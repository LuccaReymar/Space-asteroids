gdjs.PlayScene2Code = {};
gdjs.PlayScene2Code.GDBigAsteroidObjects4_1final = [];

gdjs.PlayScene2Code.GDBulletObjects3_1final = [];

gdjs.PlayScene2Code.GDBulletObjects4_1final = [];

gdjs.PlayScene2Code.GDEnemyBulletObjects3_1final = [];

gdjs.PlayScene2Code.GDEnemyBulletObjects4_1final = [];

gdjs.PlayScene2Code.GDFireButtonObjects2_1final = [];

gdjs.PlayScene2Code.GDLeftButtonObjects3_1final = [];

gdjs.PlayScene2Code.GDMediumAsteroidObjects4_1final = [];

gdjs.PlayScene2Code.GDRightButtonObjects2_1final = [];

gdjs.PlayScene2Code.GDSmallAsteroidObjects3_1final = [];

gdjs.PlayScene2Code.GDTopButtonObjects2_1final = [];

gdjs.PlayScene2Code.GDTopButtonObjects3_1final = [];

gdjs.PlayScene2Code.forEachIndex3 = 0;

gdjs.PlayScene2Code.forEachIndex4 = 0;

gdjs.PlayScene2Code.forEachObjects3 = [];

gdjs.PlayScene2Code.forEachObjects4 = [];

gdjs.PlayScene2Code.forEachTemporary3 = null;

gdjs.PlayScene2Code.forEachTemporary4 = null;

gdjs.PlayScene2Code.forEachTotalCount3 = 0;

gdjs.PlayScene2Code.forEachTotalCount4 = 0;

gdjs.PlayScene2Code.GDPlayerObjects1= [];
gdjs.PlayScene2Code.GDPlayerObjects2= [];
gdjs.PlayScene2Code.GDPlayerObjects3= [];
gdjs.PlayScene2Code.GDPlayerObjects4= [];
gdjs.PlayScene2Code.GDPlayerObjects5= [];
gdjs.PlayScene2Code.GDPlayerObjects6= [];
gdjs.PlayScene2Code.GDBulletObjects1= [];
gdjs.PlayScene2Code.GDBulletObjects2= [];
gdjs.PlayScene2Code.GDBulletObjects3= [];
gdjs.PlayScene2Code.GDBulletObjects4= [];
gdjs.PlayScene2Code.GDBulletObjects5= [];
gdjs.PlayScene2Code.GDBulletObjects6= [];
gdjs.PlayScene2Code.GDBigAsteroidObjects1= [];
gdjs.PlayScene2Code.GDBigAsteroidObjects2= [];
gdjs.PlayScene2Code.GDBigAsteroidObjects3= [];
gdjs.PlayScene2Code.GDBigAsteroidObjects4= [];
gdjs.PlayScene2Code.GDBigAsteroidObjects5= [];
gdjs.PlayScene2Code.GDBigAsteroidObjects6= [];
gdjs.PlayScene2Code.GDMediumAsteroidObjects1= [];
gdjs.PlayScene2Code.GDMediumAsteroidObjects2= [];
gdjs.PlayScene2Code.GDMediumAsteroidObjects3= [];
gdjs.PlayScene2Code.GDMediumAsteroidObjects4= [];
gdjs.PlayScene2Code.GDMediumAsteroidObjects5= [];
gdjs.PlayScene2Code.GDMediumAsteroidObjects6= [];
gdjs.PlayScene2Code.GDSmallAsteroidObjects1= [];
gdjs.PlayScene2Code.GDSmallAsteroidObjects2= [];
gdjs.PlayScene2Code.GDSmallAsteroidObjects3= [];
gdjs.PlayScene2Code.GDSmallAsteroidObjects4= [];
gdjs.PlayScene2Code.GDSmallAsteroidObjects5= [];
gdjs.PlayScene2Code.GDSmallAsteroidObjects6= [];
gdjs.PlayScene2Code.GDLifeBarObjects1= [];
gdjs.PlayScene2Code.GDLifeBarObjects2= [];
gdjs.PlayScene2Code.GDLifeBarObjects3= [];
gdjs.PlayScene2Code.GDLifeBarObjects4= [];
gdjs.PlayScene2Code.GDLifeBarObjects5= [];
gdjs.PlayScene2Code.GDLifeBarObjects6= [];
gdjs.PlayScene2Code.GDGameOverObjects1= [];
gdjs.PlayScene2Code.GDGameOverObjects2= [];
gdjs.PlayScene2Code.GDGameOverObjects3= [];
gdjs.PlayScene2Code.GDGameOverObjects4= [];
gdjs.PlayScene2Code.GDGameOverObjects5= [];
gdjs.PlayScene2Code.GDGameOverObjects6= [];
gdjs.PlayScene2Code.GDDeathShipParticleObjects1= [];
gdjs.PlayScene2Code.GDDeathShipParticleObjects2= [];
gdjs.PlayScene2Code.GDDeathShipParticleObjects3= [];
gdjs.PlayScene2Code.GDDeathShipParticleObjects4= [];
gdjs.PlayScene2Code.GDDeathShipParticleObjects5= [];
gdjs.PlayScene2Code.GDDeathShipParticleObjects6= [];
gdjs.PlayScene2Code.GDDeathDebrisParticleObjects1= [];
gdjs.PlayScene2Code.GDDeathDebrisParticleObjects2= [];
gdjs.PlayScene2Code.GDDeathDebrisParticleObjects3= [];
gdjs.PlayScene2Code.GDDeathDebrisParticleObjects4= [];
gdjs.PlayScene2Code.GDDeathDebrisParticleObjects5= [];
gdjs.PlayScene2Code.GDDeathDebrisParticleObjects6= [];
gdjs.PlayScene2Code.GDDebrisHugeObjects1= [];
gdjs.PlayScene2Code.GDDebrisHugeObjects2= [];
gdjs.PlayScene2Code.GDDebrisHugeObjects3= [];
gdjs.PlayScene2Code.GDDebrisHugeObjects4= [];
gdjs.PlayScene2Code.GDDebrisHugeObjects5= [];
gdjs.PlayScene2Code.GDDebrisHugeObjects6= [];
gdjs.PlayScene2Code.GDDebrisMediumObjects1= [];
gdjs.PlayScene2Code.GDDebrisMediumObjects2= [];
gdjs.PlayScene2Code.GDDebrisMediumObjects3= [];
gdjs.PlayScene2Code.GDDebrisMediumObjects4= [];
gdjs.PlayScene2Code.GDDebrisMediumObjects5= [];
gdjs.PlayScene2Code.GDDebrisMediumObjects6= [];
gdjs.PlayScene2Code.GDDebrisSmallObjects1= [];
gdjs.PlayScene2Code.GDDebrisSmallObjects2= [];
gdjs.PlayScene2Code.GDDebrisSmallObjects3= [];
gdjs.PlayScene2Code.GDDebrisSmallObjects4= [];
gdjs.PlayScene2Code.GDDebrisSmallObjects5= [];
gdjs.PlayScene2Code.GDDebrisSmallObjects6= [];
gdjs.PlayScene2Code.GDBulletHitObjects1= [];
gdjs.PlayScene2Code.GDBulletHitObjects2= [];
gdjs.PlayScene2Code.GDBulletHitObjects3= [];
gdjs.PlayScene2Code.GDBulletHitObjects4= [];
gdjs.PlayScene2Code.GDBulletHitObjects5= [];
gdjs.PlayScene2Code.GDBulletHitObjects6= [];
gdjs.PlayScene2Code.GDBulletFlashObjects1= [];
gdjs.PlayScene2Code.GDBulletFlashObjects2= [];
gdjs.PlayScene2Code.GDBulletFlashObjects3= [];
gdjs.PlayScene2Code.GDBulletFlashObjects4= [];
gdjs.PlayScene2Code.GDBulletFlashObjects5= [];
gdjs.PlayScene2Code.GDBulletFlashObjects6= [];
gdjs.PlayScene2Code.GDStarBackgroundObjects1= [];
gdjs.PlayScene2Code.GDStarBackgroundObjects2= [];
gdjs.PlayScene2Code.GDStarBackgroundObjects3= [];
gdjs.PlayScene2Code.GDStarBackgroundObjects4= [];
gdjs.PlayScene2Code.GDStarBackgroundObjects5= [];
gdjs.PlayScene2Code.GDStarBackgroundObjects6= [];
gdjs.PlayScene2Code.GDMotionTrailObjects1= [];
gdjs.PlayScene2Code.GDMotionTrailObjects2= [];
gdjs.PlayScene2Code.GDMotionTrailObjects3= [];
gdjs.PlayScene2Code.GDMotionTrailObjects4= [];
gdjs.PlayScene2Code.GDMotionTrailObjects5= [];
gdjs.PlayScene2Code.GDMotionTrailObjects6= [];
gdjs.PlayScene2Code.GDTutorialTextObjects1= [];
gdjs.PlayScene2Code.GDTutorialTextObjects2= [];
gdjs.PlayScene2Code.GDTutorialTextObjects3= [];
gdjs.PlayScene2Code.GDTutorialTextObjects4= [];
gdjs.PlayScene2Code.GDTutorialTextObjects5= [];
gdjs.PlayScene2Code.GDTutorialTextObjects6= [];
gdjs.PlayScene2Code.GDContinueTextObjects1= [];
gdjs.PlayScene2Code.GDContinueTextObjects2= [];
gdjs.PlayScene2Code.GDContinueTextObjects3= [];
gdjs.PlayScene2Code.GDContinueTextObjects4= [];
gdjs.PlayScene2Code.GDContinueTextObjects5= [];
gdjs.PlayScene2Code.GDContinueTextObjects6= [];
gdjs.PlayScene2Code.GDRightButtonObjects1= [];
gdjs.PlayScene2Code.GDRightButtonObjects2= [];
gdjs.PlayScene2Code.GDRightButtonObjects3= [];
gdjs.PlayScene2Code.GDRightButtonObjects4= [];
gdjs.PlayScene2Code.GDRightButtonObjects5= [];
gdjs.PlayScene2Code.GDRightButtonObjects6= [];
gdjs.PlayScene2Code.GDLeftButtonObjects1= [];
gdjs.PlayScene2Code.GDLeftButtonObjects2= [];
gdjs.PlayScene2Code.GDLeftButtonObjects3= [];
gdjs.PlayScene2Code.GDLeftButtonObjects4= [];
gdjs.PlayScene2Code.GDLeftButtonObjects5= [];
gdjs.PlayScene2Code.GDLeftButtonObjects6= [];
gdjs.PlayScene2Code.GDTopButtonObjects1= [];
gdjs.PlayScene2Code.GDTopButtonObjects2= [];
gdjs.PlayScene2Code.GDTopButtonObjects3= [];
gdjs.PlayScene2Code.GDTopButtonObjects4= [];
gdjs.PlayScene2Code.GDTopButtonObjects5= [];
gdjs.PlayScene2Code.GDTopButtonObjects6= [];
gdjs.PlayScene2Code.GDFireButtonObjects1= [];
gdjs.PlayScene2Code.GDFireButtonObjects2= [];
gdjs.PlayScene2Code.GDFireButtonObjects3= [];
gdjs.PlayScene2Code.GDFireButtonObjects4= [];
gdjs.PlayScene2Code.GDFireButtonObjects5= [];
gdjs.PlayScene2Code.GDFireButtonObjects6= [];
gdjs.PlayScene2Code.GDEnemyBulletObjects1= [];
gdjs.PlayScene2Code.GDEnemyBulletObjects2= [];
gdjs.PlayScene2Code.GDEnemyBulletObjects3= [];
gdjs.PlayScene2Code.GDEnemyBulletObjects4= [];
gdjs.PlayScene2Code.GDEnemyBulletObjects5= [];
gdjs.PlayScene2Code.GDEnemyBulletObjects6= [];
gdjs.PlayScene2Code.GDEnemyObjects1= [];
gdjs.PlayScene2Code.GDEnemyObjects2= [];
gdjs.PlayScene2Code.GDEnemyObjects3= [];
gdjs.PlayScene2Code.GDEnemyObjects4= [];
gdjs.PlayScene2Code.GDEnemyObjects5= [];
gdjs.PlayScene2Code.GDEnemyObjects6= [];
gdjs.PlayScene2Code.GDTitleTextObjects1= [];
gdjs.PlayScene2Code.GDTitleTextObjects2= [];
gdjs.PlayScene2Code.GDTitleTextObjects3= [];
gdjs.PlayScene2Code.GDTitleTextObjects4= [];
gdjs.PlayScene2Code.GDTitleTextObjects5= [];
gdjs.PlayScene2Code.GDTitleTextObjects6= [];
gdjs.PlayScene2Code.GDHealthPowerObjects1= [];
gdjs.PlayScene2Code.GDHealthPowerObjects2= [];
gdjs.PlayScene2Code.GDHealthPowerObjects3= [];
gdjs.PlayScene2Code.GDHealthPowerObjects4= [];
gdjs.PlayScene2Code.GDHealthPowerObjects5= [];
gdjs.PlayScene2Code.GDHealthPowerObjects6= [];
gdjs.PlayScene2Code.GDNextLevelObjects1= [];
gdjs.PlayScene2Code.GDNextLevelObjects2= [];
gdjs.PlayScene2Code.GDNextLevelObjects3= [];
gdjs.PlayScene2Code.GDNextLevelObjects4= [];
gdjs.PlayScene2Code.GDNextLevelObjects5= [];
gdjs.PlayScene2Code.GDNextLevelObjects6= [];
gdjs.PlayScene2Code.GDDeathEnemyParticleObjects1= [];
gdjs.PlayScene2Code.GDDeathEnemyParticleObjects2= [];
gdjs.PlayScene2Code.GDDeathEnemyParticleObjects3= [];
gdjs.PlayScene2Code.GDDeathEnemyParticleObjects4= [];
gdjs.PlayScene2Code.GDDeathEnemyParticleObjects5= [];
gdjs.PlayScene2Code.GDDeathEnemyParticleObjects6= [];
gdjs.PlayScene2Code.GDMenuTextObjects1= [];
gdjs.PlayScene2Code.GDMenuTextObjects2= [];
gdjs.PlayScene2Code.GDMenuTextObjects3= [];
gdjs.PlayScene2Code.GDMenuTextObjects4= [];
gdjs.PlayScene2Code.GDMenuTextObjects5= [];
gdjs.PlayScene2Code.GDMenuTextObjects6= [];
gdjs.PlayScene2Code.GDContinueButtonObjects1= [];
gdjs.PlayScene2Code.GDContinueButtonObjects2= [];
gdjs.PlayScene2Code.GDContinueButtonObjects3= [];
gdjs.PlayScene2Code.GDContinueButtonObjects4= [];
gdjs.PlayScene2Code.GDContinueButtonObjects5= [];
gdjs.PlayScene2Code.GDContinueButtonObjects6= [];
gdjs.PlayScene2Code.GDEnemyGreenObjects1= [];
gdjs.PlayScene2Code.GDEnemyGreenObjects2= [];
gdjs.PlayScene2Code.GDEnemyGreenObjects3= [];
gdjs.PlayScene2Code.GDEnemyGreenObjects4= [];
gdjs.PlayScene2Code.GDEnemyGreenObjects5= [];
gdjs.PlayScene2Code.GDEnemyGreenObjects6= [];
gdjs.PlayScene2Code.GDDeathGreenEnemyParticleObjects1= [];
gdjs.PlayScene2Code.GDDeathGreenEnemyParticleObjects2= [];
gdjs.PlayScene2Code.GDDeathGreenEnemyParticleObjects3= [];
gdjs.PlayScene2Code.GDDeathGreenEnemyParticleObjects4= [];
gdjs.PlayScene2Code.GDDeathGreenEnemyParticleObjects5= [];
gdjs.PlayScene2Code.GDDeathGreenEnemyParticleObjects6= [];
gdjs.PlayScene2Code.GDTimeTextObjects1= [];
gdjs.PlayScene2Code.GDTimeTextObjects2= [];
gdjs.PlayScene2Code.GDTimeTextObjects3= [];
gdjs.PlayScene2Code.GDTimeTextObjects4= [];
gdjs.PlayScene2Code.GDTimeTextObjects5= [];
gdjs.PlayScene2Code.GDTimeTextObjects6= [];
gdjs.PlayScene2Code.GDTimeText2Objects1= [];
gdjs.PlayScene2Code.GDTimeText2Objects2= [];
gdjs.PlayScene2Code.GDTimeText2Objects3= [];
gdjs.PlayScene2Code.GDTimeText2Objects4= [];
gdjs.PlayScene2Code.GDTimeText2Objects5= [];
gdjs.PlayScene2Code.GDTimeText2Objects6= [];
gdjs.PlayScene2Code.GDTimeText3Objects1= [];
gdjs.PlayScene2Code.GDTimeText3Objects2= [];
gdjs.PlayScene2Code.GDTimeText3Objects3= [];
gdjs.PlayScene2Code.GDTimeText3Objects4= [];
gdjs.PlayScene2Code.GDTimeText3Objects5= [];
gdjs.PlayScene2Code.GDTimeText3Objects6= [];
gdjs.PlayScene2Code.GDTimeText4Objects1= [];
gdjs.PlayScene2Code.GDTimeText4Objects2= [];
gdjs.PlayScene2Code.GDTimeText4Objects3= [];
gdjs.PlayScene2Code.GDTimeText4Objects4= [];
gdjs.PlayScene2Code.GDTimeText4Objects5= [];
gdjs.PlayScene2Code.GDTimeText4Objects6= [];


gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDEnemyObjects1Objects = Hashtable.newFrom({"Enemy": gdjs.PlayScene2Code.GDEnemyObjects1});
gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDEnemyGreenObjects2Objects = Hashtable.newFrom({"EnemyGreen": gdjs.PlayScene2Code.GDEnemyGreenObjects2});
gdjs.PlayScene2Code.asyncCallback15915868 = function (runtimeScene, asyncObjectsList) {
gdjs.PlayScene2Code.GDEnemyGreenObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDEnemyGreenObjects2Objects, 0, gdjs.randomInRange(40, 500), "");
}}
gdjs.PlayScene2Code.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.PlayScene2Code.asyncCallback15915868(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.PlayScene2Code.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TutorialText"), gdjs.PlayScene2Code.GDTutorialTextObjects2);
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "MultiTouchControls", 0, 0, 0);
}{for(var i = 0, len = gdjs.PlayScene2Code.GDTutorialTextObjects2.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDTutorialTextObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("BigAsteroid"), gdjs.PlayScene2Code.GDBigAsteroidObjects1);
gdjs.copyArray(runtimeScene.getObjects("MediumAsteroid"), gdjs.PlayScene2Code.GDMediumAsteroidObjects1);
gdjs.copyArray(runtimeScene.getObjects("SmallAsteroid"), gdjs.PlayScene2Code.GDSmallAsteroidObjects1);
gdjs.PlayScene2Code.GDEnemyObjects1.length = 0;

{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Timer");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDEnemyObjects1Objects, 960, gdjs.randomInRange(40, 500), "");
}{for(var i = 0, len = gdjs.PlayScene2Code.GDBigAsteroidObjects1.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDBigAsteroidObjects1[i].getBehavior("Physics2").applyForce(gdjs.randomInRange(-(60), 60), gdjs.randomInRange(-(60), 60), (gdjs.PlayScene2Code.GDBigAsteroidObjects1[i].getCenterXInScene()), (gdjs.PlayScene2Code.GDBigAsteroidObjects1[i].getCenterYInScene()));
}
}{for(var i = 0, len = gdjs.PlayScene2Code.GDMediumAsteroidObjects1.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDMediumAsteroidObjects1[i].getBehavior("Physics2").applyForce(gdjs.randomInRange(-(25), 25), gdjs.randomInRange(-(25), 25), (gdjs.PlayScene2Code.GDMediumAsteroidObjects1[i].getCenterXInScene()), (gdjs.PlayScene2Code.GDMediumAsteroidObjects1[i].getCenterYInScene()));
}
}{for(var i = 0, len = gdjs.PlayScene2Code.GDSmallAsteroidObjects1.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDSmallAsteroidObjects1[i].getBehavior("Physics2").applyForce(gdjs.randomInRange(-(5), 5), gdjs.randomInRange(-(5), 5), (gdjs.PlayScene2Code.GDSmallAsteroidObjects1[i].getCenterXInScene()), (gdjs.PlayScene2Code.GDSmallAsteroidObjects1[i].getCenterYInScene()));
}
}{for(var i = 0, len = gdjs.PlayScene2Code.GDBigAsteroidObjects1.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDBigAsteroidObjects1[i].setAnimation(gdjs.random(3));
}
}{for(var i = 0, len = gdjs.PlayScene2Code.GDMediumAsteroidObjects1.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDMediumAsteroidObjects1[i].setAnimation(gdjs.random(1));
}
}{for(var i = 0, len = gdjs.PlayScene2Code.GDSmallAsteroidObjects1.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDSmallAsteroidObjects1[i].setAnimation(gdjs.random(1));
}
}{for(var i = 0, len = gdjs.PlayScene2Code.GDBigAsteroidObjects1.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDBigAsteroidObjects1[i].setAngle(gdjs.random(360));
}
for(var i = 0, len = gdjs.PlayScene2Code.GDMediumAsteroidObjects1.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDMediumAsteroidObjects1[i].setAngle(gdjs.random(360));
}
for(var i = 0, len = gdjs.PlayScene2Code.GDSmallAsteroidObjects1.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDSmallAsteroidObjects1[i].setAngle(gdjs.random(360));
}
}{for(var i = 0, len = gdjs.PlayScene2Code.GDBigAsteroidObjects1.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDBigAsteroidObjects1[i].setPosition(gdjs.PlayScene2Code.GDBigAsteroidObjects1[i].getX() +(gdjs.randomInRange(-(32), 32)),gdjs.PlayScene2Code.GDBigAsteroidObjects1[i].getY() +(gdjs.randomInRange(-(32), 32)));
}
for(var i = 0, len = gdjs.PlayScene2Code.GDMediumAsteroidObjects1.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDMediumAsteroidObjects1[i].setPosition(gdjs.PlayScene2Code.GDMediumAsteroidObjects1[i].getX() +(gdjs.randomInRange(-(32), 32)),gdjs.PlayScene2Code.GDMediumAsteroidObjects1[i].getY() +(gdjs.randomInRange(-(32), 32)));
}
for(var i = 0, len = gdjs.PlayScene2Code.GDSmallAsteroidObjects1.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDSmallAsteroidObjects1[i].setPosition(gdjs.PlayScene2Code.GDSmallAsteroidObjects1[i].getX() +(gdjs.randomInRange(-(32), 32)),gdjs.PlayScene2Code.GDSmallAsteroidObjects1[i].getY() +(gdjs.randomInRange(-(32), 32)));
}
}
{ //Subevents
gdjs.PlayScene2Code.eventsList0(runtimeScene);} //End of subevents
}

}


};gdjs.PlayScene2Code.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().get("State").setString("GamePlaying");
}
{ //Subevents
gdjs.PlayScene2Code.eventsList1(runtimeScene);} //End of subevents
}

}


};gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDMotionTrailObjects3Objects = Hashtable.newFrom({"MotionTrail": gdjs.PlayScene2Code.GDMotionTrailObjects3});
gdjs.PlayScene2Code.mapOfEmptyGDTopButtonObjects = Hashtable.newFrom({"TopButton": []});
gdjs.PlayScene2Code.eventsList3 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.PlayScene2Code.GDMotionTrailObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDMotionTrailObjects3Objects, 0, 0, "");
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("MotionTrail"), gdjs.PlayScene2Code.GDMotionTrailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PlayScene2Code.GDPlayerObjects3);
{for(var i = 0, len = gdjs.PlayScene2Code.GDMotionTrailObjects3.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDMotionTrailObjects3[i].setPosition((( gdjs.PlayScene2Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDPlayerObjects3[0].getPointX("MotionTrail")),(( gdjs.PlayScene2Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDPlayerObjects3[0].getPointY("MotionTrail")));
}
}}

}


{

gdjs.PlayScene2Code.GDTopButtonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.PlayScene2Code.GDTopButtonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("TopButton"), gdjs.PlayScene2Code.GDTopButtonObjects4);
for (var i = 0, k = 0, l = gdjs.PlayScene2Code.GDTopButtonObjects4.length;i<l;++i) {
    if ( gdjs.PlayScene2Code.GDTopButtonObjects4[i].getBehavior("MultitouchButton").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.PlayScene2Code.GDTopButtonObjects4[k] = gdjs.PlayScene2Code.GDTopButtonObjects4[i];
        ++k;
    }
}
gdjs.PlayScene2Code.GDTopButtonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PlayScene2Code.GDTopButtonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.PlayScene2Code.GDTopButtonObjects3_1final.indexOf(gdjs.PlayScene2Code.GDTopButtonObjects4[j]) === -1 )
            gdjs.PlayScene2Code.GDTopButtonObjects3_1final.push(gdjs.PlayScene2Code.GDTopButtonObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.PlayScene2Code.GDTopButtonObjects3_1final, gdjs.PlayScene2Code.GDTopButtonObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15922084);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("MotionTrail"), gdjs.PlayScene2Code.GDMotionTrailObjects3);
{for(var i = 0, len = gdjs.PlayScene2Code.GDMotionTrailObjects3.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDMotionTrailObjects3[i].startEmission();
}
}}

}


{

gdjs.PlayScene2Code.GDTopButtonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "w"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.PlayScene2Code.GDTopButtonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("TopButton"), gdjs.PlayScene2Code.GDTopButtonObjects3);
for (var i = 0, k = 0, l = gdjs.PlayScene2Code.GDTopButtonObjects3.length;i<l;++i) {
    if ( !(gdjs.PlayScene2Code.GDTopButtonObjects3[i].getBehavior("MultitouchButton").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_1 = true;
        gdjs.PlayScene2Code.GDTopButtonObjects3[k] = gdjs.PlayScene2Code.GDTopButtonObjects3[i];
        ++k;
    }
}
gdjs.PlayScene2Code.GDTopButtonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PlayScene2Code.GDTopButtonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.PlayScene2Code.GDTopButtonObjects2_1final.indexOf(gdjs.PlayScene2Code.GDTopButtonObjects3[j]) === -1 )
            gdjs.PlayScene2Code.GDTopButtonObjects2_1final.push(gdjs.PlayScene2Code.GDTopButtonObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene2Code.mapOfEmptyGDTopButtonObjects) == 0;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.PlayScene2Code.GDTopButtonObjects2_1final, gdjs.PlayScene2Code.GDTopButtonObjects2);
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("MotionTrail"), gdjs.PlayScene2Code.GDMotionTrailObjects2);
{for(var i = 0, len = gdjs.PlayScene2Code.GDMotionTrailObjects2.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDMotionTrailObjects2[i].stopEmission();
}
}}

}


};gdjs.PlayScene2Code.eventsList4 = function(runtimeScene) {

{

gdjs.PlayScene2Code.GDTopButtonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.PlayScene2Code.GDTopButtonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("TopButton"), gdjs.PlayScene2Code.GDTopButtonObjects4);
for (var i = 0, k = 0, l = gdjs.PlayScene2Code.GDTopButtonObjects4.length;i<l;++i) {
    if ( gdjs.PlayScene2Code.GDTopButtonObjects4[i].getBehavior("MultitouchButton").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.PlayScene2Code.GDTopButtonObjects4[k] = gdjs.PlayScene2Code.GDTopButtonObjects4[i];
        ++k;
    }
}
gdjs.PlayScene2Code.GDTopButtonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PlayScene2Code.GDTopButtonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.PlayScene2Code.GDTopButtonObjects3_1final.indexOf(gdjs.PlayScene2Code.GDTopButtonObjects4[j]) === -1 )
            gdjs.PlayScene2Code.GDTopButtonObjects3_1final.push(gdjs.PlayScene2Code.GDTopButtonObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.PlayScene2Code.GDTopButtonObjects3_1final, gdjs.PlayScene2Code.GDTopButtonObjects3);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PlayScene2Code.GDPlayerObjects3);
{for(var i = 0, len = gdjs.PlayScene2Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDPlayerObjects3[i].getBehavior("Physics2").applyPolarForce((gdjs.PlayScene2Code.GDPlayerObjects3[i].getAngle()), 4.5, (gdjs.PlayScene2Code.GDPlayerObjects3[i].getPointX("")), (gdjs.PlayScene2Code.GDPlayerObjects3[i].getPointY("")));
}
}}

}


{

gdjs.PlayScene2Code.GDLeftButtonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.PlayScene2Code.GDLeftButtonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("LeftButton"), gdjs.PlayScene2Code.GDLeftButtonObjects4);
for (var i = 0, k = 0, l = gdjs.PlayScene2Code.GDLeftButtonObjects4.length;i<l;++i) {
    if ( gdjs.PlayScene2Code.GDLeftButtonObjects4[i].getBehavior("MultitouchButton").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.PlayScene2Code.GDLeftButtonObjects4[k] = gdjs.PlayScene2Code.GDLeftButtonObjects4[i];
        ++k;
    }
}
gdjs.PlayScene2Code.GDLeftButtonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PlayScene2Code.GDLeftButtonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.PlayScene2Code.GDLeftButtonObjects3_1final.indexOf(gdjs.PlayScene2Code.GDLeftButtonObjects4[j]) === -1 )
            gdjs.PlayScene2Code.GDLeftButtonObjects3_1final.push(gdjs.PlayScene2Code.GDLeftButtonObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.PlayScene2Code.GDLeftButtonObjects3_1final, gdjs.PlayScene2Code.GDLeftButtonObjects3);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PlayScene2Code.GDPlayerObjects3);
{for(var i = 0, len = gdjs.PlayScene2Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDPlayerObjects3[i].getBehavior("Physics2").applyTorque(-(0.5));
}
}}

}


{

gdjs.PlayScene2Code.GDRightButtonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.PlayScene2Code.GDRightButtonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("RightButton"), gdjs.PlayScene2Code.GDRightButtonObjects3);
for (var i = 0, k = 0, l = gdjs.PlayScene2Code.GDRightButtonObjects3.length;i<l;++i) {
    if ( gdjs.PlayScene2Code.GDRightButtonObjects3[i].getBehavior("MultitouchButton").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.PlayScene2Code.GDRightButtonObjects3[k] = gdjs.PlayScene2Code.GDRightButtonObjects3[i];
        ++k;
    }
}
gdjs.PlayScene2Code.GDRightButtonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PlayScene2Code.GDRightButtonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.PlayScene2Code.GDRightButtonObjects2_1final.indexOf(gdjs.PlayScene2Code.GDRightButtonObjects3[j]) === -1 )
            gdjs.PlayScene2Code.GDRightButtonObjects2_1final.push(gdjs.PlayScene2Code.GDRightButtonObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.PlayScene2Code.GDRightButtonObjects2_1final, gdjs.PlayScene2Code.GDRightButtonObjects2);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PlayScene2Code.GDPlayerObjects2);
{for(var i = 0, len = gdjs.PlayScene2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDPlayerObjects2[i].getBehavior("Physics2").applyTorque(0.5);
}
}}

}


};gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDBulletObjects2Objects = Hashtable.newFrom({"Bullet": gdjs.PlayScene2Code.GDBulletObjects2});
gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDBulletFlashObjects2Objects = Hashtable.newFrom({"BulletFlash": gdjs.PlayScene2Code.GDBulletFlashObjects2});
gdjs.PlayScene2Code.eventsList5 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PlayScene2Code.GDPlayerObjects2);
gdjs.PlayScene2Code.GDFireButtonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PlayScene2Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.PlayScene2Code.GDPlayerObjects2[i].getBehavior("FireBullet").IsReadyToShoot((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.PlayScene2Code.GDPlayerObjects2[k] = gdjs.PlayScene2Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.PlayScene2Code.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.PlayScene2Code.GDFireButtonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("FireButton"), gdjs.PlayScene2Code.GDFireButtonObjects3);
for (var i = 0, k = 0, l = gdjs.PlayScene2Code.GDFireButtonObjects3.length;i<l;++i) {
    if ( gdjs.PlayScene2Code.GDFireButtonObjects3[i].getBehavior("MultitouchButton").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.PlayScene2Code.GDFireButtonObjects3[k] = gdjs.PlayScene2Code.GDFireButtonObjects3[i];
        ++k;
    }
}
gdjs.PlayScene2Code.GDFireButtonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PlayScene2Code.GDFireButtonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.PlayScene2Code.GDFireButtonObjects2_1final.indexOf(gdjs.PlayScene2Code.GDFireButtonObjects3[j]) === -1 )
            gdjs.PlayScene2Code.GDFireButtonObjects2_1final.push(gdjs.PlayScene2Code.GDFireButtonObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.PlayScene2Code.GDFireButtonObjects2_1final, gdjs.PlayScene2Code.GDFireButtonObjects2);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.PlayScene2Code.GDBulletObjects2);
/* Reuse gdjs.PlayScene2Code.GDPlayerObjects2 */
gdjs.PlayScene2Code.GDBulletFlashObjects2.length = 0;

{for(var i = 0, len = gdjs.PlayScene2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDPlayerObjects2[i].getBehavior("FireBullet").Fire((gdjs.PlayScene2Code.GDPlayerObjects2[i].getPointX("BulletSpawn")), (gdjs.PlayScene2Code.GDPlayerObjects2[i].getPointY("BulletSpawn")), gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDBulletObjects2Objects, (gdjs.PlayScene2Code.GDPlayerObjects2[i].getAngle()), 240, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.PlayScene2Code.GDBulletObjects2.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDBulletObjects2[i].setZOrder((( gdjs.PlayScene2Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDPlayerObjects2[0].getZOrder()) - 2);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "LaserFire.wav", false, 40, gdjs.randomFloatInRange(0.9, 1.1));
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDBulletFlashObjects2Objects, (( gdjs.PlayScene2Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDPlayerObjects2[0].getPointX("BulletFlash")), (( gdjs.PlayScene2Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDPlayerObjects2[0].getPointY("BulletFlash")), "");
}{for(var i = 0, len = gdjs.PlayScene2Code.GDBulletFlashObjects2.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDBulletFlashObjects2[i].setAngle((( gdjs.PlayScene2Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDPlayerObjects2[0].getAngle()) + 90);
}
}{for(var i = 0, len = gdjs.PlayScene2Code.GDBulletFlashObjects2.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDBulletFlashObjects2[i].setZOrder((( gdjs.PlayScene2Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDPlayerObjects2[0].getZOrder()) - 1);
}
}}

}


};gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDEnemyBulletObjects3Objects = Hashtable.newFrom({"EnemyBullet": gdjs.PlayScene2Code.GDEnemyBulletObjects3});
gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDBulletFlashObjects3Objects = Hashtable.newFrom({"BulletFlash": gdjs.PlayScene2Code.GDBulletFlashObjects3});
gdjs.PlayScene2Code.eventsList6 = function(runtimeScene) {

{

/* Reuse gdjs.PlayScene2Code.GDEnemyGreenObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PlayScene2Code.GDEnemyGreenObjects3.length;i<l;++i) {
    if ( gdjs.PlayScene2Code.GDEnemyGreenObjects3[i].getBehavior("FireBullet").HasJustFired((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.PlayScene2Code.GDEnemyGreenObjects3[k] = gdjs.PlayScene2Code.GDEnemyGreenObjects3[i];
        ++k;
    }
}
gdjs.PlayScene2Code.GDEnemyGreenObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.PlayScene2Code.GDEnemyBulletObjects3 */
/* Reuse gdjs.PlayScene2Code.GDEnemyGreenObjects3 */
gdjs.PlayScene2Code.GDBulletFlashObjects3.length = 0;

{for(var i = 0, len = gdjs.PlayScene2Code.GDEnemyBulletObjects3.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDEnemyBulletObjects3[i].setZOrder((( gdjs.PlayScene2Code.GDEnemyGreenObjects3.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDEnemyGreenObjects3[0].getZOrder()) - 2);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Laser-weapon 4.aac", false, 30, gdjs.randomFloatInRange(0.9, 1.1));
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDBulletFlashObjects3Objects, (( gdjs.PlayScene2Code.GDEnemyGreenObjects3.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDEnemyGreenObjects3[0].getPointX("BulletFlash")), (( gdjs.PlayScene2Code.GDEnemyGreenObjects3.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDEnemyGreenObjects3[0].getPointY("BulletFlash")), "");
}{for(var i = 0, len = gdjs.PlayScene2Code.GDBulletFlashObjects3.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDBulletFlashObjects3[i].setAngle((( gdjs.PlayScene2Code.GDEnemyGreenObjects3.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDEnemyGreenObjects3[0].getAngle()) + 90);
}
}{for(var i = 0, len = gdjs.PlayScene2Code.GDBulletFlashObjects3.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDBulletFlashObjects3[i].setZOrder((( gdjs.PlayScene2Code.GDEnemyGreenObjects3.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDEnemyGreenObjects3[0].getZOrder()) - 1);
}
}}

}


};gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.PlayScene2Code.GDBulletObjects3});
gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDEnemyGreenObjects3Objects = Hashtable.newFrom({"EnemyGreen": gdjs.PlayScene2Code.GDEnemyGreenObjects3});
gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDDeathDebrisParticleObjects3Objects = Hashtable.newFrom({"DeathDebrisParticle": gdjs.PlayScene2Code.GDDeathDebrisParticleObjects3});
gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDDeathGreenEnemyParticleObjects3Objects = Hashtable.newFrom({"DeathGreenEnemyParticle": gdjs.PlayScene2Code.GDDeathGreenEnemyParticleObjects3});
gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDHealthPowerObjects3Objects = Hashtable.newFrom({"HealthPower": gdjs.PlayScene2Code.GDHealthPowerObjects3});
gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDBulletHitObjects3Objects = Hashtable.newFrom({"BulletHit": gdjs.PlayScene2Code.GDBulletHitObjects3});
gdjs.PlayScene2Code.mapOfEmptyGDEnemyGreenObjects = Hashtable.newFrom({"EnemyGreen": []});
gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDEnemyGreenObjects3Objects = Hashtable.newFrom({"EnemyGreen": gdjs.PlayScene2Code.GDEnemyGreenObjects3});
gdjs.PlayScene2Code.eventsList7 = function(runtimeScene) {

};gdjs.PlayScene2Code.eventsList8 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("EnemyBullet"), gdjs.PlayScene2Code.GDEnemyBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("EnemyGreen"), gdjs.PlayScene2Code.GDEnemyGreenObjects3);
{for(var i = 0, len = gdjs.PlayScene2Code.GDEnemyGreenObjects3.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDEnemyGreenObjects3[i].getBehavior("FireBullet").Fire((gdjs.PlayScene2Code.GDEnemyGreenObjects3[i].getPointX("BulletSpawn")), (gdjs.PlayScene2Code.GDEnemyGreenObjects3[i].getPointY("BulletSpawn")), gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDEnemyBulletObjects3Objects, (gdjs.PlayScene2Code.GDEnemyGreenObjects3[i].getAngle()) - 90, 160, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.PlayScene2Code.eventsList6(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.PlayScene2Code.GDEnemyObjects3);
gdjs.copyArray(runtimeScene.getObjects("EnemyGreen"), gdjs.PlayScene2Code.GDEnemyGreenObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PlayScene2Code.GDPlayerObjects3);
{for(var i = 0, len = gdjs.PlayScene2Code.GDEnemyGreenObjects3.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDEnemyGreenObjects3[i].getBehavior("Physics2").applyForce(6, 0, (( gdjs.PlayScene2Code.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDEnemyObjects3[0].getPointX("Origin")), (( gdjs.PlayScene2Code.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDEnemyObjects3[0].getPointY("Origin")));
}
}{for(var i = 0, len = gdjs.PlayScene2Code.GDEnemyGreenObjects3.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDEnemyGreenObjects3[i].rotateTowardPosition((( gdjs.PlayScene2Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDPlayerObjects3[0].getPointX("Origin")), (( gdjs.PlayScene2Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDPlayerObjects3[0].getPointY("Origin")), 0, runtimeScene);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.PlayScene2Code.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("EnemyGreen"), gdjs.PlayScene2Code.GDEnemyGreenObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDBulletObjects3Objects, gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDEnemyGreenObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.PlayScene2Code.GDBulletObjects3 */
gdjs.copyArray(runtimeScene.getObjects("DeathGreenEnemyParticle"), gdjs.PlayScene2Code.GDDeathGreenEnemyParticleObjects3);
/* Reuse gdjs.PlayScene2Code.GDEnemyGreenObjects3 */
gdjs.PlayScene2Code.GDBulletHitObjects3.length = 0;

gdjs.PlayScene2Code.GDDeathDebrisParticleObjects3.length = 0;

gdjs.PlayScene2Code.GDHealthPowerObjects3.length = 0;

{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "UFOTimer");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "PillTimer");
}{for(var i = 0, len = gdjs.PlayScene2Code.GDEnemyGreenObjects3.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDEnemyGreenObjects3[i].getBehavior("Health").Hit(1, false, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Explosion.wav", false, 60, gdjs.randomFloatInRange(0.9, 1));
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDDeathDebrisParticleObjects3Objects, (( gdjs.PlayScene2Code.GDEnemyGreenObjects3.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDEnemyGreenObjects3[0].getPointX("")), (( gdjs.PlayScene2Code.GDEnemyGreenObjects3.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDEnemyGreenObjects3[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.PlayScene2Code.GDDeathGreenEnemyParticleObjects3.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDDeathGreenEnemyParticleObjects3[i].setAngle((( gdjs.PlayScene2Code.GDEnemyGreenObjects3.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDEnemyGreenObjects3[0].getAngle()));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDDeathGreenEnemyParticleObjects3Objects, (( gdjs.PlayScene2Code.GDEnemyGreenObjects3.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDEnemyGreenObjects3[0].getPointX("")), (( gdjs.PlayScene2Code.GDEnemyGreenObjects3.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDEnemyGreenObjects3[0].getPointY("")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDHealthPowerObjects3Objects, (( gdjs.PlayScene2Code.GDEnemyGreenObjects3.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDEnemyGreenObjects3[0].getPointX("")), (( gdjs.PlayScene2Code.GDEnemyGreenObjects3.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDEnemyGreenObjects3[0].getPointY("")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDBulletHitObjects3Objects, (( gdjs.PlayScene2Code.GDBulletObjects3.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDBulletObjects3[0].getPointX("BulletHit")), (( gdjs.PlayScene2Code.GDBulletObjects3.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDBulletObjects3[0].getPointY("BulletHit")), "");
}{for(var i = 0, len = gdjs.PlayScene2Code.GDEnemyGreenObjects3.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDEnemyGreenObjects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.PlayScene2Code.GDBulletObjects3.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDBulletObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{


let stopDoWhile_0 = false;
do {
gdjs.PlayScene2Code.GDEnemyGreenObjects3.length = 0;

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "UFOTimer") >= 8;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene2Code.mapOfEmptyGDEnemyGreenObjects) == 0;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
let isConditionTrue_0 = false;
if (true) {
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDEnemyGreenObjects3Objects, 0, gdjs.randomInRange(40, 500), "");
}
{ //Subevents: 
gdjs.PlayScene2Code.eventsList7(runtimeScene);} //Subevents end.
}
} else stopDoWhile_0 = true; 
} while (!stopDoWhile_0);

}


};gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDEnemyBulletObjects3Objects = Hashtable.newFrom({"EnemyBullet": gdjs.PlayScene2Code.GDEnemyBulletObjects3});
gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDBulletFlashObjects3Objects = Hashtable.newFrom({"BulletFlash": gdjs.PlayScene2Code.GDBulletFlashObjects3});
gdjs.PlayScene2Code.eventsList9 = function(runtimeScene) {

{

/* Reuse gdjs.PlayScene2Code.GDEnemyObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PlayScene2Code.GDEnemyObjects3.length;i<l;++i) {
    if ( gdjs.PlayScene2Code.GDEnemyObjects3[i].getBehavior("FireBullet").HasJustFired((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.PlayScene2Code.GDEnemyObjects3[k] = gdjs.PlayScene2Code.GDEnemyObjects3[i];
        ++k;
    }
}
gdjs.PlayScene2Code.GDEnemyObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.PlayScene2Code.GDEnemyObjects3 */
/* Reuse gdjs.PlayScene2Code.GDEnemyBulletObjects3 */
gdjs.PlayScene2Code.GDBulletFlashObjects3.length = 0;

{for(var i = 0, len = gdjs.PlayScene2Code.GDEnemyBulletObjects3.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDEnemyBulletObjects3[i].setZOrder((( gdjs.PlayScene2Code.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDEnemyObjects3[0].getZOrder()) - 2);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Laser effect (2).aac", false, 40, gdjs.randomFloatInRange(0.9, 1.1));
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDBulletFlashObjects3Objects, (( gdjs.PlayScene2Code.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDEnemyObjects3[0].getPointX("BulletFlash")), (( gdjs.PlayScene2Code.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDEnemyObjects3[0].getPointY("BulletFlash")), "");
}{for(var i = 0, len = gdjs.PlayScene2Code.GDBulletFlashObjects3.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDBulletFlashObjects3[i].setAngle((( gdjs.PlayScene2Code.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDEnemyObjects3[0].getAngle()) + 90);
}
}{for(var i = 0, len = gdjs.PlayScene2Code.GDBulletFlashObjects3.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDBulletFlashObjects3[i].setZOrder((( gdjs.PlayScene2Code.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDEnemyObjects3[0].getZOrder()) - 1);
}
}}

}


};gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.PlayScene2Code.GDBulletObjects3});
gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDEnemyObjects3Objects = Hashtable.newFrom({"Enemy": gdjs.PlayScene2Code.GDEnemyObjects3});
gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDDeathDebrisParticleObjects3Objects = Hashtable.newFrom({"DeathDebrisParticle": gdjs.PlayScene2Code.GDDeathDebrisParticleObjects3});
gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDDeathEnemyParticleObjects3Objects = Hashtable.newFrom({"DeathEnemyParticle": gdjs.PlayScene2Code.GDDeathEnemyParticleObjects3});
gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDHealthPowerObjects3Objects = Hashtable.newFrom({"HealthPower": gdjs.PlayScene2Code.GDHealthPowerObjects3});
gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDBulletHitObjects3Objects = Hashtable.newFrom({"BulletHit": gdjs.PlayScene2Code.GDBulletHitObjects3});
gdjs.PlayScene2Code.mapOfEmptyGDEnemyObjects = Hashtable.newFrom({"Enemy": []});
gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDEnemyObjects3Objects = Hashtable.newFrom({"Enemy": gdjs.PlayScene2Code.GDEnemyObjects3});
gdjs.PlayScene2Code.eventsList10 = function(runtimeScene) {

};gdjs.PlayScene2Code.eventsList11 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.PlayScene2Code.GDEnemyObjects3);
gdjs.copyArray(runtimeScene.getObjects("EnemyBullet"), gdjs.PlayScene2Code.GDEnemyBulletObjects3);
{for(var i = 0, len = gdjs.PlayScene2Code.GDEnemyObjects3.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDEnemyObjects3[i].getBehavior("FireBullet").Fire((gdjs.PlayScene2Code.GDEnemyObjects3[i].getPointX("BulletSpawn")), (gdjs.PlayScene2Code.GDEnemyObjects3[i].getPointY("BulletSpawn")), gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDEnemyBulletObjects3Objects, (gdjs.PlayScene2Code.GDEnemyObjects3[i].getAngle()), 120, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.PlayScene2Code.eventsList9(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.PlayScene2Code.GDEnemyObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PlayScene2Code.GDPlayerObjects3);
{for(var i = 0, len = gdjs.PlayScene2Code.GDEnemyObjects3.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDEnemyObjects3[i].getBehavior("Physics2").applyForce(-(3), 0, (gdjs.PlayScene2Code.GDEnemyObjects3[i].getPointX("Origin")), (gdjs.PlayScene2Code.GDEnemyObjects3[i].getPointY("Origin")));
}
}{for(var i = 0, len = gdjs.PlayScene2Code.GDEnemyObjects3.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDEnemyObjects3[i].rotateTowardPosition((( gdjs.PlayScene2Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDPlayerObjects3[0].getPointX("Origin")), (( gdjs.PlayScene2Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDPlayerObjects3[0].getPointY("Origin")), 0, runtimeScene);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.PlayScene2Code.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.PlayScene2Code.GDEnemyObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDBulletObjects3Objects, gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDEnemyObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.PlayScene2Code.GDBulletObjects3 */
gdjs.copyArray(runtimeScene.getObjects("DeathEnemyParticle"), gdjs.PlayScene2Code.GDDeathEnemyParticleObjects3);
/* Reuse gdjs.PlayScene2Code.GDEnemyObjects3 */
gdjs.PlayScene2Code.GDBulletHitObjects3.length = 0;

gdjs.PlayScene2Code.GDDeathDebrisParticleObjects3.length = 0;

gdjs.PlayScene2Code.GDHealthPowerObjects3.length = 0;

{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "EnemyTimer");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "PillTimer");
}{for(var i = 0, len = gdjs.PlayScene2Code.GDEnemyObjects3.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDEnemyObjects3[i].getBehavior("Health").Hit(1, false, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Explosion.wav", false, 60, gdjs.randomFloatInRange(0.9, 1));
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDDeathDebrisParticleObjects3Objects, (( gdjs.PlayScene2Code.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDEnemyObjects3[0].getPointX("")), (( gdjs.PlayScene2Code.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDEnemyObjects3[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.PlayScene2Code.GDDeathEnemyParticleObjects3.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDDeathEnemyParticleObjects3[i].setAngle((( gdjs.PlayScene2Code.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDEnemyObjects3[0].getAngle()));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDDeathEnemyParticleObjects3Objects, (( gdjs.PlayScene2Code.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDEnemyObjects3[0].getPointX("")), (( gdjs.PlayScene2Code.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDEnemyObjects3[0].getPointY("")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDHealthPowerObjects3Objects, (( gdjs.PlayScene2Code.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDEnemyObjects3[0].getPointX("")), (( gdjs.PlayScene2Code.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDEnemyObjects3[0].getPointY("")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDBulletHitObjects3Objects, (( gdjs.PlayScene2Code.GDBulletObjects3.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDBulletObjects3[0].getPointX("BulletHit")), (( gdjs.PlayScene2Code.GDBulletObjects3.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDBulletObjects3[0].getPointY("BulletHit")), "");
}{for(var i = 0, len = gdjs.PlayScene2Code.GDEnemyObjects3.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDEnemyObjects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.PlayScene2Code.GDBulletObjects3.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDBulletObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{


let stopDoWhile_0 = false;
do {
gdjs.PlayScene2Code.GDEnemyObjects3.length = 0;

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "EnemyTimer") >= 5;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene2Code.mapOfEmptyGDEnemyObjects) == 0;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
let isConditionTrue_0 = false;
if (true) {
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDEnemyObjects3Objects, 960, gdjs.randomInRange(40, 500), "");
}
{ //Subevents: 
gdjs.PlayScene2Code.eventsList10(runtimeScene);} //Subevents end.
}
} else stopDoWhile_0 = true; 
} while (!stopDoWhile_0);

}


};gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.PlayScene2Code.GDPlayerObjects3});
gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDHealthPowerObjects3Objects = Hashtable.newFrom({"HealthPower": gdjs.PlayScene2Code.GDHealthPowerObjects3});
gdjs.PlayScene2Code.mapOfEmptyGDHealthPowerObjects = Hashtable.newFrom({"HealthPower": []});
gdjs.PlayScene2Code.eventsList12 = function(runtimeScene) {

{

/* Reuse gdjs.PlayScene2Code.GDHealthPowerObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.PlayScene2Code.GDHealthPowerObjects2.length;i<l;++i) {
    if ( gdjs.PlayScene2Code.GDHealthPowerObjects2[i].getBehavior("Flash").IsFlashing((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.PlayScene2Code.GDHealthPowerObjects2[k] = gdjs.PlayScene2Code.GDHealthPowerObjects2[i];
        ++k;
    }
}
gdjs.PlayScene2Code.GDHealthPowerObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "PillTimer") >= 8;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.PlayScene2Code.GDHealthPowerObjects2 */
{for(var i = 0, len = gdjs.PlayScene2Code.GDHealthPowerObjects2.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDHealthPowerObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.PlayScene2Code.eventsList13 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("HealthPower"), gdjs.PlayScene2Code.GDHealthPowerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PlayScene2Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDPlayerObjects3Objects, gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDHealthPowerObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.PlayScene2Code.GDHealthPowerObjects3 */
gdjs.copyArray(runtimeScene.getObjects("LifeBar"), gdjs.PlayScene2Code.GDLifeBarObjects3);
/* Reuse gdjs.PlayScene2Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.PlayScene2Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDPlayerObjects3[i].getBehavior("Health").Heal(1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.PlayScene2Code.GDLifeBarObjects3.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDLifeBarObjects3[i].SetValue((( gdjs.PlayScene2Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDPlayerObjects3[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.PlayScene2Code.GDHealthPowerObjects3.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDHealthPowerObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene2Code.mapOfEmptyGDHealthPowerObjects) > 0;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "PillTimer") >= 5;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("HealthPower"), gdjs.PlayScene2Code.GDHealthPowerObjects2);
{for(var i = 0, len = gdjs.PlayScene2Code.GDHealthPowerObjects2.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDHealthPowerObjects2[i].getBehavior("Flash").Flash(3, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.PlayScene2Code.eventsList12(runtimeScene);} //End of subevents
}

}


};gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDBulletObjects5Objects = Hashtable.newFrom({"Bullet": gdjs.PlayScene2Code.GDBulletObjects5});
gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDBigAsteroidObjects5Objects = Hashtable.newFrom({"BigAsteroid": gdjs.PlayScene2Code.GDBigAsteroidObjects5});
gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDEnemyBulletObjects5Objects = Hashtable.newFrom({"EnemyBullet": gdjs.PlayScene2Code.GDEnemyBulletObjects5});
gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDBigAsteroidObjects5Objects = Hashtable.newFrom({"BigAsteroid": gdjs.PlayScene2Code.GDBigAsteroidObjects5});
gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDDebrisHugeObjects4Objects = Hashtable.newFrom({"DebrisHuge": gdjs.PlayScene2Code.GDDebrisHugeObjects4});
gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDBulletHitObjects4Objects = Hashtable.newFrom({"BulletHit": gdjs.PlayScene2Code.GDBulletHitObjects4});
gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDMediumAsteroidObjects5Objects = Hashtable.newFrom({"MediumAsteroid": gdjs.PlayScene2Code.GDMediumAsteroidObjects5});
gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDMediumAsteroidObjects5Objects = Hashtable.newFrom({"MediumAsteroid": gdjs.PlayScene2Code.GDMediumAsteroidObjects5});
gdjs.PlayScene2Code.eventsList14 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.PlayScene2Code.GDBigAsteroidObjects4, gdjs.PlayScene2Code.GDBigAsteroidObjects5);

gdjs.copyArray(gdjs.PlayScene2Code.GDBulletObjects4, gdjs.PlayScene2Code.GDBulletObjects5);

gdjs.PlayScene2Code.GDMediumAsteroidObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDMediumAsteroidObjects5Objects, (( gdjs.PlayScene2Code.GDBigAsteroidObjects5.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDBigAsteroidObjects5[0].getPointX("")), (( gdjs.PlayScene2Code.GDBigAsteroidObjects5.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDBigAsteroidObjects5[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.PlayScene2Code.GDMediumAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDMediumAsteroidObjects5[i].setAngle(gdjs.random(360));
}
}{for(var i = 0, len = gdjs.PlayScene2Code.GDMediumAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDMediumAsteroidObjects5[i].putAroundObject((gdjs.PlayScene2Code.GDBigAsteroidObjects5.length !== 0 ? gdjs.PlayScene2Code.GDBigAsteroidObjects5[0] : null), 15, (( gdjs.PlayScene2Code.GDBulletObjects5.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDBulletObjects5[0].getAngle()) - 90);
}
}{for(var i = 0, len = gdjs.PlayScene2Code.GDMediumAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDMediumAsteroidObjects5[i].getBehavior("Physics2").applyTorque(gdjs.randomFloatInRange(-(0.1), 0.1));
}
}{for(var i = 0, len = gdjs.PlayScene2Code.GDMediumAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDMediumAsteroidObjects5[i].getBehavior("Physics2").applyPolarForce((( gdjs.PlayScene2Code.GDBulletObjects5.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDBulletObjects5[0].getAngle()) + gdjs.randomFloatInRange(-(60), 0), 5, (gdjs.PlayScene2Code.GDMediumAsteroidObjects5[i].getBehavior("Physics2").getMassCenterX()), (gdjs.PlayScene2Code.GDMediumAsteroidObjects5[i].getBehavior("Physics2").getMassCenterY()));
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.PlayScene2Code.GDBigAsteroidObjects4, gdjs.PlayScene2Code.GDBigAsteroidObjects5);

gdjs.copyArray(gdjs.PlayScene2Code.GDBulletObjects4, gdjs.PlayScene2Code.GDBulletObjects5);

gdjs.PlayScene2Code.GDMediumAsteroidObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDMediumAsteroidObjects5Objects, (( gdjs.PlayScene2Code.GDBigAsteroidObjects5.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDBigAsteroidObjects5[0].getPointX("")), (( gdjs.PlayScene2Code.GDBigAsteroidObjects5.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDBigAsteroidObjects5[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.PlayScene2Code.GDMediumAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDMediumAsteroidObjects5[i].setAngle(gdjs.random(360));
}
}{for(var i = 0, len = gdjs.PlayScene2Code.GDMediumAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDMediumAsteroidObjects5[i].putAroundObject((gdjs.PlayScene2Code.GDBigAsteroidObjects5.length !== 0 ? gdjs.PlayScene2Code.GDBigAsteroidObjects5[0] : null), 15, (( gdjs.PlayScene2Code.GDBulletObjects5.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDBulletObjects5[0].getAngle()) + 90);
}
}{for(var i = 0, len = gdjs.PlayScene2Code.GDMediumAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDMediumAsteroidObjects5[i].getBehavior("Physics2").applyTorque(gdjs.randomFloatInRange(-(0.1), 0.1));
}
}{for(var i = 0, len = gdjs.PlayScene2Code.GDMediumAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDMediumAsteroidObjects5[i].getBehavior("Physics2").applyPolarForce((( gdjs.PlayScene2Code.GDBulletObjects5.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDBulletObjects5[0].getAngle()) + gdjs.randomFloatInRange(0, 60), 5, (gdjs.PlayScene2Code.GDMediumAsteroidObjects5[i].getBehavior("Physics2").getMassCenterX()), (gdjs.PlayScene2Code.GDMediumAsteroidObjects5[i].getBehavior("Physics2").getMassCenterY()));
}
}}

}


};gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDBulletObjects5Objects = Hashtable.newFrom({"Bullet": gdjs.PlayScene2Code.GDBulletObjects5});
gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDMediumAsteroidObjects5Objects = Hashtable.newFrom({"MediumAsteroid": gdjs.PlayScene2Code.GDMediumAsteroidObjects5});
gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDEnemyBulletObjects5Objects = Hashtable.newFrom({"EnemyBullet": gdjs.PlayScene2Code.GDEnemyBulletObjects5});
gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDMediumAsteroidObjects5Objects = Hashtable.newFrom({"MediumAsteroid": gdjs.PlayScene2Code.GDMediumAsteroidObjects5});
gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDDebrisMediumObjects4Objects = Hashtable.newFrom({"DebrisMedium": gdjs.PlayScene2Code.GDDebrisMediumObjects4});
gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDBulletHitObjects4Objects = Hashtable.newFrom({"BulletHit": gdjs.PlayScene2Code.GDBulletHitObjects4});
gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDSmallAsteroidObjects5Objects = Hashtable.newFrom({"SmallAsteroid": gdjs.PlayScene2Code.GDSmallAsteroidObjects5});
gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDSmallAsteroidObjects5Objects = Hashtable.newFrom({"SmallAsteroid": gdjs.PlayScene2Code.GDSmallAsteroidObjects5});
gdjs.PlayScene2Code.eventsList15 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("BigAsteroid"), gdjs.PlayScene2Code.GDBigAsteroidObjects5);
gdjs.copyArray(gdjs.PlayScene2Code.GDBulletObjects4, gdjs.PlayScene2Code.GDBulletObjects5);

gdjs.copyArray(gdjs.PlayScene2Code.GDMediumAsteroidObjects4, gdjs.PlayScene2Code.GDMediumAsteroidObjects5);

gdjs.PlayScene2Code.GDSmallAsteroidObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDSmallAsteroidObjects5Objects, (( gdjs.PlayScene2Code.GDBigAsteroidObjects5.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDBigAsteroidObjects5[0].getPointX("")), (( gdjs.PlayScene2Code.GDBigAsteroidObjects5.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDBigAsteroidObjects5[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.PlayScene2Code.GDSmallAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDSmallAsteroidObjects5[i].setAngle(gdjs.random(360));
}
}{for(var i = 0, len = gdjs.PlayScene2Code.GDSmallAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDSmallAsteroidObjects5[i].putAroundObject((gdjs.PlayScene2Code.GDMediumAsteroidObjects5.length !== 0 ? gdjs.PlayScene2Code.GDMediumAsteroidObjects5[0] : null), 8, (( gdjs.PlayScene2Code.GDBulletObjects5.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDBulletObjects5[0].getAngle()) - 90);
}
}{for(var i = 0, len = gdjs.PlayScene2Code.GDSmallAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDSmallAsteroidObjects5[i].getBehavior("Physics2").applyTorque(gdjs.randomFloatInRange(-(0.1), 0.1));
}
}{for(var i = 0, len = gdjs.PlayScene2Code.GDSmallAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDSmallAsteroidObjects5[i].getBehavior("Physics2").applyPolarForce((( gdjs.PlayScene2Code.GDBulletObjects5.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDBulletObjects5[0].getAngle()) + gdjs.randomFloatInRange(-(60), 0), 2, (gdjs.PlayScene2Code.GDSmallAsteroidObjects5[i].getBehavior("Physics2").getMassCenterX()), (gdjs.PlayScene2Code.GDSmallAsteroidObjects5[i].getBehavior("Physics2").getMassCenterY()));
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.PlayScene2Code.GDBulletObjects4, gdjs.PlayScene2Code.GDBulletObjects5);

gdjs.copyArray(gdjs.PlayScene2Code.GDMediumAsteroidObjects4, gdjs.PlayScene2Code.GDMediumAsteroidObjects5);

gdjs.PlayScene2Code.GDSmallAsteroidObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDSmallAsteroidObjects5Objects, (( gdjs.PlayScene2Code.GDMediumAsteroidObjects5.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDMediumAsteroidObjects5[0].getPointX("")), (( gdjs.PlayScene2Code.GDMediumAsteroidObjects5.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDMediumAsteroidObjects5[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.PlayScene2Code.GDSmallAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDSmallAsteroidObjects5[i].setAngle(gdjs.random(360));
}
}{for(var i = 0, len = gdjs.PlayScene2Code.GDSmallAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDSmallAsteroidObjects5[i].putAroundObject((gdjs.PlayScene2Code.GDMediumAsteroidObjects5.length !== 0 ? gdjs.PlayScene2Code.GDMediumAsteroidObjects5[0] : null), 8, (( gdjs.PlayScene2Code.GDBulletObjects5.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDBulletObjects5[0].getAngle()) + 90);
}
}{for(var i = 0, len = gdjs.PlayScene2Code.GDSmallAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDSmallAsteroidObjects5[i].getBehavior("Physics2").applyTorque(gdjs.randomFloatInRange(-(0.1), 0.1));
}
}{for(var i = 0, len = gdjs.PlayScene2Code.GDSmallAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDSmallAsteroidObjects5[i].getBehavior("Physics2").applyPolarForce((( gdjs.PlayScene2Code.GDBulletObjects5.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDBulletObjects5[0].getAngle()) + gdjs.randomFloatInRange(0, 60), 2, (gdjs.PlayScene2Code.GDSmallAsteroidObjects5[i].getBehavior("Physics2").getMassCenterX()), (gdjs.PlayScene2Code.GDSmallAsteroidObjects5[i].getBehavior("Physics2").getMassCenterY()));
}
}}

}


};gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDBulletObjects4Objects = Hashtable.newFrom({"Bullet": gdjs.PlayScene2Code.GDBulletObjects4});
gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDSmallAsteroidObjects4Objects = Hashtable.newFrom({"SmallAsteroid": gdjs.PlayScene2Code.GDSmallAsteroidObjects4});
gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDEnemyBulletObjects4Objects = Hashtable.newFrom({"EnemyBullet": gdjs.PlayScene2Code.GDEnemyBulletObjects4});
gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDSmallAsteroidObjects4Objects = Hashtable.newFrom({"SmallAsteroid": gdjs.PlayScene2Code.GDSmallAsteroidObjects4});
gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDDebrisSmallObjects3Objects = Hashtable.newFrom({"DebrisSmall": gdjs.PlayScene2Code.GDDebrisSmallObjects3});
gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDBulletHitObjects3Objects = Hashtable.newFrom({"BulletHit": gdjs.PlayScene2Code.GDBulletHitObjects3});
gdjs.PlayScene2Code.eventsList16 = function(runtimeScene) {

};gdjs.PlayScene2Code.eventsList17 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("BigAsteroid"), gdjs.PlayScene2Code.GDBigAsteroidObjects3);

for (gdjs.PlayScene2Code.forEachIndex4 = 0;gdjs.PlayScene2Code.forEachIndex4 < gdjs.PlayScene2Code.GDBigAsteroidObjects3.length;++gdjs.PlayScene2Code.forEachIndex4) {
gdjs.PlayScene2Code.GDBulletObjects4.length = 0;

gdjs.PlayScene2Code.GDBulletHitObjects4.length = 0;

gdjs.PlayScene2Code.GDDebrisHugeObjects4.length = 0;

gdjs.PlayScene2Code.GDEnemyBulletObjects4.length = 0;

gdjs.PlayScene2Code.GDBigAsteroidObjects4.length = 0;


gdjs.PlayScene2Code.forEachTemporary4 = gdjs.PlayScene2Code.GDBigAsteroidObjects3[gdjs.PlayScene2Code.forEachIndex4];
gdjs.PlayScene2Code.GDBigAsteroidObjects4.push(gdjs.PlayScene2Code.forEachTemporary4);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.PlayScene2Code.GDBigAsteroidObjects4_1final.length = 0;
gdjs.PlayScene2Code.GDBulletObjects4_1final.length = 0;
gdjs.PlayScene2Code.GDEnemyBulletObjects4_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.PlayScene2Code.GDBigAsteroidObjects4, gdjs.PlayScene2Code.GDBigAsteroidObjects5);

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.PlayScene2Code.GDBulletObjects5);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDBulletObjects5Objects, gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDBigAsteroidObjects5Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PlayScene2Code.GDBigAsteroidObjects5.length; j < jLen ; ++j) {
        if ( gdjs.PlayScene2Code.GDBigAsteroidObjects4_1final.indexOf(gdjs.PlayScene2Code.GDBigAsteroidObjects5[j]) === -1 )
            gdjs.PlayScene2Code.GDBigAsteroidObjects4_1final.push(gdjs.PlayScene2Code.GDBigAsteroidObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.PlayScene2Code.GDBulletObjects5.length; j < jLen ; ++j) {
        if ( gdjs.PlayScene2Code.GDBulletObjects4_1final.indexOf(gdjs.PlayScene2Code.GDBulletObjects5[j]) === -1 )
            gdjs.PlayScene2Code.GDBulletObjects4_1final.push(gdjs.PlayScene2Code.GDBulletObjects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.PlayScene2Code.GDBigAsteroidObjects4, gdjs.PlayScene2Code.GDBigAsteroidObjects5);

gdjs.copyArray(runtimeScene.getObjects("EnemyBullet"), gdjs.PlayScene2Code.GDEnemyBulletObjects5);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDEnemyBulletObjects5Objects, gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDBigAsteroidObjects5Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PlayScene2Code.GDBigAsteroidObjects5.length; j < jLen ; ++j) {
        if ( gdjs.PlayScene2Code.GDBigAsteroidObjects4_1final.indexOf(gdjs.PlayScene2Code.GDBigAsteroidObjects5[j]) === -1 )
            gdjs.PlayScene2Code.GDBigAsteroidObjects4_1final.push(gdjs.PlayScene2Code.GDBigAsteroidObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.PlayScene2Code.GDEnemyBulletObjects5.length; j < jLen ; ++j) {
        if ( gdjs.PlayScene2Code.GDEnemyBulletObjects4_1final.indexOf(gdjs.PlayScene2Code.GDEnemyBulletObjects5[j]) === -1 )
            gdjs.PlayScene2Code.GDEnemyBulletObjects4_1final.push(gdjs.PlayScene2Code.GDEnemyBulletObjects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.PlayScene2Code.GDBigAsteroidObjects4_1final, gdjs.PlayScene2Code.GDBigAsteroidObjects4);
gdjs.copyArray(gdjs.PlayScene2Code.GDBulletObjects4_1final, gdjs.PlayScene2Code.GDBulletObjects4);
gdjs.copyArray(gdjs.PlayScene2Code.GDEnemyBulletObjects4_1final, gdjs.PlayScene2Code.GDEnemyBulletObjects4);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Explosion.wav", false, 60, gdjs.randomFloatInRange(0.9, 1));
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDDebrisHugeObjects4Objects, (( gdjs.PlayScene2Code.GDBigAsteroidObjects4.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDBigAsteroidObjects4[0].getPointX("")), (( gdjs.PlayScene2Code.GDBigAsteroidObjects4.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDBigAsteroidObjects4[0].getPointY("")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDBulletHitObjects4Objects, (( gdjs.PlayScene2Code.GDBulletObjects4.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDBulletObjects4[0].getPointX("BulletHit")), (( gdjs.PlayScene2Code.GDBulletObjects4.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDBulletObjects4[0].getPointY("BulletHit")), "");
}{for(var i = 0, len = gdjs.PlayScene2Code.GDBigAsteroidObjects4.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDBigAsteroidObjects4[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.PlayScene2Code.GDEnemyBulletObjects4.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDEnemyBulletObjects4[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.PlayScene2Code.GDBulletObjects4.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDBulletObjects4[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents: 
gdjs.PlayScene2Code.eventsList14(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("MediumAsteroid"), gdjs.PlayScene2Code.GDMediumAsteroidObjects3);

for (gdjs.PlayScene2Code.forEachIndex4 = 0;gdjs.PlayScene2Code.forEachIndex4 < gdjs.PlayScene2Code.GDMediumAsteroidObjects3.length;++gdjs.PlayScene2Code.forEachIndex4) {
gdjs.PlayScene2Code.GDBulletObjects4.length = 0;

gdjs.PlayScene2Code.GDBulletHitObjects4.length = 0;

gdjs.PlayScene2Code.GDDebrisMediumObjects4.length = 0;

gdjs.PlayScene2Code.GDEnemyBulletObjects4.length = 0;

gdjs.PlayScene2Code.GDMediumAsteroidObjects4.length = 0;


gdjs.PlayScene2Code.forEachTemporary4 = gdjs.PlayScene2Code.GDMediumAsteroidObjects3[gdjs.PlayScene2Code.forEachIndex4];
gdjs.PlayScene2Code.GDMediumAsteroidObjects4.push(gdjs.PlayScene2Code.forEachTemporary4);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.PlayScene2Code.GDBulletObjects4_1final.length = 0;
gdjs.PlayScene2Code.GDEnemyBulletObjects4_1final.length = 0;
gdjs.PlayScene2Code.GDMediumAsteroidObjects4_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.PlayScene2Code.GDBulletObjects5);
gdjs.copyArray(gdjs.PlayScene2Code.GDMediumAsteroidObjects4, gdjs.PlayScene2Code.GDMediumAsteroidObjects5);

isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDBulletObjects5Objects, gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDMediumAsteroidObjects5Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PlayScene2Code.GDBulletObjects5.length; j < jLen ; ++j) {
        if ( gdjs.PlayScene2Code.GDBulletObjects4_1final.indexOf(gdjs.PlayScene2Code.GDBulletObjects5[j]) === -1 )
            gdjs.PlayScene2Code.GDBulletObjects4_1final.push(gdjs.PlayScene2Code.GDBulletObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.PlayScene2Code.GDMediumAsteroidObjects5.length; j < jLen ; ++j) {
        if ( gdjs.PlayScene2Code.GDMediumAsteroidObjects4_1final.indexOf(gdjs.PlayScene2Code.GDMediumAsteroidObjects5[j]) === -1 )
            gdjs.PlayScene2Code.GDMediumAsteroidObjects4_1final.push(gdjs.PlayScene2Code.GDMediumAsteroidObjects5[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("EnemyBullet"), gdjs.PlayScene2Code.GDEnemyBulletObjects5);
gdjs.copyArray(gdjs.PlayScene2Code.GDMediumAsteroidObjects4, gdjs.PlayScene2Code.GDMediumAsteroidObjects5);

isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDEnemyBulletObjects5Objects, gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDMediumAsteroidObjects5Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PlayScene2Code.GDEnemyBulletObjects5.length; j < jLen ; ++j) {
        if ( gdjs.PlayScene2Code.GDEnemyBulletObjects4_1final.indexOf(gdjs.PlayScene2Code.GDEnemyBulletObjects5[j]) === -1 )
            gdjs.PlayScene2Code.GDEnemyBulletObjects4_1final.push(gdjs.PlayScene2Code.GDEnemyBulletObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.PlayScene2Code.GDMediumAsteroidObjects5.length; j < jLen ; ++j) {
        if ( gdjs.PlayScene2Code.GDMediumAsteroidObjects4_1final.indexOf(gdjs.PlayScene2Code.GDMediumAsteroidObjects5[j]) === -1 )
            gdjs.PlayScene2Code.GDMediumAsteroidObjects4_1final.push(gdjs.PlayScene2Code.GDMediumAsteroidObjects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.PlayScene2Code.GDBulletObjects4_1final, gdjs.PlayScene2Code.GDBulletObjects4);
gdjs.copyArray(gdjs.PlayScene2Code.GDEnemyBulletObjects4_1final, gdjs.PlayScene2Code.GDEnemyBulletObjects4);
gdjs.copyArray(gdjs.PlayScene2Code.GDMediumAsteroidObjects4_1final, gdjs.PlayScene2Code.GDMediumAsteroidObjects4);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Explosion.wav", false, 55, gdjs.randomFloatInRange(1, 1.1));
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDDebrisMediumObjects4Objects, (( gdjs.PlayScene2Code.GDMediumAsteroidObjects4.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDMediumAsteroidObjects4[0].getPointX("")), (( gdjs.PlayScene2Code.GDMediumAsteroidObjects4.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDMediumAsteroidObjects4[0].getPointY("")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDBulletHitObjects4Objects, (( gdjs.PlayScene2Code.GDBulletObjects4.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDBulletObjects4[0].getPointX("BulletHit")), (( gdjs.PlayScene2Code.GDBulletObjects4.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDBulletObjects4[0].getPointY("BulletHit")), "");
}{for(var i = 0, len = gdjs.PlayScene2Code.GDMediumAsteroidObjects4.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDMediumAsteroidObjects4[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.PlayScene2Code.GDBulletObjects4.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDBulletObjects4[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.PlayScene2Code.GDEnemyBulletObjects4.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDEnemyBulletObjects4[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents: 
gdjs.PlayScene2Code.eventsList15(runtimeScene);} //Subevents end.
}
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("SmallAsteroid"), gdjs.PlayScene2Code.GDSmallAsteroidObjects2);

for (gdjs.PlayScene2Code.forEachIndex3 = 0;gdjs.PlayScene2Code.forEachIndex3 < gdjs.PlayScene2Code.GDSmallAsteroidObjects2.length;++gdjs.PlayScene2Code.forEachIndex3) {
gdjs.PlayScene2Code.GDBulletObjects3.length = 0;

gdjs.PlayScene2Code.GDBulletHitObjects3.length = 0;

gdjs.PlayScene2Code.GDDebrisSmallObjects3.length = 0;

gdjs.PlayScene2Code.GDEnemyBulletObjects3.length = 0;

gdjs.PlayScene2Code.GDSmallAsteroidObjects3.length = 0;


gdjs.PlayScene2Code.forEachTemporary3 = gdjs.PlayScene2Code.GDSmallAsteroidObjects2[gdjs.PlayScene2Code.forEachIndex3];
gdjs.PlayScene2Code.GDSmallAsteroidObjects3.push(gdjs.PlayScene2Code.forEachTemporary3);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.PlayScene2Code.GDBulletObjects3_1final.length = 0;
gdjs.PlayScene2Code.GDEnemyBulletObjects3_1final.length = 0;
gdjs.PlayScene2Code.GDSmallAsteroidObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.PlayScene2Code.GDBulletObjects4);
gdjs.copyArray(gdjs.PlayScene2Code.GDSmallAsteroidObjects3, gdjs.PlayScene2Code.GDSmallAsteroidObjects4);

isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDBulletObjects4Objects, gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDSmallAsteroidObjects4Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PlayScene2Code.GDBulletObjects4.length; j < jLen ; ++j) {
        if ( gdjs.PlayScene2Code.GDBulletObjects3_1final.indexOf(gdjs.PlayScene2Code.GDBulletObjects4[j]) === -1 )
            gdjs.PlayScene2Code.GDBulletObjects3_1final.push(gdjs.PlayScene2Code.GDBulletObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.PlayScene2Code.GDSmallAsteroidObjects4.length; j < jLen ; ++j) {
        if ( gdjs.PlayScene2Code.GDSmallAsteroidObjects3_1final.indexOf(gdjs.PlayScene2Code.GDSmallAsteroidObjects4[j]) === -1 )
            gdjs.PlayScene2Code.GDSmallAsteroidObjects3_1final.push(gdjs.PlayScene2Code.GDSmallAsteroidObjects4[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("EnemyBullet"), gdjs.PlayScene2Code.GDEnemyBulletObjects4);
gdjs.copyArray(gdjs.PlayScene2Code.GDSmallAsteroidObjects3, gdjs.PlayScene2Code.GDSmallAsteroidObjects4);

isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDEnemyBulletObjects4Objects, gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDSmallAsteroidObjects4Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PlayScene2Code.GDEnemyBulletObjects4.length; j < jLen ; ++j) {
        if ( gdjs.PlayScene2Code.GDEnemyBulletObjects3_1final.indexOf(gdjs.PlayScene2Code.GDEnemyBulletObjects4[j]) === -1 )
            gdjs.PlayScene2Code.GDEnemyBulletObjects3_1final.push(gdjs.PlayScene2Code.GDEnemyBulletObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.PlayScene2Code.GDSmallAsteroidObjects4.length; j < jLen ; ++j) {
        if ( gdjs.PlayScene2Code.GDSmallAsteroidObjects3_1final.indexOf(gdjs.PlayScene2Code.GDSmallAsteroidObjects4[j]) === -1 )
            gdjs.PlayScene2Code.GDSmallAsteroidObjects3_1final.push(gdjs.PlayScene2Code.GDSmallAsteroidObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.PlayScene2Code.GDBulletObjects3_1final, gdjs.PlayScene2Code.GDBulletObjects3);
gdjs.copyArray(gdjs.PlayScene2Code.GDEnemyBulletObjects3_1final, gdjs.PlayScene2Code.GDEnemyBulletObjects3);
gdjs.copyArray(gdjs.PlayScene2Code.GDSmallAsteroidObjects3_1final, gdjs.PlayScene2Code.GDSmallAsteroidObjects3);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Explosion.wav", false, 50, gdjs.randomFloatInRange(1.1, 1.2));
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDDebrisSmallObjects3Objects, (( gdjs.PlayScene2Code.GDSmallAsteroidObjects3.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDSmallAsteroidObjects3[0].getPointX("")), (( gdjs.PlayScene2Code.GDSmallAsteroidObjects3.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDSmallAsteroidObjects3[0].getPointY("")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDBulletHitObjects3Objects, (( gdjs.PlayScene2Code.GDBulletObjects3.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDBulletObjects3[0].getPointX("BulletHit")), (( gdjs.PlayScene2Code.GDBulletObjects3.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDBulletObjects3[0].getPointY("BulletHit")), "");
}{for(var i = 0, len = gdjs.PlayScene2Code.GDSmallAsteroidObjects3.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDSmallAsteroidObjects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.PlayScene2Code.GDEnemyBulletObjects3.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDEnemyBulletObjects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.PlayScene2Code.GDBulletObjects3.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDBulletObjects3[i].deleteFromScene(runtimeScene);
}
}}
}

}


};gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.PlayScene2Code.GDPlayerObjects2});
gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDBigAsteroidObjects2ObjectsGDgdjs_9546PlayScene2Code_9546GDMediumAsteroidObjects2ObjectsGDgdjs_9546PlayScene2Code_9546GDSmallAsteroidObjects2Objects = Hashtable.newFrom({"BigAsteroid": gdjs.PlayScene2Code.GDBigAsteroidObjects2, "MediumAsteroid": gdjs.PlayScene2Code.GDMediumAsteroidObjects2, "SmallAsteroid": gdjs.PlayScene2Code.GDSmallAsteroidObjects2});
gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDEnemyBulletObjects2Objects = Hashtable.newFrom({"EnemyBullet": gdjs.PlayScene2Code.GDEnemyBulletObjects2});
gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.PlayScene2Code.GDPlayerObjects2});
gdjs.PlayScene2Code.eventsList18 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtsExt__CameraShake__SetLayerTranslationAmplitude.func(runtimeScene, 1, 1, "", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__CameraShake__SetLayerRotationAmplitude.func(runtimeScene, 1, "", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__CameraShake__SetLayerZoomAmplitude.func(runtimeScene, 1.01, "", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__CameraShake__SetDefaultShakingFrequency.func(runtimeScene, 10, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("BigAsteroid"), gdjs.PlayScene2Code.GDBigAsteroidObjects2);
gdjs.copyArray(runtimeScene.getObjects("MediumAsteroid"), gdjs.PlayScene2Code.GDMediumAsteroidObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PlayScene2Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("SmallAsteroid"), gdjs.PlayScene2Code.GDSmallAsteroidObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.physics2.objectsCollide(gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDPlayerObjects2Objects, "Physics2", gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDBigAsteroidObjects2ObjectsGDgdjs_9546PlayScene2Code_9546GDMediumAsteroidObjects2ObjectsGDgdjs_9546PlayScene2Code_9546GDSmallAsteroidObjects2Objects, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("LifeBar"), gdjs.PlayScene2Code.GDLifeBarObjects2);
/* Reuse gdjs.PlayScene2Code.GDPlayerObjects2 */
{gdjs.evtTools.sound.playSound(runtimeScene, "Bump.wav", false, 60, gdjs.randomFloatInRange(0.9, 1.1));
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 1, 0, 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.PlayScene2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDPlayerObjects2[i].getBehavior("Flash").Flash(1.5, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.PlayScene2Code.GDLifeBarObjects2.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDLifeBarObjects2[i].getBehavior("Flash").Flash(1.5, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.PlayScene2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDPlayerObjects2[i].getBehavior("Health").Hit(1, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.PlayScene2Code.GDLifeBarObjects2.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDLifeBarObjects2[i].SetValue((( gdjs.PlayScene2Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDPlayerObjects2[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("EnemyBullet"), gdjs.PlayScene2Code.GDEnemyBulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PlayScene2Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDEnemyBulletObjects2Objects, gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDPlayerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.PlayScene2Code.GDEnemyBulletObjects2 */
gdjs.copyArray(runtimeScene.getObjects("LifeBar"), gdjs.PlayScene2Code.GDLifeBarObjects2);
/* Reuse gdjs.PlayScene2Code.GDPlayerObjects2 */
{gdjs.evtTools.sound.playSound(runtimeScene, "Hit 1.aac", false, 60, gdjs.randomFloatInRange(0.9, 1.1));
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 1, 0, 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.PlayScene2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDPlayerObjects2[i].getBehavior("Flash").Flash(1.5, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.PlayScene2Code.GDLifeBarObjects2.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDLifeBarObjects2[i].getBehavior("Flash").Flash(1.5, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.PlayScene2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDPlayerObjects2[i].getBehavior("Health").Hit(1, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.PlayScene2Code.GDLifeBarObjects2.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDLifeBarObjects2[i].SetValue((( gdjs.PlayScene2Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDPlayerObjects2[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.PlayScene2Code.GDEnemyBulletObjects2.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDEnemyBulletObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PlayScene2Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PlayScene2Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.PlayScene2Code.GDPlayerObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.PlayScene2Code.GDPlayerObjects1[k] = gdjs.PlayScene2Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.PlayScene2Code.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("MotionTrail"), gdjs.PlayScene2Code.GDMotionTrailObjects1);
{for(var i = 0, len = gdjs.PlayScene2Code.GDMotionTrailObjects1.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDMotionTrailObjects1[i].stopEmission();
}
}{runtimeScene.getScene().getVariables().get("State").setString("GameOverAnimation");
}}

}


};gdjs.PlayScene2Code.eventsList19 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("TimeText"), gdjs.PlayScene2Code.GDTimeTextObjects2);
{for(var i = 0, len = gdjs.PlayScene2Code.GDTimeTextObjects2.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDTimeTextObjects2[i].getBehavior("Text").setText("Time:" + gdjs.evtsExt__TimeFormatter__SecondsToHHMMSS000.func(runtimeScene, gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSeconds(runtimeScene, "Timer"), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
}}

}


{


gdjs.PlayScene2Code.eventsList3(runtimeScene);
}


{


gdjs.PlayScene2Code.eventsList4(runtimeScene);
}


{


gdjs.PlayScene2Code.eventsList5(runtimeScene);
}


{


gdjs.PlayScene2Code.eventsList8(runtimeScene);
}


{


gdjs.PlayScene2Code.eventsList11(runtimeScene);
}


{


gdjs.PlayScene2Code.eventsList13(runtimeScene);
}


{


gdjs.PlayScene2Code.eventsList17(runtimeScene);
}


{


gdjs.PlayScene2Code.eventsList18(runtimeScene);
}


};gdjs.PlayScene2Code.eventsList20 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("State")) == "GamePlaying";
if (isConditionTrue_0) {

{ //Subevents
gdjs.PlayScene2Code.eventsList19(runtimeScene);} //End of subevents
}

}


};gdjs.PlayScene2Code.eventsList21 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15976660);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "Menu", 0, 0, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ContinueButton"), gdjs.PlayScene2Code.GDContinueButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PlayScene2Code.GDContinueButtonObjects1.length;i<l;++i) {
    if ( gdjs.PlayScene2Code.GDContinueButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.PlayScene2Code.GDContinueButtonObjects1[k] = gdjs.PlayScene2Code.GDContinueButtonObjects1[i];
        ++k;
    }
}
gdjs.PlayScene2Code.GDContinueButtonObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.PlayScene2Code.GDContinueButtonObjects1 */
gdjs.copyArray(runtimeScene.getObjects("MenuText"), gdjs.PlayScene2Code.GDMenuTextObjects1);
{runtimeScene.getScene().getVariables().get("State").setString("GamePlaying");
}{gdjs.evtTools.runtimeScene.unpauseTimer(runtimeScene, "Timer");
}{for(var i = 0, len = gdjs.PlayScene2Code.GDMenuTextObjects1.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDMenuTextObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.PlayScene2Code.GDContinueButtonObjects1.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDContinueButtonObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.PlayScene2Code.eventsList22 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().get("State").setString("MenuAnimation");
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "Timer");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("State")) == "MenuAnimation";
if (isConditionTrue_0) {

{ //Subevents
gdjs.PlayScene2Code.eventsList21(runtimeScene);} //End of subevents
}

}


};gdjs.PlayScene2Code.mapOfEmptyGDBigAsteroidObjectsEmptyGDMediumAsteroidObjectsEmptyGDSmallAsteroidObjects = Hashtable.newFrom({"BigAsteroid": [], "MediumAsteroid": [], "SmallAsteroid": []});
gdjs.PlayScene2Code.mapOfEmptyGDEnemyObjects = Hashtable.newFrom({"Enemy": []});
gdjs.PlayScene2Code.mapOfEmptyGDEnemyGreenObjects = Hashtable.newFrom({"EnemyGreen": []});
gdjs.PlayScene2Code.asyncCallback15982524 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("ContinueButton"), gdjs.PlayScene2Code.GDContinueButtonObjects3);

{for(var i = 0, len = gdjs.PlayScene2Code.GDContinueButtonObjects3.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDContinueButtonObjects3[i].hide(false);
}
}{runtimeScene.getScene().getVariables().get("State").setString("NextLevelContinue");
}}
gdjs.PlayScene2Code.eventsList23 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.PlayScene2Code.GDContinueButtonObjects2) asyncObjectsList.addObject("ContinueButton", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.PlayScene2Code.asyncCallback15982524(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.PlayScene2Code.eventsList24 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15981596);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "NextLevel", 0, 0, 0);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15982284);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ContinueButton"), gdjs.PlayScene2Code.GDContinueButtonObjects2);
{for(var i = 0, len = gdjs.PlayScene2Code.GDContinueButtonObjects2.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDContinueButtonObjects2[i].hide();
}
}
{ //Subevents
gdjs.PlayScene2Code.eventsList23(runtimeScene);} //End of subevents
}

}


};gdjs.PlayScene2Code.eventsList25 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene2Code.mapOfEmptyGDBigAsteroidObjectsEmptyGDMediumAsteroidObjectsEmptyGDSmallAsteroidObjects) == 0;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene2Code.mapOfEmptyGDEnemyObjects) == 0;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene2Code.mapOfEmptyGDEnemyGreenObjects) == 0;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TutorialText"), gdjs.PlayScene2Code.GDTutorialTextObjects2);
{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "EnemyTimer");
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "UFOTimer");
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "Timer");
}{runtimeScene.getGame().getVariables().getFromIndex(1).setString(gdjs.evtsExt__TimeFormatter__SecondsToHHMMSS000.func(runtimeScene, gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSeconds(runtimeScene, "Timer"), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}{for(var i = 0, len = gdjs.PlayScene2Code.GDTutorialTextObjects2.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDTutorialTextObjects2[i].hide();
}
}{runtimeScene.getScene().getVariables().get("State").setString("NextLevelScreen");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("State")) == "NextLevelScreen";
if (isConditionTrue_0) {

{ //Subevents
gdjs.PlayScene2Code.eventsList24(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("State")) == "NextLevelContinue";
if (isConditionTrue_0) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("ContinueButton"), gdjs.PlayScene2Code.GDContinueButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PlayScene2Code.GDContinueButtonObjects1.length;i<l;++i) {
    if ( gdjs.PlayScene2Code.GDContinueButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.PlayScene2Code.GDContinueButtonObjects1[k] = gdjs.PlayScene2Code.GDContinueButtonObjects1[i];
        ++k;
    }
}
gdjs.PlayScene2Code.GDContinueButtonObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "PlayScene3", false);
}}

}


};gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDDeathShipParticleObjects3Objects = Hashtable.newFrom({"DeathShipParticle": gdjs.PlayScene2Code.GDDeathShipParticleObjects3});
gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDDeathDebrisParticleObjects3Objects = Hashtable.newFrom({"DeathDebrisParticle": gdjs.PlayScene2Code.GDDeathDebrisParticleObjects3});
gdjs.PlayScene2Code.asyncCallback15987948 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("ContinueText"), gdjs.PlayScene2Code.GDContinueTextObjects3);

{for(var i = 0, len = gdjs.PlayScene2Code.GDContinueTextObjects3.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDContinueTextObjects3[i].hide(false);
}
}{runtimeScene.getScene().getVariables().get("State").setString("GameOverWaitKey");
}}
gdjs.PlayScene2Code.eventsList26 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.PlayScene2Code.GDContinueTextObjects2) asyncObjectsList.addObject("ContinueText", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.PlayScene2Code.asyncCallback15987948(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.PlayScene2Code.eventsList27 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15985420);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PlayScene2Code.GDPlayerObjects3);
gdjs.PlayScene2Code.GDDeathDebrisParticleObjects3.length = 0;

gdjs.PlayScene2Code.GDDeathShipParticleObjects3.length = 0;

{gdjs.evtTools.sound.playSound(runtimeScene, "Death.wav", false, 50, 1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDDeathShipParticleObjects3Objects, (( gdjs.PlayScene2Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDPlayerObjects3[0].getPointX("")), (( gdjs.PlayScene2Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDPlayerObjects3[0].getPointY("")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene2Code.mapOfGDgdjs_9546PlayScene2Code_9546GDDeathDebrisParticleObjects3Objects, (( gdjs.PlayScene2Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDPlayerObjects3[0].getPointX("")), (( gdjs.PlayScene2Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDPlayerObjects3[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.PlayScene2Code.GDDeathShipParticleObjects3.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDDeathShipParticleObjects3[i].setAngle((( gdjs.PlayScene2Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.PlayScene2Code.GDPlayerObjects3[0].getAngle()));
}
}{for(var i = 0, len = gdjs.PlayScene2Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDPlayerObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15986932);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "GameOver", 0, 0, 0);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15987068);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ContinueText"), gdjs.PlayScene2Code.GDContinueTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("TutorialText"), gdjs.PlayScene2Code.GDTutorialTextObjects2);
{for(var i = 0, len = gdjs.PlayScene2Code.GDTutorialTextObjects2.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDTutorialTextObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.PlayScene2Code.GDContinueTextObjects2.length ;i < len;++i) {
    gdjs.PlayScene2Code.GDContinueTextObjects2[i].hide();
}
}
{ //Subevents
gdjs.PlayScene2Code.eventsList26(runtimeScene);} //End of subevents
}

}


};gdjs.PlayScene2Code.eventsList28 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.anyKeyReleased(runtimeScene);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "TitleScene", false);
}}

}


};gdjs.PlayScene2Code.eventsList29 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("State")) == "GameOverAnimation";
if (isConditionTrue_0) {

{ //Subevents
gdjs.PlayScene2Code.eventsList27(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("State")) == "GameOverWaitKey";
if (isConditionTrue_0) {

{ //Subevents
gdjs.PlayScene2Code.eventsList28(runtimeScene);} //End of subevents
}

}


};gdjs.PlayScene2Code.eventsList30 = function(runtimeScene) {

{



}


{


gdjs.PlayScene2Code.eventsList2(runtimeScene);
}


{


gdjs.PlayScene2Code.eventsList20(runtimeScene);
}


{


gdjs.PlayScene2Code.eventsList22(runtimeScene);
}


{


gdjs.PlayScene2Code.eventsList25(runtimeScene);
}


{


gdjs.PlayScene2Code.eventsList29(runtimeScene);
}


};

gdjs.PlayScene2Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.PlayScene2Code.GDPlayerObjects1.length = 0;
gdjs.PlayScene2Code.GDPlayerObjects2.length = 0;
gdjs.PlayScene2Code.GDPlayerObjects3.length = 0;
gdjs.PlayScene2Code.GDPlayerObjects4.length = 0;
gdjs.PlayScene2Code.GDPlayerObjects5.length = 0;
gdjs.PlayScene2Code.GDPlayerObjects6.length = 0;
gdjs.PlayScene2Code.GDBulletObjects1.length = 0;
gdjs.PlayScene2Code.GDBulletObjects2.length = 0;
gdjs.PlayScene2Code.GDBulletObjects3.length = 0;
gdjs.PlayScene2Code.GDBulletObjects4.length = 0;
gdjs.PlayScene2Code.GDBulletObjects5.length = 0;
gdjs.PlayScene2Code.GDBulletObjects6.length = 0;
gdjs.PlayScene2Code.GDBigAsteroidObjects1.length = 0;
gdjs.PlayScene2Code.GDBigAsteroidObjects2.length = 0;
gdjs.PlayScene2Code.GDBigAsteroidObjects3.length = 0;
gdjs.PlayScene2Code.GDBigAsteroidObjects4.length = 0;
gdjs.PlayScene2Code.GDBigAsteroidObjects5.length = 0;
gdjs.PlayScene2Code.GDBigAsteroidObjects6.length = 0;
gdjs.PlayScene2Code.GDMediumAsteroidObjects1.length = 0;
gdjs.PlayScene2Code.GDMediumAsteroidObjects2.length = 0;
gdjs.PlayScene2Code.GDMediumAsteroidObjects3.length = 0;
gdjs.PlayScene2Code.GDMediumAsteroidObjects4.length = 0;
gdjs.PlayScene2Code.GDMediumAsteroidObjects5.length = 0;
gdjs.PlayScene2Code.GDMediumAsteroidObjects6.length = 0;
gdjs.PlayScene2Code.GDSmallAsteroidObjects1.length = 0;
gdjs.PlayScene2Code.GDSmallAsteroidObjects2.length = 0;
gdjs.PlayScene2Code.GDSmallAsteroidObjects3.length = 0;
gdjs.PlayScene2Code.GDSmallAsteroidObjects4.length = 0;
gdjs.PlayScene2Code.GDSmallAsteroidObjects5.length = 0;
gdjs.PlayScene2Code.GDSmallAsteroidObjects6.length = 0;
gdjs.PlayScene2Code.GDLifeBarObjects1.length = 0;
gdjs.PlayScene2Code.GDLifeBarObjects2.length = 0;
gdjs.PlayScene2Code.GDLifeBarObjects3.length = 0;
gdjs.PlayScene2Code.GDLifeBarObjects4.length = 0;
gdjs.PlayScene2Code.GDLifeBarObjects5.length = 0;
gdjs.PlayScene2Code.GDLifeBarObjects6.length = 0;
gdjs.PlayScene2Code.GDGameOverObjects1.length = 0;
gdjs.PlayScene2Code.GDGameOverObjects2.length = 0;
gdjs.PlayScene2Code.GDGameOverObjects3.length = 0;
gdjs.PlayScene2Code.GDGameOverObjects4.length = 0;
gdjs.PlayScene2Code.GDGameOverObjects5.length = 0;
gdjs.PlayScene2Code.GDGameOverObjects6.length = 0;
gdjs.PlayScene2Code.GDDeathShipParticleObjects1.length = 0;
gdjs.PlayScene2Code.GDDeathShipParticleObjects2.length = 0;
gdjs.PlayScene2Code.GDDeathShipParticleObjects3.length = 0;
gdjs.PlayScene2Code.GDDeathShipParticleObjects4.length = 0;
gdjs.PlayScene2Code.GDDeathShipParticleObjects5.length = 0;
gdjs.PlayScene2Code.GDDeathShipParticleObjects6.length = 0;
gdjs.PlayScene2Code.GDDeathDebrisParticleObjects1.length = 0;
gdjs.PlayScene2Code.GDDeathDebrisParticleObjects2.length = 0;
gdjs.PlayScene2Code.GDDeathDebrisParticleObjects3.length = 0;
gdjs.PlayScene2Code.GDDeathDebrisParticleObjects4.length = 0;
gdjs.PlayScene2Code.GDDeathDebrisParticleObjects5.length = 0;
gdjs.PlayScene2Code.GDDeathDebrisParticleObjects6.length = 0;
gdjs.PlayScene2Code.GDDebrisHugeObjects1.length = 0;
gdjs.PlayScene2Code.GDDebrisHugeObjects2.length = 0;
gdjs.PlayScene2Code.GDDebrisHugeObjects3.length = 0;
gdjs.PlayScene2Code.GDDebrisHugeObjects4.length = 0;
gdjs.PlayScene2Code.GDDebrisHugeObjects5.length = 0;
gdjs.PlayScene2Code.GDDebrisHugeObjects6.length = 0;
gdjs.PlayScene2Code.GDDebrisMediumObjects1.length = 0;
gdjs.PlayScene2Code.GDDebrisMediumObjects2.length = 0;
gdjs.PlayScene2Code.GDDebrisMediumObjects3.length = 0;
gdjs.PlayScene2Code.GDDebrisMediumObjects4.length = 0;
gdjs.PlayScene2Code.GDDebrisMediumObjects5.length = 0;
gdjs.PlayScene2Code.GDDebrisMediumObjects6.length = 0;
gdjs.PlayScene2Code.GDDebrisSmallObjects1.length = 0;
gdjs.PlayScene2Code.GDDebrisSmallObjects2.length = 0;
gdjs.PlayScene2Code.GDDebrisSmallObjects3.length = 0;
gdjs.PlayScene2Code.GDDebrisSmallObjects4.length = 0;
gdjs.PlayScene2Code.GDDebrisSmallObjects5.length = 0;
gdjs.PlayScene2Code.GDDebrisSmallObjects6.length = 0;
gdjs.PlayScene2Code.GDBulletHitObjects1.length = 0;
gdjs.PlayScene2Code.GDBulletHitObjects2.length = 0;
gdjs.PlayScene2Code.GDBulletHitObjects3.length = 0;
gdjs.PlayScene2Code.GDBulletHitObjects4.length = 0;
gdjs.PlayScene2Code.GDBulletHitObjects5.length = 0;
gdjs.PlayScene2Code.GDBulletHitObjects6.length = 0;
gdjs.PlayScene2Code.GDBulletFlashObjects1.length = 0;
gdjs.PlayScene2Code.GDBulletFlashObjects2.length = 0;
gdjs.PlayScene2Code.GDBulletFlashObjects3.length = 0;
gdjs.PlayScene2Code.GDBulletFlashObjects4.length = 0;
gdjs.PlayScene2Code.GDBulletFlashObjects5.length = 0;
gdjs.PlayScene2Code.GDBulletFlashObjects6.length = 0;
gdjs.PlayScene2Code.GDStarBackgroundObjects1.length = 0;
gdjs.PlayScene2Code.GDStarBackgroundObjects2.length = 0;
gdjs.PlayScene2Code.GDStarBackgroundObjects3.length = 0;
gdjs.PlayScene2Code.GDStarBackgroundObjects4.length = 0;
gdjs.PlayScene2Code.GDStarBackgroundObjects5.length = 0;
gdjs.PlayScene2Code.GDStarBackgroundObjects6.length = 0;
gdjs.PlayScene2Code.GDMotionTrailObjects1.length = 0;
gdjs.PlayScene2Code.GDMotionTrailObjects2.length = 0;
gdjs.PlayScene2Code.GDMotionTrailObjects3.length = 0;
gdjs.PlayScene2Code.GDMotionTrailObjects4.length = 0;
gdjs.PlayScene2Code.GDMotionTrailObjects5.length = 0;
gdjs.PlayScene2Code.GDMotionTrailObjects6.length = 0;
gdjs.PlayScene2Code.GDTutorialTextObjects1.length = 0;
gdjs.PlayScene2Code.GDTutorialTextObjects2.length = 0;
gdjs.PlayScene2Code.GDTutorialTextObjects3.length = 0;
gdjs.PlayScene2Code.GDTutorialTextObjects4.length = 0;
gdjs.PlayScene2Code.GDTutorialTextObjects5.length = 0;
gdjs.PlayScene2Code.GDTutorialTextObjects6.length = 0;
gdjs.PlayScene2Code.GDContinueTextObjects1.length = 0;
gdjs.PlayScene2Code.GDContinueTextObjects2.length = 0;
gdjs.PlayScene2Code.GDContinueTextObjects3.length = 0;
gdjs.PlayScene2Code.GDContinueTextObjects4.length = 0;
gdjs.PlayScene2Code.GDContinueTextObjects5.length = 0;
gdjs.PlayScene2Code.GDContinueTextObjects6.length = 0;
gdjs.PlayScene2Code.GDRightButtonObjects1.length = 0;
gdjs.PlayScene2Code.GDRightButtonObjects2.length = 0;
gdjs.PlayScene2Code.GDRightButtonObjects3.length = 0;
gdjs.PlayScene2Code.GDRightButtonObjects4.length = 0;
gdjs.PlayScene2Code.GDRightButtonObjects5.length = 0;
gdjs.PlayScene2Code.GDRightButtonObjects6.length = 0;
gdjs.PlayScene2Code.GDLeftButtonObjects1.length = 0;
gdjs.PlayScene2Code.GDLeftButtonObjects2.length = 0;
gdjs.PlayScene2Code.GDLeftButtonObjects3.length = 0;
gdjs.PlayScene2Code.GDLeftButtonObjects4.length = 0;
gdjs.PlayScene2Code.GDLeftButtonObjects5.length = 0;
gdjs.PlayScene2Code.GDLeftButtonObjects6.length = 0;
gdjs.PlayScene2Code.GDTopButtonObjects1.length = 0;
gdjs.PlayScene2Code.GDTopButtonObjects2.length = 0;
gdjs.PlayScene2Code.GDTopButtonObjects3.length = 0;
gdjs.PlayScene2Code.GDTopButtonObjects4.length = 0;
gdjs.PlayScene2Code.GDTopButtonObjects5.length = 0;
gdjs.PlayScene2Code.GDTopButtonObjects6.length = 0;
gdjs.PlayScene2Code.GDFireButtonObjects1.length = 0;
gdjs.PlayScene2Code.GDFireButtonObjects2.length = 0;
gdjs.PlayScene2Code.GDFireButtonObjects3.length = 0;
gdjs.PlayScene2Code.GDFireButtonObjects4.length = 0;
gdjs.PlayScene2Code.GDFireButtonObjects5.length = 0;
gdjs.PlayScene2Code.GDFireButtonObjects6.length = 0;
gdjs.PlayScene2Code.GDEnemyBulletObjects1.length = 0;
gdjs.PlayScene2Code.GDEnemyBulletObjects2.length = 0;
gdjs.PlayScene2Code.GDEnemyBulletObjects3.length = 0;
gdjs.PlayScene2Code.GDEnemyBulletObjects4.length = 0;
gdjs.PlayScene2Code.GDEnemyBulletObjects5.length = 0;
gdjs.PlayScene2Code.GDEnemyBulletObjects6.length = 0;
gdjs.PlayScene2Code.GDEnemyObjects1.length = 0;
gdjs.PlayScene2Code.GDEnemyObjects2.length = 0;
gdjs.PlayScene2Code.GDEnemyObjects3.length = 0;
gdjs.PlayScene2Code.GDEnemyObjects4.length = 0;
gdjs.PlayScene2Code.GDEnemyObjects5.length = 0;
gdjs.PlayScene2Code.GDEnemyObjects6.length = 0;
gdjs.PlayScene2Code.GDTitleTextObjects1.length = 0;
gdjs.PlayScene2Code.GDTitleTextObjects2.length = 0;
gdjs.PlayScene2Code.GDTitleTextObjects3.length = 0;
gdjs.PlayScene2Code.GDTitleTextObjects4.length = 0;
gdjs.PlayScene2Code.GDTitleTextObjects5.length = 0;
gdjs.PlayScene2Code.GDTitleTextObjects6.length = 0;
gdjs.PlayScene2Code.GDHealthPowerObjects1.length = 0;
gdjs.PlayScene2Code.GDHealthPowerObjects2.length = 0;
gdjs.PlayScene2Code.GDHealthPowerObjects3.length = 0;
gdjs.PlayScene2Code.GDHealthPowerObjects4.length = 0;
gdjs.PlayScene2Code.GDHealthPowerObjects5.length = 0;
gdjs.PlayScene2Code.GDHealthPowerObjects6.length = 0;
gdjs.PlayScene2Code.GDNextLevelObjects1.length = 0;
gdjs.PlayScene2Code.GDNextLevelObjects2.length = 0;
gdjs.PlayScene2Code.GDNextLevelObjects3.length = 0;
gdjs.PlayScene2Code.GDNextLevelObjects4.length = 0;
gdjs.PlayScene2Code.GDNextLevelObjects5.length = 0;
gdjs.PlayScene2Code.GDNextLevelObjects6.length = 0;
gdjs.PlayScene2Code.GDDeathEnemyParticleObjects1.length = 0;
gdjs.PlayScene2Code.GDDeathEnemyParticleObjects2.length = 0;
gdjs.PlayScene2Code.GDDeathEnemyParticleObjects3.length = 0;
gdjs.PlayScene2Code.GDDeathEnemyParticleObjects4.length = 0;
gdjs.PlayScene2Code.GDDeathEnemyParticleObjects5.length = 0;
gdjs.PlayScene2Code.GDDeathEnemyParticleObjects6.length = 0;
gdjs.PlayScene2Code.GDMenuTextObjects1.length = 0;
gdjs.PlayScene2Code.GDMenuTextObjects2.length = 0;
gdjs.PlayScene2Code.GDMenuTextObjects3.length = 0;
gdjs.PlayScene2Code.GDMenuTextObjects4.length = 0;
gdjs.PlayScene2Code.GDMenuTextObjects5.length = 0;
gdjs.PlayScene2Code.GDMenuTextObjects6.length = 0;
gdjs.PlayScene2Code.GDContinueButtonObjects1.length = 0;
gdjs.PlayScene2Code.GDContinueButtonObjects2.length = 0;
gdjs.PlayScene2Code.GDContinueButtonObjects3.length = 0;
gdjs.PlayScene2Code.GDContinueButtonObjects4.length = 0;
gdjs.PlayScene2Code.GDContinueButtonObjects5.length = 0;
gdjs.PlayScene2Code.GDContinueButtonObjects6.length = 0;
gdjs.PlayScene2Code.GDEnemyGreenObjects1.length = 0;
gdjs.PlayScene2Code.GDEnemyGreenObjects2.length = 0;
gdjs.PlayScene2Code.GDEnemyGreenObjects3.length = 0;
gdjs.PlayScene2Code.GDEnemyGreenObjects4.length = 0;
gdjs.PlayScene2Code.GDEnemyGreenObjects5.length = 0;
gdjs.PlayScene2Code.GDEnemyGreenObjects6.length = 0;
gdjs.PlayScene2Code.GDDeathGreenEnemyParticleObjects1.length = 0;
gdjs.PlayScene2Code.GDDeathGreenEnemyParticleObjects2.length = 0;
gdjs.PlayScene2Code.GDDeathGreenEnemyParticleObjects3.length = 0;
gdjs.PlayScene2Code.GDDeathGreenEnemyParticleObjects4.length = 0;
gdjs.PlayScene2Code.GDDeathGreenEnemyParticleObjects5.length = 0;
gdjs.PlayScene2Code.GDDeathGreenEnemyParticleObjects6.length = 0;
gdjs.PlayScene2Code.GDTimeTextObjects1.length = 0;
gdjs.PlayScene2Code.GDTimeTextObjects2.length = 0;
gdjs.PlayScene2Code.GDTimeTextObjects3.length = 0;
gdjs.PlayScene2Code.GDTimeTextObjects4.length = 0;
gdjs.PlayScene2Code.GDTimeTextObjects5.length = 0;
gdjs.PlayScene2Code.GDTimeTextObjects6.length = 0;
gdjs.PlayScene2Code.GDTimeText2Objects1.length = 0;
gdjs.PlayScene2Code.GDTimeText2Objects2.length = 0;
gdjs.PlayScene2Code.GDTimeText2Objects3.length = 0;
gdjs.PlayScene2Code.GDTimeText2Objects4.length = 0;
gdjs.PlayScene2Code.GDTimeText2Objects5.length = 0;
gdjs.PlayScene2Code.GDTimeText2Objects6.length = 0;
gdjs.PlayScene2Code.GDTimeText3Objects1.length = 0;
gdjs.PlayScene2Code.GDTimeText3Objects2.length = 0;
gdjs.PlayScene2Code.GDTimeText3Objects3.length = 0;
gdjs.PlayScene2Code.GDTimeText3Objects4.length = 0;
gdjs.PlayScene2Code.GDTimeText3Objects5.length = 0;
gdjs.PlayScene2Code.GDTimeText3Objects6.length = 0;
gdjs.PlayScene2Code.GDTimeText4Objects1.length = 0;
gdjs.PlayScene2Code.GDTimeText4Objects2.length = 0;
gdjs.PlayScene2Code.GDTimeText4Objects3.length = 0;
gdjs.PlayScene2Code.GDTimeText4Objects4.length = 0;
gdjs.PlayScene2Code.GDTimeText4Objects5.length = 0;
gdjs.PlayScene2Code.GDTimeText4Objects6.length = 0;

gdjs.PlayScene2Code.eventsList30(runtimeScene);

return;

}

gdjs['PlayScene2Code'] = gdjs.PlayScene2Code;
