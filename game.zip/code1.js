gdjs.PlayScene3Code = {};
gdjs.PlayScene3Code.GDBigAsteroidObjects4_1final = [];

gdjs.PlayScene3Code.GDBulletObjects3_1final = [];

gdjs.PlayScene3Code.GDBulletObjects4_1final = [];

gdjs.PlayScene3Code.GDEnemyBulletObjects3_1final = [];

gdjs.PlayScene3Code.GDEnemyBulletObjects4_1final = [];

gdjs.PlayScene3Code.GDFireButtonObjects2_1final = [];

gdjs.PlayScene3Code.GDLeftButtonObjects3_1final = [];

gdjs.PlayScene3Code.GDMediumAsteroidObjects4_1final = [];

gdjs.PlayScene3Code.GDRightButtonObjects2_1final = [];

gdjs.PlayScene3Code.GDSmallAsteroidObjects3_1final = [];

gdjs.PlayScene3Code.GDTopButtonObjects2_1final = [];

gdjs.PlayScene3Code.GDTopButtonObjects3_1final = [];

gdjs.PlayScene3Code.forEachIndex3 = 0;

gdjs.PlayScene3Code.forEachIndex4 = 0;

gdjs.PlayScene3Code.forEachObjects3 = [];

gdjs.PlayScene3Code.forEachObjects4 = [];

gdjs.PlayScene3Code.forEachTemporary3 = null;

gdjs.PlayScene3Code.forEachTemporary4 = null;

gdjs.PlayScene3Code.forEachTotalCount3 = 0;

gdjs.PlayScene3Code.forEachTotalCount4 = 0;

gdjs.PlayScene3Code.GDPlayerObjects1= [];
gdjs.PlayScene3Code.GDPlayerObjects2= [];
gdjs.PlayScene3Code.GDPlayerObjects3= [];
gdjs.PlayScene3Code.GDPlayerObjects4= [];
gdjs.PlayScene3Code.GDPlayerObjects5= [];
gdjs.PlayScene3Code.GDPlayerObjects6= [];
gdjs.PlayScene3Code.GDBulletObjects1= [];
gdjs.PlayScene3Code.GDBulletObjects2= [];
gdjs.PlayScene3Code.GDBulletObjects3= [];
gdjs.PlayScene3Code.GDBulletObjects4= [];
gdjs.PlayScene3Code.GDBulletObjects5= [];
gdjs.PlayScene3Code.GDBulletObjects6= [];
gdjs.PlayScene3Code.GDBigAsteroidObjects1= [];
gdjs.PlayScene3Code.GDBigAsteroidObjects2= [];
gdjs.PlayScene3Code.GDBigAsteroidObjects3= [];
gdjs.PlayScene3Code.GDBigAsteroidObjects4= [];
gdjs.PlayScene3Code.GDBigAsteroidObjects5= [];
gdjs.PlayScene3Code.GDBigAsteroidObjects6= [];
gdjs.PlayScene3Code.GDMediumAsteroidObjects1= [];
gdjs.PlayScene3Code.GDMediumAsteroidObjects2= [];
gdjs.PlayScene3Code.GDMediumAsteroidObjects3= [];
gdjs.PlayScene3Code.GDMediumAsteroidObjects4= [];
gdjs.PlayScene3Code.GDMediumAsteroidObjects5= [];
gdjs.PlayScene3Code.GDMediumAsteroidObjects6= [];
gdjs.PlayScene3Code.GDSmallAsteroidObjects1= [];
gdjs.PlayScene3Code.GDSmallAsteroidObjects2= [];
gdjs.PlayScene3Code.GDSmallAsteroidObjects3= [];
gdjs.PlayScene3Code.GDSmallAsteroidObjects4= [];
gdjs.PlayScene3Code.GDSmallAsteroidObjects5= [];
gdjs.PlayScene3Code.GDSmallAsteroidObjects6= [];
gdjs.PlayScene3Code.GDLifeBarObjects1= [];
gdjs.PlayScene3Code.GDLifeBarObjects2= [];
gdjs.PlayScene3Code.GDLifeBarObjects3= [];
gdjs.PlayScene3Code.GDLifeBarObjects4= [];
gdjs.PlayScene3Code.GDLifeBarObjects5= [];
gdjs.PlayScene3Code.GDLifeBarObjects6= [];
gdjs.PlayScene3Code.GDGameOverObjects1= [];
gdjs.PlayScene3Code.GDGameOverObjects2= [];
gdjs.PlayScene3Code.GDGameOverObjects3= [];
gdjs.PlayScene3Code.GDGameOverObjects4= [];
gdjs.PlayScene3Code.GDGameOverObjects5= [];
gdjs.PlayScene3Code.GDGameOverObjects6= [];
gdjs.PlayScene3Code.GDDeathShipParticleObjects1= [];
gdjs.PlayScene3Code.GDDeathShipParticleObjects2= [];
gdjs.PlayScene3Code.GDDeathShipParticleObjects3= [];
gdjs.PlayScene3Code.GDDeathShipParticleObjects4= [];
gdjs.PlayScene3Code.GDDeathShipParticleObjects5= [];
gdjs.PlayScene3Code.GDDeathShipParticleObjects6= [];
gdjs.PlayScene3Code.GDDeathDebrisParticleObjects1= [];
gdjs.PlayScene3Code.GDDeathDebrisParticleObjects2= [];
gdjs.PlayScene3Code.GDDeathDebrisParticleObjects3= [];
gdjs.PlayScene3Code.GDDeathDebrisParticleObjects4= [];
gdjs.PlayScene3Code.GDDeathDebrisParticleObjects5= [];
gdjs.PlayScene3Code.GDDeathDebrisParticleObjects6= [];
gdjs.PlayScene3Code.GDDebrisHugeObjects1= [];
gdjs.PlayScene3Code.GDDebrisHugeObjects2= [];
gdjs.PlayScene3Code.GDDebrisHugeObjects3= [];
gdjs.PlayScene3Code.GDDebrisHugeObjects4= [];
gdjs.PlayScene3Code.GDDebrisHugeObjects5= [];
gdjs.PlayScene3Code.GDDebrisHugeObjects6= [];
gdjs.PlayScene3Code.GDDebrisMediumObjects1= [];
gdjs.PlayScene3Code.GDDebrisMediumObjects2= [];
gdjs.PlayScene3Code.GDDebrisMediumObjects3= [];
gdjs.PlayScene3Code.GDDebrisMediumObjects4= [];
gdjs.PlayScene3Code.GDDebrisMediumObjects5= [];
gdjs.PlayScene3Code.GDDebrisMediumObjects6= [];
gdjs.PlayScene3Code.GDDebrisSmallObjects1= [];
gdjs.PlayScene3Code.GDDebrisSmallObjects2= [];
gdjs.PlayScene3Code.GDDebrisSmallObjects3= [];
gdjs.PlayScene3Code.GDDebrisSmallObjects4= [];
gdjs.PlayScene3Code.GDDebrisSmallObjects5= [];
gdjs.PlayScene3Code.GDDebrisSmallObjects6= [];
gdjs.PlayScene3Code.GDBulletHitObjects1= [];
gdjs.PlayScene3Code.GDBulletHitObjects2= [];
gdjs.PlayScene3Code.GDBulletHitObjects3= [];
gdjs.PlayScene3Code.GDBulletHitObjects4= [];
gdjs.PlayScene3Code.GDBulletHitObjects5= [];
gdjs.PlayScene3Code.GDBulletHitObjects6= [];
gdjs.PlayScene3Code.GDBulletFlashObjects1= [];
gdjs.PlayScene3Code.GDBulletFlashObjects2= [];
gdjs.PlayScene3Code.GDBulletFlashObjects3= [];
gdjs.PlayScene3Code.GDBulletFlashObjects4= [];
gdjs.PlayScene3Code.GDBulletFlashObjects5= [];
gdjs.PlayScene3Code.GDBulletFlashObjects6= [];
gdjs.PlayScene3Code.GDStarBackgroundObjects1= [];
gdjs.PlayScene3Code.GDStarBackgroundObjects2= [];
gdjs.PlayScene3Code.GDStarBackgroundObjects3= [];
gdjs.PlayScene3Code.GDStarBackgroundObjects4= [];
gdjs.PlayScene3Code.GDStarBackgroundObjects5= [];
gdjs.PlayScene3Code.GDStarBackgroundObjects6= [];
gdjs.PlayScene3Code.GDMotionTrailObjects1= [];
gdjs.PlayScene3Code.GDMotionTrailObjects2= [];
gdjs.PlayScene3Code.GDMotionTrailObjects3= [];
gdjs.PlayScene3Code.GDMotionTrailObjects4= [];
gdjs.PlayScene3Code.GDMotionTrailObjects5= [];
gdjs.PlayScene3Code.GDMotionTrailObjects6= [];
gdjs.PlayScene3Code.GDTutorialTextObjects1= [];
gdjs.PlayScene3Code.GDTutorialTextObjects2= [];
gdjs.PlayScene3Code.GDTutorialTextObjects3= [];
gdjs.PlayScene3Code.GDTutorialTextObjects4= [];
gdjs.PlayScene3Code.GDTutorialTextObjects5= [];
gdjs.PlayScene3Code.GDTutorialTextObjects6= [];
gdjs.PlayScene3Code.GDContinueTextObjects1= [];
gdjs.PlayScene3Code.GDContinueTextObjects2= [];
gdjs.PlayScene3Code.GDContinueTextObjects3= [];
gdjs.PlayScene3Code.GDContinueTextObjects4= [];
gdjs.PlayScene3Code.GDContinueTextObjects5= [];
gdjs.PlayScene3Code.GDContinueTextObjects6= [];
gdjs.PlayScene3Code.GDRightButtonObjects1= [];
gdjs.PlayScene3Code.GDRightButtonObjects2= [];
gdjs.PlayScene3Code.GDRightButtonObjects3= [];
gdjs.PlayScene3Code.GDRightButtonObjects4= [];
gdjs.PlayScene3Code.GDRightButtonObjects5= [];
gdjs.PlayScene3Code.GDRightButtonObjects6= [];
gdjs.PlayScene3Code.GDLeftButtonObjects1= [];
gdjs.PlayScene3Code.GDLeftButtonObjects2= [];
gdjs.PlayScene3Code.GDLeftButtonObjects3= [];
gdjs.PlayScene3Code.GDLeftButtonObjects4= [];
gdjs.PlayScene3Code.GDLeftButtonObjects5= [];
gdjs.PlayScene3Code.GDLeftButtonObjects6= [];
gdjs.PlayScene3Code.GDTopButtonObjects1= [];
gdjs.PlayScene3Code.GDTopButtonObjects2= [];
gdjs.PlayScene3Code.GDTopButtonObjects3= [];
gdjs.PlayScene3Code.GDTopButtonObjects4= [];
gdjs.PlayScene3Code.GDTopButtonObjects5= [];
gdjs.PlayScene3Code.GDTopButtonObjects6= [];
gdjs.PlayScene3Code.GDFireButtonObjects1= [];
gdjs.PlayScene3Code.GDFireButtonObjects2= [];
gdjs.PlayScene3Code.GDFireButtonObjects3= [];
gdjs.PlayScene3Code.GDFireButtonObjects4= [];
gdjs.PlayScene3Code.GDFireButtonObjects5= [];
gdjs.PlayScene3Code.GDFireButtonObjects6= [];
gdjs.PlayScene3Code.GDEnemyBulletObjects1= [];
gdjs.PlayScene3Code.GDEnemyBulletObjects2= [];
gdjs.PlayScene3Code.GDEnemyBulletObjects3= [];
gdjs.PlayScene3Code.GDEnemyBulletObjects4= [];
gdjs.PlayScene3Code.GDEnemyBulletObjects5= [];
gdjs.PlayScene3Code.GDEnemyBulletObjects6= [];
gdjs.PlayScene3Code.GDEnemyObjects1= [];
gdjs.PlayScene3Code.GDEnemyObjects2= [];
gdjs.PlayScene3Code.GDEnemyObjects3= [];
gdjs.PlayScene3Code.GDEnemyObjects4= [];
gdjs.PlayScene3Code.GDEnemyObjects5= [];
gdjs.PlayScene3Code.GDEnemyObjects6= [];
gdjs.PlayScene3Code.GDTitleTextObjects1= [];
gdjs.PlayScene3Code.GDTitleTextObjects2= [];
gdjs.PlayScene3Code.GDTitleTextObjects3= [];
gdjs.PlayScene3Code.GDTitleTextObjects4= [];
gdjs.PlayScene3Code.GDTitleTextObjects5= [];
gdjs.PlayScene3Code.GDTitleTextObjects6= [];
gdjs.PlayScene3Code.GDHealthPowerObjects1= [];
gdjs.PlayScene3Code.GDHealthPowerObjects2= [];
gdjs.PlayScene3Code.GDHealthPowerObjects3= [];
gdjs.PlayScene3Code.GDHealthPowerObjects4= [];
gdjs.PlayScene3Code.GDHealthPowerObjects5= [];
gdjs.PlayScene3Code.GDHealthPowerObjects6= [];
gdjs.PlayScene3Code.GDNextLevelObjects1= [];
gdjs.PlayScene3Code.GDNextLevelObjects2= [];
gdjs.PlayScene3Code.GDNextLevelObjects3= [];
gdjs.PlayScene3Code.GDNextLevelObjects4= [];
gdjs.PlayScene3Code.GDNextLevelObjects5= [];
gdjs.PlayScene3Code.GDNextLevelObjects6= [];
gdjs.PlayScene3Code.GDDeathEnemyParticleObjects1= [];
gdjs.PlayScene3Code.GDDeathEnemyParticleObjects2= [];
gdjs.PlayScene3Code.GDDeathEnemyParticleObjects3= [];
gdjs.PlayScene3Code.GDDeathEnemyParticleObjects4= [];
gdjs.PlayScene3Code.GDDeathEnemyParticleObjects5= [];
gdjs.PlayScene3Code.GDDeathEnemyParticleObjects6= [];
gdjs.PlayScene3Code.GDMenuTextObjects1= [];
gdjs.PlayScene3Code.GDMenuTextObjects2= [];
gdjs.PlayScene3Code.GDMenuTextObjects3= [];
gdjs.PlayScene3Code.GDMenuTextObjects4= [];
gdjs.PlayScene3Code.GDMenuTextObjects5= [];
gdjs.PlayScene3Code.GDMenuTextObjects6= [];
gdjs.PlayScene3Code.GDContinueButtonObjects1= [];
gdjs.PlayScene3Code.GDContinueButtonObjects2= [];
gdjs.PlayScene3Code.GDContinueButtonObjects3= [];
gdjs.PlayScene3Code.GDContinueButtonObjects4= [];
gdjs.PlayScene3Code.GDContinueButtonObjects5= [];
gdjs.PlayScene3Code.GDContinueButtonObjects6= [];
gdjs.PlayScene3Code.GDEnemyGreenObjects1= [];
gdjs.PlayScene3Code.GDEnemyGreenObjects2= [];
gdjs.PlayScene3Code.GDEnemyGreenObjects3= [];
gdjs.PlayScene3Code.GDEnemyGreenObjects4= [];
gdjs.PlayScene3Code.GDEnemyGreenObjects5= [];
gdjs.PlayScene3Code.GDEnemyGreenObjects6= [];
gdjs.PlayScene3Code.GDDeathGreenEnemyParticleObjects1= [];
gdjs.PlayScene3Code.GDDeathGreenEnemyParticleObjects2= [];
gdjs.PlayScene3Code.GDDeathGreenEnemyParticleObjects3= [];
gdjs.PlayScene3Code.GDDeathGreenEnemyParticleObjects4= [];
gdjs.PlayScene3Code.GDDeathGreenEnemyParticleObjects5= [];
gdjs.PlayScene3Code.GDDeathGreenEnemyParticleObjects6= [];
gdjs.PlayScene3Code.GDEnemyBlueObjects1= [];
gdjs.PlayScene3Code.GDEnemyBlueObjects2= [];
gdjs.PlayScene3Code.GDEnemyBlueObjects3= [];
gdjs.PlayScene3Code.GDEnemyBlueObjects4= [];
gdjs.PlayScene3Code.GDEnemyBlueObjects5= [];
gdjs.PlayScene3Code.GDEnemyBlueObjects6= [];
gdjs.PlayScene3Code.GDDeathBlueEnemyParticleObjects1= [];
gdjs.PlayScene3Code.GDDeathBlueEnemyParticleObjects2= [];
gdjs.PlayScene3Code.GDDeathBlueEnemyParticleObjects3= [];
gdjs.PlayScene3Code.GDDeathBlueEnemyParticleObjects4= [];
gdjs.PlayScene3Code.GDDeathBlueEnemyParticleObjects5= [];
gdjs.PlayScene3Code.GDDeathBlueEnemyParticleObjects6= [];
gdjs.PlayScene3Code.GDTimeTextObjects1= [];
gdjs.PlayScene3Code.GDTimeTextObjects2= [];
gdjs.PlayScene3Code.GDTimeTextObjects3= [];
gdjs.PlayScene3Code.GDTimeTextObjects4= [];
gdjs.PlayScene3Code.GDTimeTextObjects5= [];
gdjs.PlayScene3Code.GDTimeTextObjects6= [];
gdjs.PlayScene3Code.GDTimeText2Objects1= [];
gdjs.PlayScene3Code.GDTimeText2Objects2= [];
gdjs.PlayScene3Code.GDTimeText2Objects3= [];
gdjs.PlayScene3Code.GDTimeText2Objects4= [];
gdjs.PlayScene3Code.GDTimeText2Objects5= [];
gdjs.PlayScene3Code.GDTimeText2Objects6= [];
gdjs.PlayScene3Code.GDTimeText3Objects1= [];
gdjs.PlayScene3Code.GDTimeText3Objects2= [];
gdjs.PlayScene3Code.GDTimeText3Objects3= [];
gdjs.PlayScene3Code.GDTimeText3Objects4= [];
gdjs.PlayScene3Code.GDTimeText3Objects5= [];
gdjs.PlayScene3Code.GDTimeText3Objects6= [];
gdjs.PlayScene3Code.GDTimeText4Objects1= [];
gdjs.PlayScene3Code.GDTimeText4Objects2= [];
gdjs.PlayScene3Code.GDTimeText4Objects3= [];
gdjs.PlayScene3Code.GDTimeText4Objects4= [];
gdjs.PlayScene3Code.GDTimeText4Objects5= [];
gdjs.PlayScene3Code.GDTimeText4Objects6= [];


gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDEnemyObjects1Objects = Hashtable.newFrom({"Enemy": gdjs.PlayScene3Code.GDEnemyObjects1});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDEnemyGreenObjects2Objects = Hashtable.newFrom({"EnemyGreen": gdjs.PlayScene3Code.GDEnemyGreenObjects2});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDEnemyBlueObjects3Objects = Hashtable.newFrom({"EnemyBlue": gdjs.PlayScene3Code.GDEnemyBlueObjects3});
gdjs.PlayScene3Code.asyncCallback15658948 = function (runtimeScene, asyncObjectsList) {
gdjs.PlayScene3Code.GDEnemyBlueObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDEnemyBlueObjects3Objects, 0, gdjs.randomInRange(40, 500), "");
}}
gdjs.PlayScene3Code.eventsList0 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.PlayScene3Code.asyncCallback15658948(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.PlayScene3Code.asyncCallback15656700 = function (runtimeScene, asyncObjectsList) {
gdjs.PlayScene3Code.GDEnemyGreenObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDEnemyGreenObjects2Objects, 0, gdjs.randomInRange(40, 500), "");
}
{ //Subevents
gdjs.PlayScene3Code.eventsList0(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.PlayScene3Code.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.PlayScene3Code.asyncCallback15656700(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.PlayScene3Code.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TutorialText"), gdjs.PlayScene3Code.GDTutorialTextObjects2);
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "MultiTouchControls", 0, 0, 0);
}{for(var i = 0, len = gdjs.PlayScene3Code.GDTutorialTextObjects2.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDTutorialTextObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("BigAsteroid"), gdjs.PlayScene3Code.GDBigAsteroidObjects1);
gdjs.copyArray(runtimeScene.getObjects("MediumAsteroid"), gdjs.PlayScene3Code.GDMediumAsteroidObjects1);
gdjs.copyArray(runtimeScene.getObjects("SmallAsteroid"), gdjs.PlayScene3Code.GDSmallAsteroidObjects1);
gdjs.PlayScene3Code.GDEnemyObjects1.length = 0;

{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Timer");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDEnemyObjects1Objects, 960, gdjs.randomInRange(40, 500), "");
}{for(var i = 0, len = gdjs.PlayScene3Code.GDBigAsteroidObjects1.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDBigAsteroidObjects1[i].getBehavior("Physics2").applyForce(gdjs.randomInRange(-(60), 60), gdjs.randomInRange(-(60), 60), (gdjs.PlayScene3Code.GDBigAsteroidObjects1[i].getCenterXInScene()), (gdjs.PlayScene3Code.GDBigAsteroidObjects1[i].getCenterYInScene()));
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDMediumAsteroidObjects1.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDMediumAsteroidObjects1[i].getBehavior("Physics2").applyForce(gdjs.randomInRange(-(20), 20), gdjs.randomInRange(-(20), 20), (gdjs.PlayScene3Code.GDMediumAsteroidObjects1[i].getCenterXInScene()), (gdjs.PlayScene3Code.GDMediumAsteroidObjects1[i].getCenterYInScene()));
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDSmallAsteroidObjects1.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDSmallAsteroidObjects1[i].getBehavior("Physics2").applyForce(gdjs.randomInRange(-(5), 5), gdjs.randomInRange(-(5), 5), (gdjs.PlayScene3Code.GDSmallAsteroidObjects1[i].getCenterXInScene()), (gdjs.PlayScene3Code.GDSmallAsteroidObjects1[i].getCenterYInScene()));
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDBigAsteroidObjects1.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDBigAsteroidObjects1[i].setAnimation(gdjs.random(3));
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDMediumAsteroidObjects1.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDMediumAsteroidObjects1[i].setAnimation(gdjs.random(1));
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDSmallAsteroidObjects1.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDSmallAsteroidObjects1[i].setAnimation(gdjs.random(1));
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDBigAsteroidObjects1.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDBigAsteroidObjects1[i].setAngle(gdjs.random(360));
}
for(var i = 0, len = gdjs.PlayScene3Code.GDMediumAsteroidObjects1.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDMediumAsteroidObjects1[i].setAngle(gdjs.random(360));
}
for(var i = 0, len = gdjs.PlayScene3Code.GDSmallAsteroidObjects1.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDSmallAsteroidObjects1[i].setAngle(gdjs.random(360));
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDBigAsteroidObjects1.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDBigAsteroidObjects1[i].setPosition(gdjs.PlayScene3Code.GDBigAsteroidObjects1[i].getX() +(gdjs.randomInRange(-(32), 32)),gdjs.PlayScene3Code.GDBigAsteroidObjects1[i].getY() +(gdjs.randomInRange(-(32), 32)));
}
for(var i = 0, len = gdjs.PlayScene3Code.GDMediumAsteroidObjects1.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDMediumAsteroidObjects1[i].setPosition(gdjs.PlayScene3Code.GDMediumAsteroidObjects1[i].getX() +(gdjs.randomInRange(-(32), 32)),gdjs.PlayScene3Code.GDMediumAsteroidObjects1[i].getY() +(gdjs.randomInRange(-(32), 32)));
}
for(var i = 0, len = gdjs.PlayScene3Code.GDSmallAsteroidObjects1.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDSmallAsteroidObjects1[i].setPosition(gdjs.PlayScene3Code.GDSmallAsteroidObjects1[i].getX() +(gdjs.randomInRange(-(32), 32)),gdjs.PlayScene3Code.GDSmallAsteroidObjects1[i].getY() +(gdjs.randomInRange(-(32), 32)));
}
}
{ //Subevents
gdjs.PlayScene3Code.eventsList1(runtimeScene);} //End of subevents
}

}


};gdjs.PlayScene3Code.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().get("State").setString("GamePlaying");
}
{ //Subevents
gdjs.PlayScene3Code.eventsList2(runtimeScene);} //End of subevents
}

}


};gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDMotionTrailObjects3Objects = Hashtable.newFrom({"MotionTrail": gdjs.PlayScene3Code.GDMotionTrailObjects3});
gdjs.PlayScene3Code.mapOfEmptyGDTopButtonObjects = Hashtable.newFrom({"TopButton": []});
gdjs.PlayScene3Code.eventsList4 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.PlayScene3Code.GDMotionTrailObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDMotionTrailObjects3Objects, 0, 0, "");
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("MotionTrail"), gdjs.PlayScene3Code.GDMotionTrailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PlayScene3Code.GDPlayerObjects3);
{for(var i = 0, len = gdjs.PlayScene3Code.GDMotionTrailObjects3.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDMotionTrailObjects3[i].setPosition((( gdjs.PlayScene3Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDPlayerObjects3[0].getPointX("MotionTrail")),(( gdjs.PlayScene3Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDPlayerObjects3[0].getPointY("MotionTrail")));
}
}}

}


{

gdjs.PlayScene3Code.GDTopButtonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.PlayScene3Code.GDTopButtonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("TopButton"), gdjs.PlayScene3Code.GDTopButtonObjects4);
for (var i = 0, k = 0, l = gdjs.PlayScene3Code.GDTopButtonObjects4.length;i<l;++i) {
    if ( gdjs.PlayScene3Code.GDTopButtonObjects4[i].getBehavior("MultitouchButton").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.PlayScene3Code.GDTopButtonObjects4[k] = gdjs.PlayScene3Code.GDTopButtonObjects4[i];
        ++k;
    }
}
gdjs.PlayScene3Code.GDTopButtonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PlayScene3Code.GDTopButtonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.PlayScene3Code.GDTopButtonObjects3_1final.indexOf(gdjs.PlayScene3Code.GDTopButtonObjects4[j]) === -1 )
            gdjs.PlayScene3Code.GDTopButtonObjects3_1final.push(gdjs.PlayScene3Code.GDTopButtonObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.PlayScene3Code.GDTopButtonObjects3_1final, gdjs.PlayScene3Code.GDTopButtonObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15663228);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("MotionTrail"), gdjs.PlayScene3Code.GDMotionTrailObjects3);
{for(var i = 0, len = gdjs.PlayScene3Code.GDMotionTrailObjects3.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDMotionTrailObjects3[i].startEmission();
}
}}

}


{

gdjs.PlayScene3Code.GDTopButtonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "w"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.PlayScene3Code.GDTopButtonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("TopButton"), gdjs.PlayScene3Code.GDTopButtonObjects3);
for (var i = 0, k = 0, l = gdjs.PlayScene3Code.GDTopButtonObjects3.length;i<l;++i) {
    if ( !(gdjs.PlayScene3Code.GDTopButtonObjects3[i].getBehavior("MultitouchButton").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_1 = true;
        gdjs.PlayScene3Code.GDTopButtonObjects3[k] = gdjs.PlayScene3Code.GDTopButtonObjects3[i];
        ++k;
    }
}
gdjs.PlayScene3Code.GDTopButtonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PlayScene3Code.GDTopButtonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.PlayScene3Code.GDTopButtonObjects2_1final.indexOf(gdjs.PlayScene3Code.GDTopButtonObjects3[j]) === -1 )
            gdjs.PlayScene3Code.GDTopButtonObjects2_1final.push(gdjs.PlayScene3Code.GDTopButtonObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene3Code.mapOfEmptyGDTopButtonObjects) == 0;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.PlayScene3Code.GDTopButtonObjects2_1final, gdjs.PlayScene3Code.GDTopButtonObjects2);
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("MotionTrail"), gdjs.PlayScene3Code.GDMotionTrailObjects2);
{for(var i = 0, len = gdjs.PlayScene3Code.GDMotionTrailObjects2.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDMotionTrailObjects2[i].stopEmission();
}
}}

}


};gdjs.PlayScene3Code.eventsList5 = function(runtimeScene) {

{

gdjs.PlayScene3Code.GDTopButtonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.PlayScene3Code.GDTopButtonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("TopButton"), gdjs.PlayScene3Code.GDTopButtonObjects4);
for (var i = 0, k = 0, l = gdjs.PlayScene3Code.GDTopButtonObjects4.length;i<l;++i) {
    if ( gdjs.PlayScene3Code.GDTopButtonObjects4[i].getBehavior("MultitouchButton").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.PlayScene3Code.GDTopButtonObjects4[k] = gdjs.PlayScene3Code.GDTopButtonObjects4[i];
        ++k;
    }
}
gdjs.PlayScene3Code.GDTopButtonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PlayScene3Code.GDTopButtonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.PlayScene3Code.GDTopButtonObjects3_1final.indexOf(gdjs.PlayScene3Code.GDTopButtonObjects4[j]) === -1 )
            gdjs.PlayScene3Code.GDTopButtonObjects3_1final.push(gdjs.PlayScene3Code.GDTopButtonObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.PlayScene3Code.GDTopButtonObjects3_1final, gdjs.PlayScene3Code.GDTopButtonObjects3);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PlayScene3Code.GDPlayerObjects3);
{for(var i = 0, len = gdjs.PlayScene3Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDPlayerObjects3[i].getBehavior("Physics2").applyPolarForce((gdjs.PlayScene3Code.GDPlayerObjects3[i].getAngle()), 4.5, (gdjs.PlayScene3Code.GDPlayerObjects3[i].getPointX("")), (gdjs.PlayScene3Code.GDPlayerObjects3[i].getPointY("")));
}
}}

}


{

gdjs.PlayScene3Code.GDLeftButtonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.PlayScene3Code.GDLeftButtonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("LeftButton"), gdjs.PlayScene3Code.GDLeftButtonObjects4);
for (var i = 0, k = 0, l = gdjs.PlayScene3Code.GDLeftButtonObjects4.length;i<l;++i) {
    if ( gdjs.PlayScene3Code.GDLeftButtonObjects4[i].getBehavior("MultitouchButton").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.PlayScene3Code.GDLeftButtonObjects4[k] = gdjs.PlayScene3Code.GDLeftButtonObjects4[i];
        ++k;
    }
}
gdjs.PlayScene3Code.GDLeftButtonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PlayScene3Code.GDLeftButtonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.PlayScene3Code.GDLeftButtonObjects3_1final.indexOf(gdjs.PlayScene3Code.GDLeftButtonObjects4[j]) === -1 )
            gdjs.PlayScene3Code.GDLeftButtonObjects3_1final.push(gdjs.PlayScene3Code.GDLeftButtonObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.PlayScene3Code.GDLeftButtonObjects3_1final, gdjs.PlayScene3Code.GDLeftButtonObjects3);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PlayScene3Code.GDPlayerObjects3);
{for(var i = 0, len = gdjs.PlayScene3Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDPlayerObjects3[i].getBehavior("Physics2").applyTorque(-(0.5));
}
}}

}


{

gdjs.PlayScene3Code.GDRightButtonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.PlayScene3Code.GDRightButtonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("RightButton"), gdjs.PlayScene3Code.GDRightButtonObjects3);
for (var i = 0, k = 0, l = gdjs.PlayScene3Code.GDRightButtonObjects3.length;i<l;++i) {
    if ( gdjs.PlayScene3Code.GDRightButtonObjects3[i].getBehavior("MultitouchButton").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.PlayScene3Code.GDRightButtonObjects3[k] = gdjs.PlayScene3Code.GDRightButtonObjects3[i];
        ++k;
    }
}
gdjs.PlayScene3Code.GDRightButtonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PlayScene3Code.GDRightButtonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.PlayScene3Code.GDRightButtonObjects2_1final.indexOf(gdjs.PlayScene3Code.GDRightButtonObjects3[j]) === -1 )
            gdjs.PlayScene3Code.GDRightButtonObjects2_1final.push(gdjs.PlayScene3Code.GDRightButtonObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.PlayScene3Code.GDRightButtonObjects2_1final, gdjs.PlayScene3Code.GDRightButtonObjects2);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PlayScene3Code.GDPlayerObjects2);
{for(var i = 0, len = gdjs.PlayScene3Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDPlayerObjects2[i].getBehavior("Physics2").applyTorque(0.5);
}
}}

}


};gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDBulletObjects2Objects = Hashtable.newFrom({"Bullet": gdjs.PlayScene3Code.GDBulletObjects2});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDBulletFlashObjects2Objects = Hashtable.newFrom({"BulletFlash": gdjs.PlayScene3Code.GDBulletFlashObjects2});
gdjs.PlayScene3Code.eventsList6 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PlayScene3Code.GDPlayerObjects2);
gdjs.PlayScene3Code.GDFireButtonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PlayScene3Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.PlayScene3Code.GDPlayerObjects2[i].getBehavior("FireBullet").IsReadyToShoot((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.PlayScene3Code.GDPlayerObjects2[k] = gdjs.PlayScene3Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.PlayScene3Code.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.PlayScene3Code.GDFireButtonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("FireButton"), gdjs.PlayScene3Code.GDFireButtonObjects3);
for (var i = 0, k = 0, l = gdjs.PlayScene3Code.GDFireButtonObjects3.length;i<l;++i) {
    if ( gdjs.PlayScene3Code.GDFireButtonObjects3[i].getBehavior("MultitouchButton").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.PlayScene3Code.GDFireButtonObjects3[k] = gdjs.PlayScene3Code.GDFireButtonObjects3[i];
        ++k;
    }
}
gdjs.PlayScene3Code.GDFireButtonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PlayScene3Code.GDFireButtonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.PlayScene3Code.GDFireButtonObjects2_1final.indexOf(gdjs.PlayScene3Code.GDFireButtonObjects3[j]) === -1 )
            gdjs.PlayScene3Code.GDFireButtonObjects2_1final.push(gdjs.PlayScene3Code.GDFireButtonObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.PlayScene3Code.GDFireButtonObjects2_1final, gdjs.PlayScene3Code.GDFireButtonObjects2);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.PlayScene3Code.GDBulletObjects2);
/* Reuse gdjs.PlayScene3Code.GDPlayerObjects2 */
gdjs.PlayScene3Code.GDBulletFlashObjects2.length = 0;

{for(var i = 0, len = gdjs.PlayScene3Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDPlayerObjects2[i].getBehavior("FireBullet").Fire((gdjs.PlayScene3Code.GDPlayerObjects2[i].getPointX("BulletSpawn")), (gdjs.PlayScene3Code.GDPlayerObjects2[i].getPointY("BulletSpawn")), gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDBulletObjects2Objects, (gdjs.PlayScene3Code.GDPlayerObjects2[i].getAngle()), 240, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDBulletObjects2.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDBulletObjects2[i].setZOrder((( gdjs.PlayScene3Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDPlayerObjects2[0].getZOrder()) - 2);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "LaserFire.wav", false, 40, gdjs.randomFloatInRange(0.9, 1.1));
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDBulletFlashObjects2Objects, (( gdjs.PlayScene3Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDPlayerObjects2[0].getPointX("BulletFlash")), (( gdjs.PlayScene3Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDPlayerObjects2[0].getPointY("BulletFlash")), "");
}{for(var i = 0, len = gdjs.PlayScene3Code.GDBulletFlashObjects2.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDBulletFlashObjects2[i].setAngle((( gdjs.PlayScene3Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDPlayerObjects2[0].getAngle()) + 90);
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDBulletFlashObjects2.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDBulletFlashObjects2[i].setZOrder((( gdjs.PlayScene3Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDPlayerObjects2[0].getZOrder()) - 1);
}
}}

}


};gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDEnemyBulletObjects3Objects = Hashtable.newFrom({"EnemyBullet": gdjs.PlayScene3Code.GDEnemyBulletObjects3});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDBulletFlashObjects3Objects = Hashtable.newFrom({"BulletFlash": gdjs.PlayScene3Code.GDBulletFlashObjects3});
gdjs.PlayScene3Code.eventsList7 = function(runtimeScene) {

{

/* Reuse gdjs.PlayScene3Code.GDEnemyBlueObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PlayScene3Code.GDEnemyBlueObjects3.length;i<l;++i) {
    if ( gdjs.PlayScene3Code.GDEnemyBlueObjects3[i].getBehavior("FireBullet").HasJustFired((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.PlayScene3Code.GDEnemyBlueObjects3[k] = gdjs.PlayScene3Code.GDEnemyBlueObjects3[i];
        ++k;
    }
}
gdjs.PlayScene3Code.GDEnemyBlueObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.PlayScene3Code.GDEnemyBlueObjects3 */
/* Reuse gdjs.PlayScene3Code.GDEnemyBulletObjects3 */
gdjs.PlayScene3Code.GDBulletFlashObjects3.length = 0;

{for(var i = 0, len = gdjs.PlayScene3Code.GDEnemyBulletObjects3.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDEnemyBulletObjects3[i].setZOrder((( gdjs.PlayScene3Code.GDEnemyBlueObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDEnemyBlueObjects3[0].getZOrder()) - 2);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Laser-weapon 8.aac", false, 40, gdjs.randomFloatInRange(0.9, 1.1));
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDBulletFlashObjects3Objects, (( gdjs.PlayScene3Code.GDEnemyBlueObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDEnemyBlueObjects3[0].getPointX("BulletFlash")), (( gdjs.PlayScene3Code.GDEnemyBlueObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDEnemyBlueObjects3[0].getPointY("BulletFlash")), "");
}{for(var i = 0, len = gdjs.PlayScene3Code.GDBulletFlashObjects3.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDBulletFlashObjects3[i].setAngle((( gdjs.PlayScene3Code.GDEnemyBlueObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDEnemyBlueObjects3[0].getAngle()) + 90);
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDBulletFlashObjects3.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDBulletFlashObjects3[i].setZOrder((( gdjs.PlayScene3Code.GDEnemyBlueObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDEnemyBlueObjects3[0].getZOrder()) - 1);
}
}}

}


};gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.PlayScene3Code.GDBulletObjects3});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDEnemyBlueObjects3Objects = Hashtable.newFrom({"EnemyBlue": gdjs.PlayScene3Code.GDEnemyBlueObjects3});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDDeathDebrisParticleObjects3Objects = Hashtable.newFrom({"DeathDebrisParticle": gdjs.PlayScene3Code.GDDeathDebrisParticleObjects3});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDDeathBlueEnemyParticleObjects3Objects = Hashtable.newFrom({"DeathBlueEnemyParticle": gdjs.PlayScene3Code.GDDeathBlueEnemyParticleObjects3});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDHealthPowerObjects3Objects = Hashtable.newFrom({"HealthPower": gdjs.PlayScene3Code.GDHealthPowerObjects3});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDBulletHitObjects3Objects = Hashtable.newFrom({"BulletHit": gdjs.PlayScene3Code.GDBulletHitObjects3});
gdjs.PlayScene3Code.mapOfEmptyGDEnemyBlueObjects = Hashtable.newFrom({"EnemyBlue": []});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDEnemyBlueObjects3Objects = Hashtable.newFrom({"EnemyBlue": gdjs.PlayScene3Code.GDEnemyBlueObjects3});
gdjs.PlayScene3Code.eventsList8 = function(runtimeScene) {

};gdjs.PlayScene3Code.eventsList9 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("EnemyBlue"), gdjs.PlayScene3Code.GDEnemyBlueObjects3);
gdjs.copyArray(runtimeScene.getObjects("EnemyBullet"), gdjs.PlayScene3Code.GDEnemyBulletObjects3);
{for(var i = 0, len = gdjs.PlayScene3Code.GDEnemyBlueObjects3.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDEnemyBlueObjects3[i].getBehavior("FireBullet").Fire((gdjs.PlayScene3Code.GDEnemyBlueObjects3[i].getPointX("BulletSpawn")), (gdjs.PlayScene3Code.GDEnemyBlueObjects3[i].getPointY("BulletSpawn")), gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDEnemyBulletObjects3Objects, (gdjs.PlayScene3Code.GDEnemyBlueObjects3[i].getAngle()) - 90, 160, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.PlayScene3Code.eventsList7(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.PlayScene3Code.GDEnemyObjects3);
gdjs.copyArray(runtimeScene.getObjects("EnemyBlue"), gdjs.PlayScene3Code.GDEnemyBlueObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PlayScene3Code.GDPlayerObjects3);
{for(var i = 0, len = gdjs.PlayScene3Code.GDEnemyBlueObjects3.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDEnemyBlueObjects3[i].rotateTowardPosition((( gdjs.PlayScene3Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDPlayerObjects3[0].getPointX("Origin")), (( gdjs.PlayScene3Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDPlayerObjects3[0].getPointY("Origin")), 0, runtimeScene);
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDEnemyBlueObjects3.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDEnemyBlueObjects3[i].getBehavior("Physics2").applyPolarForce((gdjs.PlayScene3Code.GDEnemyBlueObjects3[i].getAngle()), 2.5, (( gdjs.PlayScene3Code.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDEnemyObjects3[0].getBehavior("Physics2").getMassCenterX()), (( gdjs.PlayScene3Code.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDEnemyObjects3[0].getBehavior("Physics2").getMassCenterY()));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.PlayScene3Code.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("EnemyBlue"), gdjs.PlayScene3Code.GDEnemyBlueObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDBulletObjects3Objects, gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDEnemyBlueObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.PlayScene3Code.GDBulletObjects3 */
gdjs.copyArray(runtimeScene.getObjects("DeathBlueEnemyParticle"), gdjs.PlayScene3Code.GDDeathBlueEnemyParticleObjects3);
/* Reuse gdjs.PlayScene3Code.GDEnemyBlueObjects3 */
gdjs.PlayScene3Code.GDBulletHitObjects3.length = 0;

gdjs.PlayScene3Code.GDDeathDebrisParticleObjects3.length = 0;

gdjs.PlayScene3Code.GDHealthPowerObjects3.length = 0;

{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "BlueTimer");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "PillTimer");
}{for(var i = 0, len = gdjs.PlayScene3Code.GDEnemyBlueObjects3.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDEnemyBlueObjects3[i].getBehavior("Health").Hit(1, false, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Explosion.wav", false, 60, gdjs.randomFloatInRange(0.9, 1));
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDDeathDebrisParticleObjects3Objects, (( gdjs.PlayScene3Code.GDEnemyBlueObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDEnemyBlueObjects3[0].getPointX("")), (( gdjs.PlayScene3Code.GDEnemyBlueObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDEnemyBlueObjects3[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.PlayScene3Code.GDDeathBlueEnemyParticleObjects3.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDDeathBlueEnemyParticleObjects3[i].setAngle((( gdjs.PlayScene3Code.GDEnemyBlueObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDEnemyBlueObjects3[0].getAngle()));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDDeathBlueEnemyParticleObjects3Objects, (( gdjs.PlayScene3Code.GDEnemyBlueObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDEnemyBlueObjects3[0].getPointX("")), (( gdjs.PlayScene3Code.GDEnemyBlueObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDEnemyBlueObjects3[0].getPointY("")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDHealthPowerObjects3Objects, (( gdjs.PlayScene3Code.GDEnemyBlueObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDEnemyBlueObjects3[0].getPointX("")), (( gdjs.PlayScene3Code.GDEnemyBlueObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDEnemyBlueObjects3[0].getPointY("")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDBulletHitObjects3Objects, (( gdjs.PlayScene3Code.GDBulletObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDBulletObjects3[0].getPointX("BulletHit")), (( gdjs.PlayScene3Code.GDBulletObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDBulletObjects3[0].getPointY("BulletHit")), "");
}{for(var i = 0, len = gdjs.PlayScene3Code.GDEnemyBlueObjects3.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDEnemyBlueObjects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDBulletObjects3.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDBulletObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{


let stopDoWhile_0 = false;
do {
gdjs.PlayScene3Code.GDEnemyBlueObjects3.length = 0;

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "BlueTimer") >= 6;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene3Code.mapOfEmptyGDEnemyBlueObjects) == 0;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
let isConditionTrue_0 = false;
if (true) {
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDEnemyBlueObjects3Objects, 960, gdjs.randomInRange(40, 500), "");
}
{ //Subevents: 
gdjs.PlayScene3Code.eventsList8(runtimeScene);} //Subevents end.
}
} else stopDoWhile_0 = true; 
} while (!stopDoWhile_0);

}


};gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDEnemyBulletObjects3Objects = Hashtable.newFrom({"EnemyBullet": gdjs.PlayScene3Code.GDEnemyBulletObjects3});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDBulletFlashObjects3Objects = Hashtable.newFrom({"BulletFlash": gdjs.PlayScene3Code.GDBulletFlashObjects3});
gdjs.PlayScene3Code.eventsList10 = function(runtimeScene) {

{

/* Reuse gdjs.PlayScene3Code.GDEnemyGreenObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PlayScene3Code.GDEnemyGreenObjects3.length;i<l;++i) {
    if ( gdjs.PlayScene3Code.GDEnemyGreenObjects3[i].getBehavior("FireBullet").HasJustFired((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.PlayScene3Code.GDEnemyGreenObjects3[k] = gdjs.PlayScene3Code.GDEnemyGreenObjects3[i];
        ++k;
    }
}
gdjs.PlayScene3Code.GDEnemyGreenObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.PlayScene3Code.GDEnemyBulletObjects3 */
/* Reuse gdjs.PlayScene3Code.GDEnemyGreenObjects3 */
gdjs.PlayScene3Code.GDBulletFlashObjects3.length = 0;

{for(var i = 0, len = gdjs.PlayScene3Code.GDEnemyBulletObjects3.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDEnemyBulletObjects3[i].setZOrder((( gdjs.PlayScene3Code.GDEnemyGreenObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDEnemyGreenObjects3[0].getZOrder()) - 2);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Laser-weapon 4.aac", false, 40, gdjs.randomFloatInRange(0.9, 1.1));
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDBulletFlashObjects3Objects, (( gdjs.PlayScene3Code.GDEnemyGreenObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDEnemyGreenObjects3[0].getPointX("BulletFlash")), (( gdjs.PlayScene3Code.GDEnemyGreenObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDEnemyGreenObjects3[0].getPointY("BulletFlash")), "");
}{for(var i = 0, len = gdjs.PlayScene3Code.GDBulletFlashObjects3.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDBulletFlashObjects3[i].setAngle((( gdjs.PlayScene3Code.GDEnemyGreenObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDEnemyGreenObjects3[0].getAngle()) + 90);
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDBulletFlashObjects3.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDBulletFlashObjects3[i].setZOrder((( gdjs.PlayScene3Code.GDEnemyGreenObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDEnemyGreenObjects3[0].getZOrder()) - 1);
}
}}

}


};gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.PlayScene3Code.GDBulletObjects3});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDEnemyGreenObjects3Objects = Hashtable.newFrom({"EnemyGreen": gdjs.PlayScene3Code.GDEnemyGreenObjects3});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDDeathDebrisParticleObjects3Objects = Hashtable.newFrom({"DeathDebrisParticle": gdjs.PlayScene3Code.GDDeathDebrisParticleObjects3});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDDeathGreenEnemyParticleObjects3Objects = Hashtable.newFrom({"DeathGreenEnemyParticle": gdjs.PlayScene3Code.GDDeathGreenEnemyParticleObjects3});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDHealthPowerObjects3Objects = Hashtable.newFrom({"HealthPower": gdjs.PlayScene3Code.GDHealthPowerObjects3});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDBulletHitObjects3Objects = Hashtable.newFrom({"BulletHit": gdjs.PlayScene3Code.GDBulletHitObjects3});
gdjs.PlayScene3Code.mapOfEmptyGDEnemyGreenObjects = Hashtable.newFrom({"EnemyGreen": []});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDEnemyGreenObjects3Objects = Hashtable.newFrom({"EnemyGreen": gdjs.PlayScene3Code.GDEnemyGreenObjects3});
gdjs.PlayScene3Code.eventsList11 = function(runtimeScene) {

};gdjs.PlayScene3Code.eventsList12 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("EnemyBullet"), gdjs.PlayScene3Code.GDEnemyBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("EnemyGreen"), gdjs.PlayScene3Code.GDEnemyGreenObjects3);
{for(var i = 0, len = gdjs.PlayScene3Code.GDEnemyGreenObjects3.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDEnemyGreenObjects3[i].getBehavior("FireBullet").Fire((gdjs.PlayScene3Code.GDEnemyGreenObjects3[i].getPointX("BulletSpawn")), (gdjs.PlayScene3Code.GDEnemyGreenObjects3[i].getPointY("BulletSpawn")), gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDEnemyBulletObjects3Objects, (gdjs.PlayScene3Code.GDEnemyGreenObjects3[i].getAngle()) - 90, 180, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.PlayScene3Code.eventsList10(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.PlayScene3Code.GDEnemyObjects3);
gdjs.copyArray(runtimeScene.getObjects("EnemyGreen"), gdjs.PlayScene3Code.GDEnemyGreenObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PlayScene3Code.GDPlayerObjects3);
{for(var i = 0, len = gdjs.PlayScene3Code.GDEnemyGreenObjects3.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDEnemyGreenObjects3[i].getBehavior("Physics2").applyForce(6, 0, (( gdjs.PlayScene3Code.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDEnemyObjects3[0].getPointX("Origin")), (( gdjs.PlayScene3Code.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDEnemyObjects3[0].getPointY("Origin")));
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDEnemyGreenObjects3.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDEnemyGreenObjects3[i].rotateTowardPosition((( gdjs.PlayScene3Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDPlayerObjects3[0].getPointX("Origin")), (( gdjs.PlayScene3Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDPlayerObjects3[0].getPointY("Origin")), 0, runtimeScene);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.PlayScene3Code.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("EnemyGreen"), gdjs.PlayScene3Code.GDEnemyGreenObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDBulletObjects3Objects, gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDEnemyGreenObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.PlayScene3Code.GDBulletObjects3 */
gdjs.copyArray(runtimeScene.getObjects("DeathGreenEnemyParticle"), gdjs.PlayScene3Code.GDDeathGreenEnemyParticleObjects3);
/* Reuse gdjs.PlayScene3Code.GDEnemyGreenObjects3 */
gdjs.PlayScene3Code.GDBulletHitObjects3.length = 0;

gdjs.PlayScene3Code.GDDeathDebrisParticleObjects3.length = 0;

gdjs.PlayScene3Code.GDHealthPowerObjects3.length = 0;

{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "UFOTimer");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "PillTimer");
}{for(var i = 0, len = gdjs.PlayScene3Code.GDEnemyGreenObjects3.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDEnemyGreenObjects3[i].getBehavior("Health").Hit(1, false, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Explosion.wav", false, 60, gdjs.randomFloatInRange(0.9, 1));
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDDeathDebrisParticleObjects3Objects, (( gdjs.PlayScene3Code.GDEnemyGreenObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDEnemyGreenObjects3[0].getPointX("")), (( gdjs.PlayScene3Code.GDEnemyGreenObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDEnemyGreenObjects3[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.PlayScene3Code.GDDeathGreenEnemyParticleObjects3.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDDeathGreenEnemyParticleObjects3[i].setAngle((( gdjs.PlayScene3Code.GDEnemyGreenObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDEnemyGreenObjects3[0].getAngle()));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDDeathGreenEnemyParticleObjects3Objects, (( gdjs.PlayScene3Code.GDEnemyGreenObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDEnemyGreenObjects3[0].getPointX("")), (( gdjs.PlayScene3Code.GDEnemyGreenObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDEnemyGreenObjects3[0].getPointY("")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDHealthPowerObjects3Objects, (( gdjs.PlayScene3Code.GDEnemyGreenObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDEnemyGreenObjects3[0].getPointX("")), (( gdjs.PlayScene3Code.GDEnemyGreenObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDEnemyGreenObjects3[0].getPointY("")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDBulletHitObjects3Objects, (( gdjs.PlayScene3Code.GDBulletObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDBulletObjects3[0].getPointX("BulletHit")), (( gdjs.PlayScene3Code.GDBulletObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDBulletObjects3[0].getPointY("BulletHit")), "");
}{for(var i = 0, len = gdjs.PlayScene3Code.GDEnemyGreenObjects3.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDEnemyGreenObjects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDBulletObjects3.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDBulletObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{


let stopDoWhile_0 = false;
do {
gdjs.PlayScene3Code.GDEnemyGreenObjects3.length = 0;

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "UFOTimer") >= 7;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene3Code.mapOfEmptyGDEnemyGreenObjects) == 0;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
let isConditionTrue_0 = false;
if (true) {
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDEnemyGreenObjects3Objects, 0, gdjs.randomInRange(40, 500), "");
}
{ //Subevents: 
gdjs.PlayScene3Code.eventsList11(runtimeScene);} //Subevents end.
}
} else stopDoWhile_0 = true; 
} while (!stopDoWhile_0);

}


};gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDEnemyBulletObjects3Objects = Hashtable.newFrom({"EnemyBullet": gdjs.PlayScene3Code.GDEnemyBulletObjects3});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDBulletFlashObjects3Objects = Hashtable.newFrom({"BulletFlash": gdjs.PlayScene3Code.GDBulletFlashObjects3});
gdjs.PlayScene3Code.eventsList13 = function(runtimeScene) {

{

/* Reuse gdjs.PlayScene3Code.GDEnemyObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PlayScene3Code.GDEnemyObjects3.length;i<l;++i) {
    if ( gdjs.PlayScene3Code.GDEnemyObjects3[i].getBehavior("FireBullet").HasJustFired((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.PlayScene3Code.GDEnemyObjects3[k] = gdjs.PlayScene3Code.GDEnemyObjects3[i];
        ++k;
    }
}
gdjs.PlayScene3Code.GDEnemyObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.PlayScene3Code.GDEnemyObjects3 */
/* Reuse gdjs.PlayScene3Code.GDEnemyBulletObjects3 */
gdjs.PlayScene3Code.GDBulletFlashObjects3.length = 0;

{for(var i = 0, len = gdjs.PlayScene3Code.GDEnemyBulletObjects3.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDEnemyBulletObjects3[i].setZOrder((( gdjs.PlayScene3Code.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDEnemyObjects3[0].getZOrder()) - 2);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Laser effect (2).aac", false, 40, gdjs.randomFloatInRange(0.9, 1.1));
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDBulletFlashObjects3Objects, (( gdjs.PlayScene3Code.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDEnemyObjects3[0].getPointX("BulletFlash")), (( gdjs.PlayScene3Code.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDEnemyObjects3[0].getPointY("BulletFlash")), "");
}{for(var i = 0, len = gdjs.PlayScene3Code.GDBulletFlashObjects3.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDBulletFlashObjects3[i].setAngle((( gdjs.PlayScene3Code.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDEnemyObjects3[0].getAngle()) + 90);
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDBulletFlashObjects3.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDBulletFlashObjects3[i].setZOrder((( gdjs.PlayScene3Code.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDEnemyObjects3[0].getZOrder()) - 1);
}
}}

}


};gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.PlayScene3Code.GDBulletObjects3});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDEnemyObjects3Objects = Hashtable.newFrom({"Enemy": gdjs.PlayScene3Code.GDEnemyObjects3});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDDeathDebrisParticleObjects3Objects = Hashtable.newFrom({"DeathDebrisParticle": gdjs.PlayScene3Code.GDDeathDebrisParticleObjects3});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDDeathEnemyParticleObjects3Objects = Hashtable.newFrom({"DeathEnemyParticle": gdjs.PlayScene3Code.GDDeathEnemyParticleObjects3});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDHealthPowerObjects3Objects = Hashtable.newFrom({"HealthPower": gdjs.PlayScene3Code.GDHealthPowerObjects3});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDBulletHitObjects3Objects = Hashtable.newFrom({"BulletHit": gdjs.PlayScene3Code.GDBulletHitObjects3});
gdjs.PlayScene3Code.mapOfEmptyGDEnemyObjects = Hashtable.newFrom({"Enemy": []});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDEnemyObjects3Objects = Hashtable.newFrom({"Enemy": gdjs.PlayScene3Code.GDEnemyObjects3});
gdjs.PlayScene3Code.eventsList14 = function(runtimeScene) {

};gdjs.PlayScene3Code.eventsList15 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.PlayScene3Code.GDEnemyObjects3);
gdjs.copyArray(runtimeScene.getObjects("EnemyBullet"), gdjs.PlayScene3Code.GDEnemyBulletObjects3);
{for(var i = 0, len = gdjs.PlayScene3Code.GDEnemyObjects3.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDEnemyObjects3[i].getBehavior("FireBullet").Fire((gdjs.PlayScene3Code.GDEnemyObjects3[i].getPointX("BulletSpawn")), (gdjs.PlayScene3Code.GDEnemyObjects3[i].getPointY("BulletSpawn")), gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDEnemyBulletObjects3Objects, (gdjs.PlayScene3Code.GDEnemyObjects3[i].getAngle()), 120, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.PlayScene3Code.eventsList13(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.PlayScene3Code.GDEnemyObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PlayScene3Code.GDPlayerObjects3);
{for(var i = 0, len = gdjs.PlayScene3Code.GDEnemyObjects3.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDEnemyObjects3[i].getBehavior("Physics2").applyForce(-(3), 0, (gdjs.PlayScene3Code.GDEnemyObjects3[i].getPointX("Origin")), (gdjs.PlayScene3Code.GDEnemyObjects3[i].getPointY("Origin")));
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDEnemyObjects3.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDEnemyObjects3[i].rotateTowardPosition((( gdjs.PlayScene3Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDPlayerObjects3[0].getPointX("Origin")), (( gdjs.PlayScene3Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDPlayerObjects3[0].getPointY("Origin")), 0, runtimeScene);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.PlayScene3Code.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.PlayScene3Code.GDEnemyObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDBulletObjects3Objects, gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDEnemyObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.PlayScene3Code.GDBulletObjects3 */
gdjs.copyArray(runtimeScene.getObjects("DeathEnemyParticle"), gdjs.PlayScene3Code.GDDeathEnemyParticleObjects3);
/* Reuse gdjs.PlayScene3Code.GDEnemyObjects3 */
gdjs.PlayScene3Code.GDBulletHitObjects3.length = 0;

gdjs.PlayScene3Code.GDDeathDebrisParticleObjects3.length = 0;

gdjs.PlayScene3Code.GDHealthPowerObjects3.length = 0;

{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "EnemyTimer");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "PillTimer");
}{for(var i = 0, len = gdjs.PlayScene3Code.GDEnemyObjects3.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDEnemyObjects3[i].getBehavior("Health").Hit(1, false, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Explosion.wav", false, 60, gdjs.randomFloatInRange(0.9, 1));
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDDeathDebrisParticleObjects3Objects, (( gdjs.PlayScene3Code.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDEnemyObjects3[0].getPointX("")), (( gdjs.PlayScene3Code.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDEnemyObjects3[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.PlayScene3Code.GDDeathEnemyParticleObjects3.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDDeathEnemyParticleObjects3[i].setAngle((( gdjs.PlayScene3Code.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDEnemyObjects3[0].getAngle()));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDDeathEnemyParticleObjects3Objects, (( gdjs.PlayScene3Code.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDEnemyObjects3[0].getPointX("")), (( gdjs.PlayScene3Code.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDEnemyObjects3[0].getPointY("")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDHealthPowerObjects3Objects, (( gdjs.PlayScene3Code.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDEnemyObjects3[0].getPointX("")), (( gdjs.PlayScene3Code.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDEnemyObjects3[0].getPointY("")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDBulletHitObjects3Objects, (( gdjs.PlayScene3Code.GDBulletObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDBulletObjects3[0].getPointX("BulletHit")), (( gdjs.PlayScene3Code.GDBulletObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDBulletObjects3[0].getPointY("BulletHit")), "");
}{for(var i = 0, len = gdjs.PlayScene3Code.GDEnemyObjects3.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDEnemyObjects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDBulletObjects3.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDBulletObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{


let stopDoWhile_0 = false;
do {
gdjs.PlayScene3Code.GDEnemyObjects3.length = 0;

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "EnemyTimer") >= 4;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene3Code.mapOfEmptyGDEnemyObjects) == 0;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
let isConditionTrue_0 = false;
if (true) {
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDEnemyObjects3Objects, 960, gdjs.randomInRange(40, 500), "");
}
{ //Subevents: 
gdjs.PlayScene3Code.eventsList14(runtimeScene);} //Subevents end.
}
} else stopDoWhile_0 = true; 
} while (!stopDoWhile_0);

}


};gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.PlayScene3Code.GDPlayerObjects3});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDHealthPowerObjects3Objects = Hashtable.newFrom({"HealthPower": gdjs.PlayScene3Code.GDHealthPowerObjects3});
gdjs.PlayScene3Code.mapOfEmptyGDHealthPowerObjects = Hashtable.newFrom({"HealthPower": []});
gdjs.PlayScene3Code.eventsList16 = function(runtimeScene) {

{

/* Reuse gdjs.PlayScene3Code.GDHealthPowerObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.PlayScene3Code.GDHealthPowerObjects2.length;i<l;++i) {
    if ( gdjs.PlayScene3Code.GDHealthPowerObjects2[i].getBehavior("Flash").IsFlashing((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.PlayScene3Code.GDHealthPowerObjects2[k] = gdjs.PlayScene3Code.GDHealthPowerObjects2[i];
        ++k;
    }
}
gdjs.PlayScene3Code.GDHealthPowerObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "PillTimer") >= 8;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.PlayScene3Code.GDHealthPowerObjects2 */
{for(var i = 0, len = gdjs.PlayScene3Code.GDHealthPowerObjects2.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDHealthPowerObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.PlayScene3Code.eventsList17 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("HealthPower"), gdjs.PlayScene3Code.GDHealthPowerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PlayScene3Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDPlayerObjects3Objects, gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDHealthPowerObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.PlayScene3Code.GDHealthPowerObjects3 */
gdjs.copyArray(runtimeScene.getObjects("LifeBar"), gdjs.PlayScene3Code.GDLifeBarObjects3);
/* Reuse gdjs.PlayScene3Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.PlayScene3Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDPlayerObjects3[i].getBehavior("Health").Heal(1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDLifeBarObjects3.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDLifeBarObjects3[i].SetValue((( gdjs.PlayScene3Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDPlayerObjects3[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDHealthPowerObjects3.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDHealthPowerObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene3Code.mapOfEmptyGDHealthPowerObjects) > 0;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "PillTimer") >= 5;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("HealthPower"), gdjs.PlayScene3Code.GDHealthPowerObjects2);
{for(var i = 0, len = gdjs.PlayScene3Code.GDHealthPowerObjects2.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDHealthPowerObjects2[i].getBehavior("Flash").Flash(3, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.PlayScene3Code.eventsList16(runtimeScene);} //End of subevents
}

}


};gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDBulletObjects5Objects = Hashtable.newFrom({"Bullet": gdjs.PlayScene3Code.GDBulletObjects5});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDBigAsteroidObjects5Objects = Hashtable.newFrom({"BigAsteroid": gdjs.PlayScene3Code.GDBigAsteroidObjects5});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDEnemyBulletObjects5Objects = Hashtable.newFrom({"EnemyBullet": gdjs.PlayScene3Code.GDEnemyBulletObjects5});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDBigAsteroidObjects5Objects = Hashtable.newFrom({"BigAsteroid": gdjs.PlayScene3Code.GDBigAsteroidObjects5});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDDebrisHugeObjects4Objects = Hashtable.newFrom({"DebrisHuge": gdjs.PlayScene3Code.GDDebrisHugeObjects4});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDBulletHitObjects4Objects = Hashtable.newFrom({"BulletHit": gdjs.PlayScene3Code.GDBulletHitObjects4});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDMediumAsteroidObjects5Objects = Hashtable.newFrom({"MediumAsteroid": gdjs.PlayScene3Code.GDMediumAsteroidObjects5});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDMediumAsteroidObjects5Objects = Hashtable.newFrom({"MediumAsteroid": gdjs.PlayScene3Code.GDMediumAsteroidObjects5});
gdjs.PlayScene3Code.eventsList18 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.PlayScene3Code.GDBigAsteroidObjects4, gdjs.PlayScene3Code.GDBigAsteroidObjects5);

gdjs.copyArray(gdjs.PlayScene3Code.GDBulletObjects4, gdjs.PlayScene3Code.GDBulletObjects5);

gdjs.PlayScene3Code.GDMediumAsteroidObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDMediumAsteroidObjects5Objects, (( gdjs.PlayScene3Code.GDBigAsteroidObjects5.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDBigAsteroidObjects5[0].getPointX("")), (( gdjs.PlayScene3Code.GDBigAsteroidObjects5.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDBigAsteroidObjects5[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.PlayScene3Code.GDMediumAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDMediumAsteroidObjects5[i].setAngle(gdjs.random(360));
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDMediumAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDMediumAsteroidObjects5[i].putAroundObject((gdjs.PlayScene3Code.GDBigAsteroidObjects5.length !== 0 ? gdjs.PlayScene3Code.GDBigAsteroidObjects5[0] : null), 15, (( gdjs.PlayScene3Code.GDBulletObjects5.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDBulletObjects5[0].getAngle()) - 90);
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDMediumAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDMediumAsteroidObjects5[i].getBehavior("Physics2").applyTorque(gdjs.randomFloatInRange(-(0.1), 0.1));
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDMediumAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDMediumAsteroidObjects5[i].getBehavior("Physics2").applyPolarForce((( gdjs.PlayScene3Code.GDBulletObjects5.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDBulletObjects5[0].getAngle()) + gdjs.randomFloatInRange(-(60), 0), 5, (gdjs.PlayScene3Code.GDMediumAsteroidObjects5[i].getBehavior("Physics2").getMassCenterX()), (gdjs.PlayScene3Code.GDMediumAsteroidObjects5[i].getBehavior("Physics2").getMassCenterY()));
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.PlayScene3Code.GDBigAsteroidObjects4, gdjs.PlayScene3Code.GDBigAsteroidObjects5);

gdjs.copyArray(gdjs.PlayScene3Code.GDBulletObjects4, gdjs.PlayScene3Code.GDBulletObjects5);

gdjs.PlayScene3Code.GDMediumAsteroidObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDMediumAsteroidObjects5Objects, (( gdjs.PlayScene3Code.GDBigAsteroidObjects5.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDBigAsteroidObjects5[0].getPointX("")), (( gdjs.PlayScene3Code.GDBigAsteroidObjects5.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDBigAsteroidObjects5[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.PlayScene3Code.GDMediumAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDMediumAsteroidObjects5[i].setAngle(gdjs.random(360));
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDMediumAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDMediumAsteroidObjects5[i].putAroundObject((gdjs.PlayScene3Code.GDBigAsteroidObjects5.length !== 0 ? gdjs.PlayScene3Code.GDBigAsteroidObjects5[0] : null), 15, (( gdjs.PlayScene3Code.GDBulletObjects5.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDBulletObjects5[0].getAngle()) + 90);
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDMediumAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDMediumAsteroidObjects5[i].getBehavior("Physics2").applyTorque(gdjs.randomFloatInRange(-(0.1), 0.1));
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDMediumAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDMediumAsteroidObjects5[i].getBehavior("Physics2").applyPolarForce((( gdjs.PlayScene3Code.GDBulletObjects5.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDBulletObjects5[0].getAngle()) + gdjs.randomFloatInRange(0, 60), 5, (gdjs.PlayScene3Code.GDMediumAsteroidObjects5[i].getBehavior("Physics2").getMassCenterX()), (gdjs.PlayScene3Code.GDMediumAsteroidObjects5[i].getBehavior("Physics2").getMassCenterY()));
}
}}

}


};gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDBulletObjects5Objects = Hashtable.newFrom({"Bullet": gdjs.PlayScene3Code.GDBulletObjects5});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDMediumAsteroidObjects5Objects = Hashtable.newFrom({"MediumAsteroid": gdjs.PlayScene3Code.GDMediumAsteroidObjects5});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDEnemyBulletObjects5Objects = Hashtable.newFrom({"EnemyBullet": gdjs.PlayScene3Code.GDEnemyBulletObjects5});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDMediumAsteroidObjects5Objects = Hashtable.newFrom({"MediumAsteroid": gdjs.PlayScene3Code.GDMediumAsteroidObjects5});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDDebrisMediumObjects4Objects = Hashtable.newFrom({"DebrisMedium": gdjs.PlayScene3Code.GDDebrisMediumObjects4});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDBulletHitObjects4Objects = Hashtable.newFrom({"BulletHit": gdjs.PlayScene3Code.GDBulletHitObjects4});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDSmallAsteroidObjects5Objects = Hashtable.newFrom({"SmallAsteroid": gdjs.PlayScene3Code.GDSmallAsteroidObjects5});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDSmallAsteroidObjects5Objects = Hashtable.newFrom({"SmallAsteroid": gdjs.PlayScene3Code.GDSmallAsteroidObjects5});
gdjs.PlayScene3Code.eventsList19 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("BigAsteroid"), gdjs.PlayScene3Code.GDBigAsteroidObjects5);
gdjs.copyArray(gdjs.PlayScene3Code.GDBulletObjects4, gdjs.PlayScene3Code.GDBulletObjects5);

gdjs.copyArray(gdjs.PlayScene3Code.GDMediumAsteroidObjects4, gdjs.PlayScene3Code.GDMediumAsteroidObjects5);

gdjs.PlayScene3Code.GDSmallAsteroidObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDSmallAsteroidObjects5Objects, (( gdjs.PlayScene3Code.GDBigAsteroidObjects5.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDBigAsteroidObjects5[0].getPointX("")), (( gdjs.PlayScene3Code.GDBigAsteroidObjects5.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDBigAsteroidObjects5[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.PlayScene3Code.GDSmallAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDSmallAsteroidObjects5[i].setAngle(gdjs.random(360));
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDSmallAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDSmallAsteroidObjects5[i].putAroundObject((gdjs.PlayScene3Code.GDMediumAsteroidObjects5.length !== 0 ? gdjs.PlayScene3Code.GDMediumAsteroidObjects5[0] : null), 8, (( gdjs.PlayScene3Code.GDBulletObjects5.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDBulletObjects5[0].getAngle()) - 90);
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDSmallAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDSmallAsteroidObjects5[i].getBehavior("Physics2").applyTorque(gdjs.randomFloatInRange(-(0.1), 0.1));
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDSmallAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDSmallAsteroidObjects5[i].getBehavior("Physics2").applyPolarForce((( gdjs.PlayScene3Code.GDBulletObjects5.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDBulletObjects5[0].getAngle()) + gdjs.randomFloatInRange(-(60), 0), 2, (gdjs.PlayScene3Code.GDSmallAsteroidObjects5[i].getBehavior("Physics2").getMassCenterX()), (gdjs.PlayScene3Code.GDSmallAsteroidObjects5[i].getBehavior("Physics2").getMassCenterY()));
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.PlayScene3Code.GDBulletObjects4, gdjs.PlayScene3Code.GDBulletObjects5);

gdjs.copyArray(gdjs.PlayScene3Code.GDMediumAsteroidObjects4, gdjs.PlayScene3Code.GDMediumAsteroidObjects5);

gdjs.PlayScene3Code.GDSmallAsteroidObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDSmallAsteroidObjects5Objects, (( gdjs.PlayScene3Code.GDMediumAsteroidObjects5.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDMediumAsteroidObjects5[0].getPointX("")), (( gdjs.PlayScene3Code.GDMediumAsteroidObjects5.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDMediumAsteroidObjects5[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.PlayScene3Code.GDSmallAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDSmallAsteroidObjects5[i].setAngle(gdjs.random(360));
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDSmallAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDSmallAsteroidObjects5[i].putAroundObject((gdjs.PlayScene3Code.GDMediumAsteroidObjects5.length !== 0 ? gdjs.PlayScene3Code.GDMediumAsteroidObjects5[0] : null), 8, (( gdjs.PlayScene3Code.GDBulletObjects5.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDBulletObjects5[0].getAngle()) + 90);
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDSmallAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDSmallAsteroidObjects5[i].getBehavior("Physics2").applyTorque(gdjs.randomFloatInRange(-(0.1), 0.1));
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDSmallAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDSmallAsteroidObjects5[i].getBehavior("Physics2").applyPolarForce((( gdjs.PlayScene3Code.GDBulletObjects5.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDBulletObjects5[0].getAngle()) + gdjs.randomFloatInRange(0, 60), 2, (gdjs.PlayScene3Code.GDSmallAsteroidObjects5[i].getBehavior("Physics2").getMassCenterX()), (gdjs.PlayScene3Code.GDSmallAsteroidObjects5[i].getBehavior("Physics2").getMassCenterY()));
}
}}

}


};gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDBulletObjects4Objects = Hashtable.newFrom({"Bullet": gdjs.PlayScene3Code.GDBulletObjects4});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDSmallAsteroidObjects4Objects = Hashtable.newFrom({"SmallAsteroid": gdjs.PlayScene3Code.GDSmallAsteroidObjects4});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDEnemyBulletObjects4Objects = Hashtable.newFrom({"EnemyBullet": gdjs.PlayScene3Code.GDEnemyBulletObjects4});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDSmallAsteroidObjects4Objects = Hashtable.newFrom({"SmallAsteroid": gdjs.PlayScene3Code.GDSmallAsteroidObjects4});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDDebrisSmallObjects3Objects = Hashtable.newFrom({"DebrisSmall": gdjs.PlayScene3Code.GDDebrisSmallObjects3});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDBulletHitObjects3Objects = Hashtable.newFrom({"BulletHit": gdjs.PlayScene3Code.GDBulletHitObjects3});
gdjs.PlayScene3Code.eventsList20 = function(runtimeScene) {

};gdjs.PlayScene3Code.eventsList21 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("BigAsteroid"), gdjs.PlayScene3Code.GDBigAsteroidObjects3);

for (gdjs.PlayScene3Code.forEachIndex4 = 0;gdjs.PlayScene3Code.forEachIndex4 < gdjs.PlayScene3Code.GDBigAsteroidObjects3.length;++gdjs.PlayScene3Code.forEachIndex4) {
gdjs.PlayScene3Code.GDBulletObjects4.length = 0;

gdjs.PlayScene3Code.GDBulletHitObjects4.length = 0;

gdjs.PlayScene3Code.GDDebrisHugeObjects4.length = 0;

gdjs.PlayScene3Code.GDEnemyBulletObjects4.length = 0;

gdjs.PlayScene3Code.GDBigAsteroidObjects4.length = 0;


gdjs.PlayScene3Code.forEachTemporary4 = gdjs.PlayScene3Code.GDBigAsteroidObjects3[gdjs.PlayScene3Code.forEachIndex4];
gdjs.PlayScene3Code.GDBigAsteroidObjects4.push(gdjs.PlayScene3Code.forEachTemporary4);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.PlayScene3Code.GDBigAsteroidObjects4_1final.length = 0;
gdjs.PlayScene3Code.GDBulletObjects4_1final.length = 0;
gdjs.PlayScene3Code.GDEnemyBulletObjects4_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.PlayScene3Code.GDBigAsteroidObjects4, gdjs.PlayScene3Code.GDBigAsteroidObjects5);

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.PlayScene3Code.GDBulletObjects5);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDBulletObjects5Objects, gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDBigAsteroidObjects5Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PlayScene3Code.GDBigAsteroidObjects5.length; j < jLen ; ++j) {
        if ( gdjs.PlayScene3Code.GDBigAsteroidObjects4_1final.indexOf(gdjs.PlayScene3Code.GDBigAsteroidObjects5[j]) === -1 )
            gdjs.PlayScene3Code.GDBigAsteroidObjects4_1final.push(gdjs.PlayScene3Code.GDBigAsteroidObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.PlayScene3Code.GDBulletObjects5.length; j < jLen ; ++j) {
        if ( gdjs.PlayScene3Code.GDBulletObjects4_1final.indexOf(gdjs.PlayScene3Code.GDBulletObjects5[j]) === -1 )
            gdjs.PlayScene3Code.GDBulletObjects4_1final.push(gdjs.PlayScene3Code.GDBulletObjects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.PlayScene3Code.GDBigAsteroidObjects4, gdjs.PlayScene3Code.GDBigAsteroidObjects5);

gdjs.copyArray(runtimeScene.getObjects("EnemyBullet"), gdjs.PlayScene3Code.GDEnemyBulletObjects5);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDEnemyBulletObjects5Objects, gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDBigAsteroidObjects5Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PlayScene3Code.GDBigAsteroidObjects5.length; j < jLen ; ++j) {
        if ( gdjs.PlayScene3Code.GDBigAsteroidObjects4_1final.indexOf(gdjs.PlayScene3Code.GDBigAsteroidObjects5[j]) === -1 )
            gdjs.PlayScene3Code.GDBigAsteroidObjects4_1final.push(gdjs.PlayScene3Code.GDBigAsteroidObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.PlayScene3Code.GDEnemyBulletObjects5.length; j < jLen ; ++j) {
        if ( gdjs.PlayScene3Code.GDEnemyBulletObjects4_1final.indexOf(gdjs.PlayScene3Code.GDEnemyBulletObjects5[j]) === -1 )
            gdjs.PlayScene3Code.GDEnemyBulletObjects4_1final.push(gdjs.PlayScene3Code.GDEnemyBulletObjects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.PlayScene3Code.GDBigAsteroidObjects4_1final, gdjs.PlayScene3Code.GDBigAsteroidObjects4);
gdjs.copyArray(gdjs.PlayScene3Code.GDBulletObjects4_1final, gdjs.PlayScene3Code.GDBulletObjects4);
gdjs.copyArray(gdjs.PlayScene3Code.GDEnemyBulletObjects4_1final, gdjs.PlayScene3Code.GDEnemyBulletObjects4);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Explosion.wav", false, 60, gdjs.randomFloatInRange(0.9, 1));
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDDebrisHugeObjects4Objects, (( gdjs.PlayScene3Code.GDBigAsteroidObjects4.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDBigAsteroidObjects4[0].getPointX("")), (( gdjs.PlayScene3Code.GDBigAsteroidObjects4.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDBigAsteroidObjects4[0].getPointY("")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDBulletHitObjects4Objects, (( gdjs.PlayScene3Code.GDBulletObjects4.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDBulletObjects4[0].getPointX("BulletHit")), (( gdjs.PlayScene3Code.GDBulletObjects4.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDBulletObjects4[0].getPointY("BulletHit")), "");
}{for(var i = 0, len = gdjs.PlayScene3Code.GDBigAsteroidObjects4.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDBigAsteroidObjects4[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDEnemyBulletObjects4.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDEnemyBulletObjects4[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDBulletObjects4.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDBulletObjects4[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents: 
gdjs.PlayScene3Code.eventsList18(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("MediumAsteroid"), gdjs.PlayScene3Code.GDMediumAsteroidObjects3);

for (gdjs.PlayScene3Code.forEachIndex4 = 0;gdjs.PlayScene3Code.forEachIndex4 < gdjs.PlayScene3Code.GDMediumAsteroidObjects3.length;++gdjs.PlayScene3Code.forEachIndex4) {
gdjs.PlayScene3Code.GDBulletObjects4.length = 0;

gdjs.PlayScene3Code.GDBulletHitObjects4.length = 0;

gdjs.PlayScene3Code.GDDebrisMediumObjects4.length = 0;

gdjs.PlayScene3Code.GDEnemyBulletObjects4.length = 0;

gdjs.PlayScene3Code.GDMediumAsteroidObjects4.length = 0;


gdjs.PlayScene3Code.forEachTemporary4 = gdjs.PlayScene3Code.GDMediumAsteroidObjects3[gdjs.PlayScene3Code.forEachIndex4];
gdjs.PlayScene3Code.GDMediumAsteroidObjects4.push(gdjs.PlayScene3Code.forEachTemporary4);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.PlayScene3Code.GDBulletObjects4_1final.length = 0;
gdjs.PlayScene3Code.GDEnemyBulletObjects4_1final.length = 0;
gdjs.PlayScene3Code.GDMediumAsteroidObjects4_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.PlayScene3Code.GDBulletObjects5);
gdjs.copyArray(gdjs.PlayScene3Code.GDMediumAsteroidObjects4, gdjs.PlayScene3Code.GDMediumAsteroidObjects5);

isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDBulletObjects5Objects, gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDMediumAsteroidObjects5Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PlayScene3Code.GDBulletObjects5.length; j < jLen ; ++j) {
        if ( gdjs.PlayScene3Code.GDBulletObjects4_1final.indexOf(gdjs.PlayScene3Code.GDBulletObjects5[j]) === -1 )
            gdjs.PlayScene3Code.GDBulletObjects4_1final.push(gdjs.PlayScene3Code.GDBulletObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.PlayScene3Code.GDMediumAsteroidObjects5.length; j < jLen ; ++j) {
        if ( gdjs.PlayScene3Code.GDMediumAsteroidObjects4_1final.indexOf(gdjs.PlayScene3Code.GDMediumAsteroidObjects5[j]) === -1 )
            gdjs.PlayScene3Code.GDMediumAsteroidObjects4_1final.push(gdjs.PlayScene3Code.GDMediumAsteroidObjects5[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("EnemyBullet"), gdjs.PlayScene3Code.GDEnemyBulletObjects5);
gdjs.copyArray(gdjs.PlayScene3Code.GDMediumAsteroidObjects4, gdjs.PlayScene3Code.GDMediumAsteroidObjects5);

isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDEnemyBulletObjects5Objects, gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDMediumAsteroidObjects5Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PlayScene3Code.GDEnemyBulletObjects5.length; j < jLen ; ++j) {
        if ( gdjs.PlayScene3Code.GDEnemyBulletObjects4_1final.indexOf(gdjs.PlayScene3Code.GDEnemyBulletObjects5[j]) === -1 )
            gdjs.PlayScene3Code.GDEnemyBulletObjects4_1final.push(gdjs.PlayScene3Code.GDEnemyBulletObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.PlayScene3Code.GDMediumAsteroidObjects5.length; j < jLen ; ++j) {
        if ( gdjs.PlayScene3Code.GDMediumAsteroidObjects4_1final.indexOf(gdjs.PlayScene3Code.GDMediumAsteroidObjects5[j]) === -1 )
            gdjs.PlayScene3Code.GDMediumAsteroidObjects4_1final.push(gdjs.PlayScene3Code.GDMediumAsteroidObjects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.PlayScene3Code.GDBulletObjects4_1final, gdjs.PlayScene3Code.GDBulletObjects4);
gdjs.copyArray(gdjs.PlayScene3Code.GDEnemyBulletObjects4_1final, gdjs.PlayScene3Code.GDEnemyBulletObjects4);
gdjs.copyArray(gdjs.PlayScene3Code.GDMediumAsteroidObjects4_1final, gdjs.PlayScene3Code.GDMediumAsteroidObjects4);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Explosion.wav", false, 55, gdjs.randomFloatInRange(1, 1.1));
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDDebrisMediumObjects4Objects, (( gdjs.PlayScene3Code.GDMediumAsteroidObjects4.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDMediumAsteroidObjects4[0].getPointX("")), (( gdjs.PlayScene3Code.GDMediumAsteroidObjects4.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDMediumAsteroidObjects4[0].getPointY("")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDBulletHitObjects4Objects, (( gdjs.PlayScene3Code.GDBulletObjects4.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDBulletObjects4[0].getPointX("BulletHit")), (( gdjs.PlayScene3Code.GDBulletObjects4.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDBulletObjects4[0].getPointY("BulletHit")), "");
}{for(var i = 0, len = gdjs.PlayScene3Code.GDMediumAsteroidObjects4.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDMediumAsteroidObjects4[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDBulletObjects4.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDBulletObjects4[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDEnemyBulletObjects4.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDEnemyBulletObjects4[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents: 
gdjs.PlayScene3Code.eventsList19(runtimeScene);} //Subevents end.
}
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("SmallAsteroid"), gdjs.PlayScene3Code.GDSmallAsteroidObjects2);

for (gdjs.PlayScene3Code.forEachIndex3 = 0;gdjs.PlayScene3Code.forEachIndex3 < gdjs.PlayScene3Code.GDSmallAsteroidObjects2.length;++gdjs.PlayScene3Code.forEachIndex3) {
gdjs.PlayScene3Code.GDBulletObjects3.length = 0;

gdjs.PlayScene3Code.GDBulletHitObjects3.length = 0;

gdjs.PlayScene3Code.GDDebrisSmallObjects3.length = 0;

gdjs.PlayScene3Code.GDEnemyBulletObjects3.length = 0;

gdjs.PlayScene3Code.GDSmallAsteroidObjects3.length = 0;


gdjs.PlayScene3Code.forEachTemporary3 = gdjs.PlayScene3Code.GDSmallAsteroidObjects2[gdjs.PlayScene3Code.forEachIndex3];
gdjs.PlayScene3Code.GDSmallAsteroidObjects3.push(gdjs.PlayScene3Code.forEachTemporary3);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.PlayScene3Code.GDBulletObjects3_1final.length = 0;
gdjs.PlayScene3Code.GDEnemyBulletObjects3_1final.length = 0;
gdjs.PlayScene3Code.GDSmallAsteroidObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.PlayScene3Code.GDBulletObjects4);
gdjs.copyArray(gdjs.PlayScene3Code.GDSmallAsteroidObjects3, gdjs.PlayScene3Code.GDSmallAsteroidObjects4);

isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDBulletObjects4Objects, gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDSmallAsteroidObjects4Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PlayScene3Code.GDBulletObjects4.length; j < jLen ; ++j) {
        if ( gdjs.PlayScene3Code.GDBulletObjects3_1final.indexOf(gdjs.PlayScene3Code.GDBulletObjects4[j]) === -1 )
            gdjs.PlayScene3Code.GDBulletObjects3_1final.push(gdjs.PlayScene3Code.GDBulletObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.PlayScene3Code.GDSmallAsteroidObjects4.length; j < jLen ; ++j) {
        if ( gdjs.PlayScene3Code.GDSmallAsteroidObjects3_1final.indexOf(gdjs.PlayScene3Code.GDSmallAsteroidObjects4[j]) === -1 )
            gdjs.PlayScene3Code.GDSmallAsteroidObjects3_1final.push(gdjs.PlayScene3Code.GDSmallAsteroidObjects4[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("EnemyBullet"), gdjs.PlayScene3Code.GDEnemyBulletObjects4);
gdjs.copyArray(gdjs.PlayScene3Code.GDSmallAsteroidObjects3, gdjs.PlayScene3Code.GDSmallAsteroidObjects4);

isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDEnemyBulletObjects4Objects, gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDSmallAsteroidObjects4Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PlayScene3Code.GDEnemyBulletObjects4.length; j < jLen ; ++j) {
        if ( gdjs.PlayScene3Code.GDEnemyBulletObjects3_1final.indexOf(gdjs.PlayScene3Code.GDEnemyBulletObjects4[j]) === -1 )
            gdjs.PlayScene3Code.GDEnemyBulletObjects3_1final.push(gdjs.PlayScene3Code.GDEnemyBulletObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.PlayScene3Code.GDSmallAsteroidObjects4.length; j < jLen ; ++j) {
        if ( gdjs.PlayScene3Code.GDSmallAsteroidObjects3_1final.indexOf(gdjs.PlayScene3Code.GDSmallAsteroidObjects4[j]) === -1 )
            gdjs.PlayScene3Code.GDSmallAsteroidObjects3_1final.push(gdjs.PlayScene3Code.GDSmallAsteroidObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.PlayScene3Code.GDBulletObjects3_1final, gdjs.PlayScene3Code.GDBulletObjects3);
gdjs.copyArray(gdjs.PlayScene3Code.GDEnemyBulletObjects3_1final, gdjs.PlayScene3Code.GDEnemyBulletObjects3);
gdjs.copyArray(gdjs.PlayScene3Code.GDSmallAsteroidObjects3_1final, gdjs.PlayScene3Code.GDSmallAsteroidObjects3);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Explosion.wav", false, 50, gdjs.randomFloatInRange(1.1, 1.2));
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDDebrisSmallObjects3Objects, (( gdjs.PlayScene3Code.GDSmallAsteroidObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDSmallAsteroidObjects3[0].getPointX("")), (( gdjs.PlayScene3Code.GDSmallAsteroidObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDSmallAsteroidObjects3[0].getPointY("")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDBulletHitObjects3Objects, (( gdjs.PlayScene3Code.GDBulletObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDBulletObjects3[0].getPointX("BulletHit")), (( gdjs.PlayScene3Code.GDBulletObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDBulletObjects3[0].getPointY("BulletHit")), "");
}{for(var i = 0, len = gdjs.PlayScene3Code.GDSmallAsteroidObjects3.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDSmallAsteroidObjects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDEnemyBulletObjects3.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDEnemyBulletObjects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDBulletObjects3.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDBulletObjects3[i].deleteFromScene(runtimeScene);
}
}}
}

}


};gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.PlayScene3Code.GDPlayerObjects2});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDBigAsteroidObjects2ObjectsGDgdjs_9546PlayScene3Code_9546GDMediumAsteroidObjects2ObjectsGDgdjs_9546PlayScene3Code_9546GDSmallAsteroidObjects2Objects = Hashtable.newFrom({"BigAsteroid": gdjs.PlayScene3Code.GDBigAsteroidObjects2, "MediumAsteroid": gdjs.PlayScene3Code.GDMediumAsteroidObjects2, "SmallAsteroid": gdjs.PlayScene3Code.GDSmallAsteroidObjects2});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.PlayScene3Code.GDPlayerObjects2});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDEnemyObjects2Objects = Hashtable.newFrom({"Enemy": gdjs.PlayScene3Code.GDEnemyObjects2});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDDebrisHugeObjects2Objects = Hashtable.newFrom({"DebrisHuge": gdjs.PlayScene3Code.GDDebrisHugeObjects2});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDEnemyBulletObjects2Objects = Hashtable.newFrom({"EnemyBullet": gdjs.PlayScene3Code.GDEnemyBulletObjects2});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.PlayScene3Code.GDPlayerObjects2});
gdjs.PlayScene3Code.eventsList22 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtsExt__CameraShake__SetLayerTranslationAmplitude.func(runtimeScene, 1, 1, "", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__CameraShake__SetLayerRotationAmplitude.func(runtimeScene, 1, "", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__CameraShake__SetLayerZoomAmplitude.func(runtimeScene, 1.01, "", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__CameraShake__SetDefaultShakingFrequency.func(runtimeScene, 10, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("BigAsteroid"), gdjs.PlayScene3Code.GDBigAsteroidObjects2);
gdjs.copyArray(runtimeScene.getObjects("MediumAsteroid"), gdjs.PlayScene3Code.GDMediumAsteroidObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PlayScene3Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("SmallAsteroid"), gdjs.PlayScene3Code.GDSmallAsteroidObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.physics2.objectsCollide(gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDPlayerObjects2Objects, "Physics2", gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDBigAsteroidObjects2ObjectsGDgdjs_9546PlayScene3Code_9546GDMediumAsteroidObjects2ObjectsGDgdjs_9546PlayScene3Code_9546GDSmallAsteroidObjects2Objects, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("LifeBar"), gdjs.PlayScene3Code.GDLifeBarObjects2);
/* Reuse gdjs.PlayScene3Code.GDPlayerObjects2 */
{gdjs.evtTools.sound.playSound(runtimeScene, "Bump.wav", false, 60, gdjs.randomFloatInRange(0.9, 1.1));
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 1, 0, 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.PlayScene3Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDPlayerObjects2[i].getBehavior("Flash").Flash(1.5, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDLifeBarObjects2.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDLifeBarObjects2[i].getBehavior("Flash").Flash(1.5, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDPlayerObjects2[i].getBehavior("Health").Hit(1, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDLifeBarObjects2.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDLifeBarObjects2[i].SetValue((( gdjs.PlayScene3Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDPlayerObjects2[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.PlayScene3Code.GDEnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PlayScene3Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.physics2.objectsCollide(gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDPlayerObjects2Objects, "Physics2", gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDEnemyObjects2Objects, false);
if (isConditionTrue_0) {
/* Reuse gdjs.PlayScene3Code.GDEnemyObjects2 */
gdjs.copyArray(runtimeScene.getObjects("LifeBar"), gdjs.PlayScene3Code.GDLifeBarObjects2);
/* Reuse gdjs.PlayScene3Code.GDPlayerObjects2 */
gdjs.PlayScene3Code.GDDebrisHugeObjects2.length = 0;

{gdjs.evtTools.sound.playSound(runtimeScene, "Explosion.wav", false, 50, gdjs.randomFloatInRange(1.1, 1.2));
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDDebrisHugeObjects2Objects, (( gdjs.PlayScene3Code.GDEnemyObjects2.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDEnemyObjects2[0].getPointX("Origin")), (( gdjs.PlayScene3Code.GDEnemyObjects2.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDEnemyObjects2[0].getPointY("Origin")), "");
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 1, 0, 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.PlayScene3Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDPlayerObjects2[i].getBehavior("Flash").Flash(1.5, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDLifeBarObjects2.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDLifeBarObjects2[i].getBehavior("Flash").Flash(1.5, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDPlayerObjects2[i].getBehavior("Health").Hit(1, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDLifeBarObjects2.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDLifeBarObjects2[i].SetValue((( gdjs.PlayScene3Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDPlayerObjects2[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDEnemyObjects2.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDEnemyObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("EnemyBullet"), gdjs.PlayScene3Code.GDEnemyBulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PlayScene3Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDEnemyBulletObjects2Objects, gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDPlayerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.PlayScene3Code.GDEnemyBulletObjects2 */
gdjs.copyArray(runtimeScene.getObjects("LifeBar"), gdjs.PlayScene3Code.GDLifeBarObjects2);
/* Reuse gdjs.PlayScene3Code.GDPlayerObjects2 */
{gdjs.evtTools.sound.playSound(runtimeScene, "Hit 1.aac", false, 60, gdjs.randomFloatInRange(0.9, 1.1));
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 1, 0, 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.PlayScene3Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDPlayerObjects2[i].getBehavior("Flash").Flash(1.5, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDLifeBarObjects2.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDLifeBarObjects2[i].getBehavior("Flash").Flash(1.5, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDPlayerObjects2[i].getBehavior("Health").Hit(1, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDLifeBarObjects2.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDLifeBarObjects2[i].SetValue((( gdjs.PlayScene3Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDPlayerObjects2[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDEnemyBulletObjects2.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDEnemyBulletObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PlayScene3Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PlayScene3Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.PlayScene3Code.GDPlayerObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.PlayScene3Code.GDPlayerObjects1[k] = gdjs.PlayScene3Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.PlayScene3Code.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("MotionTrail"), gdjs.PlayScene3Code.GDMotionTrailObjects1);
{for(var i = 0, len = gdjs.PlayScene3Code.GDMotionTrailObjects1.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDMotionTrailObjects1[i].stopEmission();
}
}{runtimeScene.getScene().getVariables().get("State").setString("GameOverAnimation");
}}

}


};gdjs.PlayScene3Code.eventsList23 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("TimeText"), gdjs.PlayScene3Code.GDTimeTextObjects2);
{for(var i = 0, len = gdjs.PlayScene3Code.GDTimeTextObjects2.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDTimeTextObjects2[i].getBehavior("Text").setText("Time:" + gdjs.evtsExt__TimeFormatter__SecondsToHHMMSS000.func(runtimeScene, gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSeconds(runtimeScene, "Timer"), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
}}

}


{


gdjs.PlayScene3Code.eventsList4(runtimeScene);
}


{


gdjs.PlayScene3Code.eventsList5(runtimeScene);
}


{


gdjs.PlayScene3Code.eventsList6(runtimeScene);
}


{


gdjs.PlayScene3Code.eventsList9(runtimeScene);
}


{


gdjs.PlayScene3Code.eventsList12(runtimeScene);
}


{


gdjs.PlayScene3Code.eventsList15(runtimeScene);
}


{


gdjs.PlayScene3Code.eventsList17(runtimeScene);
}


{


gdjs.PlayScene3Code.eventsList21(runtimeScene);
}


{


gdjs.PlayScene3Code.eventsList22(runtimeScene);
}


};gdjs.PlayScene3Code.eventsList24 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("State")) == "GamePlaying";
if (isConditionTrue_0) {

{ //Subevents
gdjs.PlayScene3Code.eventsList23(runtimeScene);} //End of subevents
}

}


};gdjs.PlayScene3Code.eventsList25 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15729156);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "Menu", 0, 0, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ContinueButton"), gdjs.PlayScene3Code.GDContinueButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PlayScene3Code.GDContinueButtonObjects1.length;i<l;++i) {
    if ( gdjs.PlayScene3Code.GDContinueButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.PlayScene3Code.GDContinueButtonObjects1[k] = gdjs.PlayScene3Code.GDContinueButtonObjects1[i];
        ++k;
    }
}
gdjs.PlayScene3Code.GDContinueButtonObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.PlayScene3Code.GDContinueButtonObjects1 */
gdjs.copyArray(runtimeScene.getObjects("MenuText"), gdjs.PlayScene3Code.GDMenuTextObjects1);
{runtimeScene.getScene().getVariables().get("State").setString("GamePlaying");
}{gdjs.evtTools.runtimeScene.unpauseTimer(runtimeScene, "Timer");
}{for(var i = 0, len = gdjs.PlayScene3Code.GDMenuTextObjects1.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDMenuTextObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDContinueButtonObjects1.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDContinueButtonObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.PlayScene3Code.eventsList26 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().get("State").setString("MenuAnimation");
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "Timer");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("State")) == "MenuAnimation";
if (isConditionTrue_0) {

{ //Subevents
gdjs.PlayScene3Code.eventsList25(runtimeScene);} //End of subevents
}

}


};gdjs.PlayScene3Code.mapOfEmptyGDBigAsteroidObjectsEmptyGDMediumAsteroidObjectsEmptyGDSmallAsteroidObjects = Hashtable.newFrom({"BigAsteroid": [], "MediumAsteroid": [], "SmallAsteroid": []});
gdjs.PlayScene3Code.mapOfEmptyGDEnemyObjects = Hashtable.newFrom({"Enemy": []});
gdjs.PlayScene3Code.mapOfEmptyGDEnemyGreenObjects = Hashtable.newFrom({"EnemyGreen": []});
gdjs.PlayScene3Code.mapOfEmptyGDEnemyBlueObjects = Hashtable.newFrom({"EnemyBlue": []});
gdjs.PlayScene3Code.asyncCallback15736716 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("ContinueButton"), gdjs.PlayScene3Code.GDContinueButtonObjects6);

{for(var i = 0, len = gdjs.PlayScene3Code.GDContinueButtonObjects6.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDContinueButtonObjects6[i].hide(false);
}
}{runtimeScene.getScene().getVariables().get("State").setString("FinishContinue");
}}
gdjs.PlayScene3Code.eventsList27 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
/* Don't save ContinueButton as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.PlayScene3Code.asyncCallback15736716(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.PlayScene3Code.asyncCallback15737148 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("TimeText4"), gdjs.PlayScene3Code.GDTimeText4Objects5);

{for(var i = 0, len = gdjs.PlayScene3Code.GDTimeText4Objects5.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDTimeText4Objects5[i].hide(false);
}
}
{ //Subevents
gdjs.PlayScene3Code.eventsList27(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.PlayScene3Code.eventsList28 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
/* Don't save ContinueButton as it will be provided by the parent asyncObjectsList. */
/* Don't save TimeText4 as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.PlayScene3Code.asyncCallback15737148(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.PlayScene3Code.asyncCallback15736956 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("TimeText3"), gdjs.PlayScene3Code.GDTimeText3Objects4);

{for(var i = 0, len = gdjs.PlayScene3Code.GDTimeText3Objects4.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDTimeText3Objects4[i].hide(false);
}
}
{ //Subevents
gdjs.PlayScene3Code.eventsList28(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.PlayScene3Code.eventsList29 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
/* Don't save ContinueButton as it will be provided by the parent asyncObjectsList. */
/* Don't save TimeText3 as it will be provided by the parent asyncObjectsList. */
/* Don't save TimeText4 as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.PlayScene3Code.asyncCallback15736956(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.PlayScene3Code.asyncCallback15736644 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("TimeText2"), gdjs.PlayScene3Code.GDTimeText2Objects3);

{for(var i = 0, len = gdjs.PlayScene3Code.GDTimeText2Objects3.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDTimeText2Objects3[i].hide(false);
}
}
{ //Subevents
gdjs.PlayScene3Code.eventsList29(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.PlayScene3Code.eventsList30 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.PlayScene3Code.GDContinueButtonObjects2) asyncObjectsList.addObject("ContinueButton", obj);
for (const obj of gdjs.PlayScene3Code.GDTimeText2Objects2) asyncObjectsList.addObject("TimeText2", obj);
for (const obj of gdjs.PlayScene3Code.GDTimeText3Objects2) asyncObjectsList.addObject("TimeText3", obj);
for (const obj of gdjs.PlayScene3Code.GDTimeText4Objects2) asyncObjectsList.addObject("TimeText4", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.PlayScene3Code.asyncCallback15736644(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.PlayScene3Code.eventsList31 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15735340);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "Finish", 0, 0, 0);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15735988);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ContinueButton"), gdjs.PlayScene3Code.GDContinueButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("TimeText2"), gdjs.PlayScene3Code.GDTimeText2Objects2);
gdjs.copyArray(runtimeScene.getObjects("TimeText3"), gdjs.PlayScene3Code.GDTimeText3Objects2);
gdjs.copyArray(runtimeScene.getObjects("TimeText4"), gdjs.PlayScene3Code.GDTimeText4Objects2);
{for(var i = 0, len = gdjs.PlayScene3Code.GDTimeText2Objects2.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDTimeText2Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDTimeText3Objects2.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDTimeText3Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDTimeText4Objects2.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDTimeText4Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDContinueButtonObjects2.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDContinueButtonObjects2[i].hide();
}
}
{ //Subevents
gdjs.PlayScene3Code.eventsList30(runtimeScene);} //End of subevents
}

}


};gdjs.PlayScene3Code.eventsList32 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene3Code.mapOfEmptyGDBigAsteroidObjectsEmptyGDMediumAsteroidObjectsEmptyGDSmallAsteroidObjects) == 0;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene3Code.mapOfEmptyGDEnemyObjects) == 0;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene3Code.mapOfEmptyGDEnemyGreenObjects) == 0;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene3Code.mapOfEmptyGDEnemyBlueObjects) == 0;
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TimeText2"), gdjs.PlayScene3Code.GDTimeText2Objects2);
gdjs.copyArray(runtimeScene.getObjects("TimeText3"), gdjs.PlayScene3Code.GDTimeText3Objects2);
gdjs.copyArray(runtimeScene.getObjects("TimeText4"), gdjs.PlayScene3Code.GDTimeText4Objects2);
gdjs.copyArray(runtimeScene.getObjects("TutorialText"), gdjs.PlayScene3Code.GDTutorialTextObjects2);
{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "EnemyTimer");
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "UFOTimer");
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "BlueTimer");
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "Timer");
}{for(var i = 0, len = gdjs.PlayScene3Code.GDTimeText2Objects2.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDTimeText2Objects2[i].getBehavior("Text").setText("Time 1:" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)));
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDTimeText3Objects2.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDTimeText3Objects2[i].getBehavior("Text").setText("Time 2:" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)));
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDTimeText4Objects2.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDTimeText4Objects2[i].getBehavior("Text").setText("Time 3:" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(2)));
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDTutorialTextObjects2.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDTutorialTextObjects2[i].hide();
}
}{runtimeScene.getScene().getVariables().get("State").setString("FinishScreen");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("State")) == "FinishScreen";
if (isConditionTrue_0) {

{ //Subevents
gdjs.PlayScene3Code.eventsList31(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("State")) == "FinishContinue";
if (isConditionTrue_0) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("ContinueButton"), gdjs.PlayScene3Code.GDContinueButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PlayScene3Code.GDContinueButtonObjects1.length;i<l;++i) {
    if ( gdjs.PlayScene3Code.GDContinueButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.PlayScene3Code.GDContinueButtonObjects1[k] = gdjs.PlayScene3Code.GDContinueButtonObjects1[i];
        ++k;
    }
}
gdjs.PlayScene3Code.GDContinueButtonObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "TitleScene", false);
}}

}


};gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDDeathShipParticleObjects3Objects = Hashtable.newFrom({"DeathShipParticle": gdjs.PlayScene3Code.GDDeathShipParticleObjects3});
gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDDeathDebrisParticleObjects3Objects = Hashtable.newFrom({"DeathDebrisParticle": gdjs.PlayScene3Code.GDDeathDebrisParticleObjects3});
gdjs.PlayScene3Code.asyncCallback15742748 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("ContinueText"), gdjs.PlayScene3Code.GDContinueTextObjects3);

{for(var i = 0, len = gdjs.PlayScene3Code.GDContinueTextObjects3.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDContinueTextObjects3[i].hide(false);
}
}{runtimeScene.getScene().getVariables().get("State").setString("GameOverWaitKey");
}}
gdjs.PlayScene3Code.eventsList33 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.PlayScene3Code.GDContinueTextObjects2) asyncObjectsList.addObject("ContinueText", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.PlayScene3Code.asyncCallback15742748(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.PlayScene3Code.eventsList34 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15740220);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PlayScene3Code.GDPlayerObjects3);
gdjs.PlayScene3Code.GDDeathDebrisParticleObjects3.length = 0;

gdjs.PlayScene3Code.GDDeathShipParticleObjects3.length = 0;

{gdjs.evtTools.sound.playSound(runtimeScene, "Death.wav", false, 50, 1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDDeathShipParticleObjects3Objects, (( gdjs.PlayScene3Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDPlayerObjects3[0].getPointX("")), (( gdjs.PlayScene3Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDPlayerObjects3[0].getPointY("")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayScene3Code.mapOfGDgdjs_9546PlayScene3Code_9546GDDeathDebrisParticleObjects3Objects, (( gdjs.PlayScene3Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDPlayerObjects3[0].getPointX("")), (( gdjs.PlayScene3Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDPlayerObjects3[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.PlayScene3Code.GDDeathShipParticleObjects3.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDDeathShipParticleObjects3[i].setAngle((( gdjs.PlayScene3Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.PlayScene3Code.GDPlayerObjects3[0].getAngle()));
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDPlayerObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15741732);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "GameOver", 0, 0, 0);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15741868);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ContinueText"), gdjs.PlayScene3Code.GDContinueTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("TutorialText"), gdjs.PlayScene3Code.GDTutorialTextObjects2);
{for(var i = 0, len = gdjs.PlayScene3Code.GDTutorialTextObjects2.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDTutorialTextObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.PlayScene3Code.GDContinueTextObjects2.length ;i < len;++i) {
    gdjs.PlayScene3Code.GDContinueTextObjects2[i].hide();
}
}
{ //Subevents
gdjs.PlayScene3Code.eventsList33(runtimeScene);} //End of subevents
}

}


};gdjs.PlayScene3Code.eventsList35 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.anyKeyReleased(runtimeScene);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "TitleScene", false);
}}

}


};gdjs.PlayScene3Code.eventsList36 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("State")) == "GameOverAnimation";
if (isConditionTrue_0) {

{ //Subevents
gdjs.PlayScene3Code.eventsList34(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("State")) == "GameOverWaitKey";
if (isConditionTrue_0) {

{ //Subevents
gdjs.PlayScene3Code.eventsList35(runtimeScene);} //End of subevents
}

}


};gdjs.PlayScene3Code.eventsList37 = function(runtimeScene) {

{



}


{


gdjs.PlayScene3Code.eventsList3(runtimeScene);
}


{


gdjs.PlayScene3Code.eventsList24(runtimeScene);
}


{


gdjs.PlayScene3Code.eventsList26(runtimeScene);
}


{


gdjs.PlayScene3Code.eventsList32(runtimeScene);
}


{


gdjs.PlayScene3Code.eventsList36(runtimeScene);
}


};

gdjs.PlayScene3Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.PlayScene3Code.GDPlayerObjects1.length = 0;
gdjs.PlayScene3Code.GDPlayerObjects2.length = 0;
gdjs.PlayScene3Code.GDPlayerObjects3.length = 0;
gdjs.PlayScene3Code.GDPlayerObjects4.length = 0;
gdjs.PlayScene3Code.GDPlayerObjects5.length = 0;
gdjs.PlayScene3Code.GDPlayerObjects6.length = 0;
gdjs.PlayScene3Code.GDBulletObjects1.length = 0;
gdjs.PlayScene3Code.GDBulletObjects2.length = 0;
gdjs.PlayScene3Code.GDBulletObjects3.length = 0;
gdjs.PlayScene3Code.GDBulletObjects4.length = 0;
gdjs.PlayScene3Code.GDBulletObjects5.length = 0;
gdjs.PlayScene3Code.GDBulletObjects6.length = 0;
gdjs.PlayScene3Code.GDBigAsteroidObjects1.length = 0;
gdjs.PlayScene3Code.GDBigAsteroidObjects2.length = 0;
gdjs.PlayScene3Code.GDBigAsteroidObjects3.length = 0;
gdjs.PlayScene3Code.GDBigAsteroidObjects4.length = 0;
gdjs.PlayScene3Code.GDBigAsteroidObjects5.length = 0;
gdjs.PlayScene3Code.GDBigAsteroidObjects6.length = 0;
gdjs.PlayScene3Code.GDMediumAsteroidObjects1.length = 0;
gdjs.PlayScene3Code.GDMediumAsteroidObjects2.length = 0;
gdjs.PlayScene3Code.GDMediumAsteroidObjects3.length = 0;
gdjs.PlayScene3Code.GDMediumAsteroidObjects4.length = 0;
gdjs.PlayScene3Code.GDMediumAsteroidObjects5.length = 0;
gdjs.PlayScene3Code.GDMediumAsteroidObjects6.length = 0;
gdjs.PlayScene3Code.GDSmallAsteroidObjects1.length = 0;
gdjs.PlayScene3Code.GDSmallAsteroidObjects2.length = 0;
gdjs.PlayScene3Code.GDSmallAsteroidObjects3.length = 0;
gdjs.PlayScene3Code.GDSmallAsteroidObjects4.length = 0;
gdjs.PlayScene3Code.GDSmallAsteroidObjects5.length = 0;
gdjs.PlayScene3Code.GDSmallAsteroidObjects6.length = 0;
gdjs.PlayScene3Code.GDLifeBarObjects1.length = 0;
gdjs.PlayScene3Code.GDLifeBarObjects2.length = 0;
gdjs.PlayScene3Code.GDLifeBarObjects3.length = 0;
gdjs.PlayScene3Code.GDLifeBarObjects4.length = 0;
gdjs.PlayScene3Code.GDLifeBarObjects5.length = 0;
gdjs.PlayScene3Code.GDLifeBarObjects6.length = 0;
gdjs.PlayScene3Code.GDGameOverObjects1.length = 0;
gdjs.PlayScene3Code.GDGameOverObjects2.length = 0;
gdjs.PlayScene3Code.GDGameOverObjects3.length = 0;
gdjs.PlayScene3Code.GDGameOverObjects4.length = 0;
gdjs.PlayScene3Code.GDGameOverObjects5.length = 0;
gdjs.PlayScene3Code.GDGameOverObjects6.length = 0;
gdjs.PlayScene3Code.GDDeathShipParticleObjects1.length = 0;
gdjs.PlayScene3Code.GDDeathShipParticleObjects2.length = 0;
gdjs.PlayScene3Code.GDDeathShipParticleObjects3.length = 0;
gdjs.PlayScene3Code.GDDeathShipParticleObjects4.length = 0;
gdjs.PlayScene3Code.GDDeathShipParticleObjects5.length = 0;
gdjs.PlayScene3Code.GDDeathShipParticleObjects6.length = 0;
gdjs.PlayScene3Code.GDDeathDebrisParticleObjects1.length = 0;
gdjs.PlayScene3Code.GDDeathDebrisParticleObjects2.length = 0;
gdjs.PlayScene3Code.GDDeathDebrisParticleObjects3.length = 0;
gdjs.PlayScene3Code.GDDeathDebrisParticleObjects4.length = 0;
gdjs.PlayScene3Code.GDDeathDebrisParticleObjects5.length = 0;
gdjs.PlayScene3Code.GDDeathDebrisParticleObjects6.length = 0;
gdjs.PlayScene3Code.GDDebrisHugeObjects1.length = 0;
gdjs.PlayScene3Code.GDDebrisHugeObjects2.length = 0;
gdjs.PlayScene3Code.GDDebrisHugeObjects3.length = 0;
gdjs.PlayScene3Code.GDDebrisHugeObjects4.length = 0;
gdjs.PlayScene3Code.GDDebrisHugeObjects5.length = 0;
gdjs.PlayScene3Code.GDDebrisHugeObjects6.length = 0;
gdjs.PlayScene3Code.GDDebrisMediumObjects1.length = 0;
gdjs.PlayScene3Code.GDDebrisMediumObjects2.length = 0;
gdjs.PlayScene3Code.GDDebrisMediumObjects3.length = 0;
gdjs.PlayScene3Code.GDDebrisMediumObjects4.length = 0;
gdjs.PlayScene3Code.GDDebrisMediumObjects5.length = 0;
gdjs.PlayScene3Code.GDDebrisMediumObjects6.length = 0;
gdjs.PlayScene3Code.GDDebrisSmallObjects1.length = 0;
gdjs.PlayScene3Code.GDDebrisSmallObjects2.length = 0;
gdjs.PlayScene3Code.GDDebrisSmallObjects3.length = 0;
gdjs.PlayScene3Code.GDDebrisSmallObjects4.length = 0;
gdjs.PlayScene3Code.GDDebrisSmallObjects5.length = 0;
gdjs.PlayScene3Code.GDDebrisSmallObjects6.length = 0;
gdjs.PlayScene3Code.GDBulletHitObjects1.length = 0;
gdjs.PlayScene3Code.GDBulletHitObjects2.length = 0;
gdjs.PlayScene3Code.GDBulletHitObjects3.length = 0;
gdjs.PlayScene3Code.GDBulletHitObjects4.length = 0;
gdjs.PlayScene3Code.GDBulletHitObjects5.length = 0;
gdjs.PlayScene3Code.GDBulletHitObjects6.length = 0;
gdjs.PlayScene3Code.GDBulletFlashObjects1.length = 0;
gdjs.PlayScene3Code.GDBulletFlashObjects2.length = 0;
gdjs.PlayScene3Code.GDBulletFlashObjects3.length = 0;
gdjs.PlayScene3Code.GDBulletFlashObjects4.length = 0;
gdjs.PlayScene3Code.GDBulletFlashObjects5.length = 0;
gdjs.PlayScene3Code.GDBulletFlashObjects6.length = 0;
gdjs.PlayScene3Code.GDStarBackgroundObjects1.length = 0;
gdjs.PlayScene3Code.GDStarBackgroundObjects2.length = 0;
gdjs.PlayScene3Code.GDStarBackgroundObjects3.length = 0;
gdjs.PlayScene3Code.GDStarBackgroundObjects4.length = 0;
gdjs.PlayScene3Code.GDStarBackgroundObjects5.length = 0;
gdjs.PlayScene3Code.GDStarBackgroundObjects6.length = 0;
gdjs.PlayScene3Code.GDMotionTrailObjects1.length = 0;
gdjs.PlayScene3Code.GDMotionTrailObjects2.length = 0;
gdjs.PlayScene3Code.GDMotionTrailObjects3.length = 0;
gdjs.PlayScene3Code.GDMotionTrailObjects4.length = 0;
gdjs.PlayScene3Code.GDMotionTrailObjects5.length = 0;
gdjs.PlayScene3Code.GDMotionTrailObjects6.length = 0;
gdjs.PlayScene3Code.GDTutorialTextObjects1.length = 0;
gdjs.PlayScene3Code.GDTutorialTextObjects2.length = 0;
gdjs.PlayScene3Code.GDTutorialTextObjects3.length = 0;
gdjs.PlayScene3Code.GDTutorialTextObjects4.length = 0;
gdjs.PlayScene3Code.GDTutorialTextObjects5.length = 0;
gdjs.PlayScene3Code.GDTutorialTextObjects6.length = 0;
gdjs.PlayScene3Code.GDContinueTextObjects1.length = 0;
gdjs.PlayScene3Code.GDContinueTextObjects2.length = 0;
gdjs.PlayScene3Code.GDContinueTextObjects3.length = 0;
gdjs.PlayScene3Code.GDContinueTextObjects4.length = 0;
gdjs.PlayScene3Code.GDContinueTextObjects5.length = 0;
gdjs.PlayScene3Code.GDContinueTextObjects6.length = 0;
gdjs.PlayScene3Code.GDRightButtonObjects1.length = 0;
gdjs.PlayScene3Code.GDRightButtonObjects2.length = 0;
gdjs.PlayScene3Code.GDRightButtonObjects3.length = 0;
gdjs.PlayScene3Code.GDRightButtonObjects4.length = 0;
gdjs.PlayScene3Code.GDRightButtonObjects5.length = 0;
gdjs.PlayScene3Code.GDRightButtonObjects6.length = 0;
gdjs.PlayScene3Code.GDLeftButtonObjects1.length = 0;
gdjs.PlayScene3Code.GDLeftButtonObjects2.length = 0;
gdjs.PlayScene3Code.GDLeftButtonObjects3.length = 0;
gdjs.PlayScene3Code.GDLeftButtonObjects4.length = 0;
gdjs.PlayScene3Code.GDLeftButtonObjects5.length = 0;
gdjs.PlayScene3Code.GDLeftButtonObjects6.length = 0;
gdjs.PlayScene3Code.GDTopButtonObjects1.length = 0;
gdjs.PlayScene3Code.GDTopButtonObjects2.length = 0;
gdjs.PlayScene3Code.GDTopButtonObjects3.length = 0;
gdjs.PlayScene3Code.GDTopButtonObjects4.length = 0;
gdjs.PlayScene3Code.GDTopButtonObjects5.length = 0;
gdjs.PlayScene3Code.GDTopButtonObjects6.length = 0;
gdjs.PlayScene3Code.GDFireButtonObjects1.length = 0;
gdjs.PlayScene3Code.GDFireButtonObjects2.length = 0;
gdjs.PlayScene3Code.GDFireButtonObjects3.length = 0;
gdjs.PlayScene3Code.GDFireButtonObjects4.length = 0;
gdjs.PlayScene3Code.GDFireButtonObjects5.length = 0;
gdjs.PlayScene3Code.GDFireButtonObjects6.length = 0;
gdjs.PlayScene3Code.GDEnemyBulletObjects1.length = 0;
gdjs.PlayScene3Code.GDEnemyBulletObjects2.length = 0;
gdjs.PlayScene3Code.GDEnemyBulletObjects3.length = 0;
gdjs.PlayScene3Code.GDEnemyBulletObjects4.length = 0;
gdjs.PlayScene3Code.GDEnemyBulletObjects5.length = 0;
gdjs.PlayScene3Code.GDEnemyBulletObjects6.length = 0;
gdjs.PlayScene3Code.GDEnemyObjects1.length = 0;
gdjs.PlayScene3Code.GDEnemyObjects2.length = 0;
gdjs.PlayScene3Code.GDEnemyObjects3.length = 0;
gdjs.PlayScene3Code.GDEnemyObjects4.length = 0;
gdjs.PlayScene3Code.GDEnemyObjects5.length = 0;
gdjs.PlayScene3Code.GDEnemyObjects6.length = 0;
gdjs.PlayScene3Code.GDTitleTextObjects1.length = 0;
gdjs.PlayScene3Code.GDTitleTextObjects2.length = 0;
gdjs.PlayScene3Code.GDTitleTextObjects3.length = 0;
gdjs.PlayScene3Code.GDTitleTextObjects4.length = 0;
gdjs.PlayScene3Code.GDTitleTextObjects5.length = 0;
gdjs.PlayScene3Code.GDTitleTextObjects6.length = 0;
gdjs.PlayScene3Code.GDHealthPowerObjects1.length = 0;
gdjs.PlayScene3Code.GDHealthPowerObjects2.length = 0;
gdjs.PlayScene3Code.GDHealthPowerObjects3.length = 0;
gdjs.PlayScene3Code.GDHealthPowerObjects4.length = 0;
gdjs.PlayScene3Code.GDHealthPowerObjects5.length = 0;
gdjs.PlayScene3Code.GDHealthPowerObjects6.length = 0;
gdjs.PlayScene3Code.GDNextLevelObjects1.length = 0;
gdjs.PlayScene3Code.GDNextLevelObjects2.length = 0;
gdjs.PlayScene3Code.GDNextLevelObjects3.length = 0;
gdjs.PlayScene3Code.GDNextLevelObjects4.length = 0;
gdjs.PlayScene3Code.GDNextLevelObjects5.length = 0;
gdjs.PlayScene3Code.GDNextLevelObjects6.length = 0;
gdjs.PlayScene3Code.GDDeathEnemyParticleObjects1.length = 0;
gdjs.PlayScene3Code.GDDeathEnemyParticleObjects2.length = 0;
gdjs.PlayScene3Code.GDDeathEnemyParticleObjects3.length = 0;
gdjs.PlayScene3Code.GDDeathEnemyParticleObjects4.length = 0;
gdjs.PlayScene3Code.GDDeathEnemyParticleObjects5.length = 0;
gdjs.PlayScene3Code.GDDeathEnemyParticleObjects6.length = 0;
gdjs.PlayScene3Code.GDMenuTextObjects1.length = 0;
gdjs.PlayScene3Code.GDMenuTextObjects2.length = 0;
gdjs.PlayScene3Code.GDMenuTextObjects3.length = 0;
gdjs.PlayScene3Code.GDMenuTextObjects4.length = 0;
gdjs.PlayScene3Code.GDMenuTextObjects5.length = 0;
gdjs.PlayScene3Code.GDMenuTextObjects6.length = 0;
gdjs.PlayScene3Code.GDContinueButtonObjects1.length = 0;
gdjs.PlayScene3Code.GDContinueButtonObjects2.length = 0;
gdjs.PlayScene3Code.GDContinueButtonObjects3.length = 0;
gdjs.PlayScene3Code.GDContinueButtonObjects4.length = 0;
gdjs.PlayScene3Code.GDContinueButtonObjects5.length = 0;
gdjs.PlayScene3Code.GDContinueButtonObjects6.length = 0;
gdjs.PlayScene3Code.GDEnemyGreenObjects1.length = 0;
gdjs.PlayScene3Code.GDEnemyGreenObjects2.length = 0;
gdjs.PlayScene3Code.GDEnemyGreenObjects3.length = 0;
gdjs.PlayScene3Code.GDEnemyGreenObjects4.length = 0;
gdjs.PlayScene3Code.GDEnemyGreenObjects5.length = 0;
gdjs.PlayScene3Code.GDEnemyGreenObjects6.length = 0;
gdjs.PlayScene3Code.GDDeathGreenEnemyParticleObjects1.length = 0;
gdjs.PlayScene3Code.GDDeathGreenEnemyParticleObjects2.length = 0;
gdjs.PlayScene3Code.GDDeathGreenEnemyParticleObjects3.length = 0;
gdjs.PlayScene3Code.GDDeathGreenEnemyParticleObjects4.length = 0;
gdjs.PlayScene3Code.GDDeathGreenEnemyParticleObjects5.length = 0;
gdjs.PlayScene3Code.GDDeathGreenEnemyParticleObjects6.length = 0;
gdjs.PlayScene3Code.GDEnemyBlueObjects1.length = 0;
gdjs.PlayScene3Code.GDEnemyBlueObjects2.length = 0;
gdjs.PlayScene3Code.GDEnemyBlueObjects3.length = 0;
gdjs.PlayScene3Code.GDEnemyBlueObjects4.length = 0;
gdjs.PlayScene3Code.GDEnemyBlueObjects5.length = 0;
gdjs.PlayScene3Code.GDEnemyBlueObjects6.length = 0;
gdjs.PlayScene3Code.GDDeathBlueEnemyParticleObjects1.length = 0;
gdjs.PlayScene3Code.GDDeathBlueEnemyParticleObjects2.length = 0;
gdjs.PlayScene3Code.GDDeathBlueEnemyParticleObjects3.length = 0;
gdjs.PlayScene3Code.GDDeathBlueEnemyParticleObjects4.length = 0;
gdjs.PlayScene3Code.GDDeathBlueEnemyParticleObjects5.length = 0;
gdjs.PlayScene3Code.GDDeathBlueEnemyParticleObjects6.length = 0;
gdjs.PlayScene3Code.GDTimeTextObjects1.length = 0;
gdjs.PlayScene3Code.GDTimeTextObjects2.length = 0;
gdjs.PlayScene3Code.GDTimeTextObjects3.length = 0;
gdjs.PlayScene3Code.GDTimeTextObjects4.length = 0;
gdjs.PlayScene3Code.GDTimeTextObjects5.length = 0;
gdjs.PlayScene3Code.GDTimeTextObjects6.length = 0;
gdjs.PlayScene3Code.GDTimeText2Objects1.length = 0;
gdjs.PlayScene3Code.GDTimeText2Objects2.length = 0;
gdjs.PlayScene3Code.GDTimeText2Objects3.length = 0;
gdjs.PlayScene3Code.GDTimeText2Objects4.length = 0;
gdjs.PlayScene3Code.GDTimeText2Objects5.length = 0;
gdjs.PlayScene3Code.GDTimeText2Objects6.length = 0;
gdjs.PlayScene3Code.GDTimeText3Objects1.length = 0;
gdjs.PlayScene3Code.GDTimeText3Objects2.length = 0;
gdjs.PlayScene3Code.GDTimeText3Objects3.length = 0;
gdjs.PlayScene3Code.GDTimeText3Objects4.length = 0;
gdjs.PlayScene3Code.GDTimeText3Objects5.length = 0;
gdjs.PlayScene3Code.GDTimeText3Objects6.length = 0;
gdjs.PlayScene3Code.GDTimeText4Objects1.length = 0;
gdjs.PlayScene3Code.GDTimeText4Objects2.length = 0;
gdjs.PlayScene3Code.GDTimeText4Objects3.length = 0;
gdjs.PlayScene3Code.GDTimeText4Objects4.length = 0;
gdjs.PlayScene3Code.GDTimeText4Objects5.length = 0;
gdjs.PlayScene3Code.GDTimeText4Objects6.length = 0;

gdjs.PlayScene3Code.eventsList37(runtimeScene);

return;

}

gdjs['PlayScene3Code'] = gdjs.PlayScene3Code;
