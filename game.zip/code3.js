gdjs.PlaySceneCode = {};
gdjs.PlaySceneCode.GDBigAsteroidObjects4_1final = [];

gdjs.PlaySceneCode.GDBulletObjects3_1final = [];

gdjs.PlaySceneCode.GDBulletObjects4_1final = [];

gdjs.PlaySceneCode.GDEnemyBulletObjects3_1final = [];

gdjs.PlaySceneCode.GDEnemyBulletObjects4_1final = [];

gdjs.PlaySceneCode.GDFireButtonObjects2_1final = [];

gdjs.PlaySceneCode.GDLeftButtonObjects3_1final = [];

gdjs.PlaySceneCode.GDMediumAsteroidObjects4_1final = [];

gdjs.PlaySceneCode.GDRightButtonObjects2_1final = [];

gdjs.PlaySceneCode.GDSmallAsteroidObjects3_1final = [];

gdjs.PlaySceneCode.GDTopButtonObjects2_1final = [];

gdjs.PlaySceneCode.GDTopButtonObjects3_1final = [];

gdjs.PlaySceneCode.forEachIndex3 = 0;

gdjs.PlaySceneCode.forEachIndex4 = 0;

gdjs.PlaySceneCode.forEachObjects3 = [];

gdjs.PlaySceneCode.forEachObjects4 = [];

gdjs.PlaySceneCode.forEachTemporary3 = null;

gdjs.PlaySceneCode.forEachTemporary4 = null;

gdjs.PlaySceneCode.forEachTotalCount3 = 0;

gdjs.PlaySceneCode.forEachTotalCount4 = 0;

gdjs.PlaySceneCode.GDPlayerObjects1= [];
gdjs.PlaySceneCode.GDPlayerObjects2= [];
gdjs.PlaySceneCode.GDPlayerObjects3= [];
gdjs.PlaySceneCode.GDPlayerObjects4= [];
gdjs.PlaySceneCode.GDPlayerObjects5= [];
gdjs.PlaySceneCode.GDPlayerObjects6= [];
gdjs.PlaySceneCode.GDBulletObjects1= [];
gdjs.PlaySceneCode.GDBulletObjects2= [];
gdjs.PlaySceneCode.GDBulletObjects3= [];
gdjs.PlaySceneCode.GDBulletObjects4= [];
gdjs.PlaySceneCode.GDBulletObjects5= [];
gdjs.PlaySceneCode.GDBulletObjects6= [];
gdjs.PlaySceneCode.GDBigAsteroidObjects1= [];
gdjs.PlaySceneCode.GDBigAsteroidObjects2= [];
gdjs.PlaySceneCode.GDBigAsteroidObjects3= [];
gdjs.PlaySceneCode.GDBigAsteroidObjects4= [];
gdjs.PlaySceneCode.GDBigAsteroidObjects5= [];
gdjs.PlaySceneCode.GDBigAsteroidObjects6= [];
gdjs.PlaySceneCode.GDMediumAsteroidObjects1= [];
gdjs.PlaySceneCode.GDMediumAsteroidObjects2= [];
gdjs.PlaySceneCode.GDMediumAsteroidObjects3= [];
gdjs.PlaySceneCode.GDMediumAsteroidObjects4= [];
gdjs.PlaySceneCode.GDMediumAsteroidObjects5= [];
gdjs.PlaySceneCode.GDMediumAsteroidObjects6= [];
gdjs.PlaySceneCode.GDSmallAsteroidObjects1= [];
gdjs.PlaySceneCode.GDSmallAsteroidObjects2= [];
gdjs.PlaySceneCode.GDSmallAsteroidObjects3= [];
gdjs.PlaySceneCode.GDSmallAsteroidObjects4= [];
gdjs.PlaySceneCode.GDSmallAsteroidObjects5= [];
gdjs.PlaySceneCode.GDSmallAsteroidObjects6= [];
gdjs.PlaySceneCode.GDLifeBarObjects1= [];
gdjs.PlaySceneCode.GDLifeBarObjects2= [];
gdjs.PlaySceneCode.GDLifeBarObjects3= [];
gdjs.PlaySceneCode.GDLifeBarObjects4= [];
gdjs.PlaySceneCode.GDLifeBarObjects5= [];
gdjs.PlaySceneCode.GDLifeBarObjects6= [];
gdjs.PlaySceneCode.GDGameOverObjects1= [];
gdjs.PlaySceneCode.GDGameOverObjects2= [];
gdjs.PlaySceneCode.GDGameOverObjects3= [];
gdjs.PlaySceneCode.GDGameOverObjects4= [];
gdjs.PlaySceneCode.GDGameOverObjects5= [];
gdjs.PlaySceneCode.GDGameOverObjects6= [];
gdjs.PlaySceneCode.GDDeathShipParticleObjects1= [];
gdjs.PlaySceneCode.GDDeathShipParticleObjects2= [];
gdjs.PlaySceneCode.GDDeathShipParticleObjects3= [];
gdjs.PlaySceneCode.GDDeathShipParticleObjects4= [];
gdjs.PlaySceneCode.GDDeathShipParticleObjects5= [];
gdjs.PlaySceneCode.GDDeathShipParticleObjects6= [];
gdjs.PlaySceneCode.GDDeathDebrisParticleObjects1= [];
gdjs.PlaySceneCode.GDDeathDebrisParticleObjects2= [];
gdjs.PlaySceneCode.GDDeathDebrisParticleObjects3= [];
gdjs.PlaySceneCode.GDDeathDebrisParticleObjects4= [];
gdjs.PlaySceneCode.GDDeathDebrisParticleObjects5= [];
gdjs.PlaySceneCode.GDDeathDebrisParticleObjects6= [];
gdjs.PlaySceneCode.GDDebrisHugeObjects1= [];
gdjs.PlaySceneCode.GDDebrisHugeObjects2= [];
gdjs.PlaySceneCode.GDDebrisHugeObjects3= [];
gdjs.PlaySceneCode.GDDebrisHugeObjects4= [];
gdjs.PlaySceneCode.GDDebrisHugeObjects5= [];
gdjs.PlaySceneCode.GDDebrisHugeObjects6= [];
gdjs.PlaySceneCode.GDDebrisMediumObjects1= [];
gdjs.PlaySceneCode.GDDebrisMediumObjects2= [];
gdjs.PlaySceneCode.GDDebrisMediumObjects3= [];
gdjs.PlaySceneCode.GDDebrisMediumObjects4= [];
gdjs.PlaySceneCode.GDDebrisMediumObjects5= [];
gdjs.PlaySceneCode.GDDebrisMediumObjects6= [];
gdjs.PlaySceneCode.GDDebrisSmallObjects1= [];
gdjs.PlaySceneCode.GDDebrisSmallObjects2= [];
gdjs.PlaySceneCode.GDDebrisSmallObjects3= [];
gdjs.PlaySceneCode.GDDebrisSmallObjects4= [];
gdjs.PlaySceneCode.GDDebrisSmallObjects5= [];
gdjs.PlaySceneCode.GDDebrisSmallObjects6= [];
gdjs.PlaySceneCode.GDBulletHitObjects1= [];
gdjs.PlaySceneCode.GDBulletHitObjects2= [];
gdjs.PlaySceneCode.GDBulletHitObjects3= [];
gdjs.PlaySceneCode.GDBulletHitObjects4= [];
gdjs.PlaySceneCode.GDBulletHitObjects5= [];
gdjs.PlaySceneCode.GDBulletHitObjects6= [];
gdjs.PlaySceneCode.GDBulletFlashObjects1= [];
gdjs.PlaySceneCode.GDBulletFlashObjects2= [];
gdjs.PlaySceneCode.GDBulletFlashObjects3= [];
gdjs.PlaySceneCode.GDBulletFlashObjects4= [];
gdjs.PlaySceneCode.GDBulletFlashObjects5= [];
gdjs.PlaySceneCode.GDBulletFlashObjects6= [];
gdjs.PlaySceneCode.GDStarBackgroundObjects1= [];
gdjs.PlaySceneCode.GDStarBackgroundObjects2= [];
gdjs.PlaySceneCode.GDStarBackgroundObjects3= [];
gdjs.PlaySceneCode.GDStarBackgroundObjects4= [];
gdjs.PlaySceneCode.GDStarBackgroundObjects5= [];
gdjs.PlaySceneCode.GDStarBackgroundObjects6= [];
gdjs.PlaySceneCode.GDMotionTrailObjects1= [];
gdjs.PlaySceneCode.GDMotionTrailObjects2= [];
gdjs.PlaySceneCode.GDMotionTrailObjects3= [];
gdjs.PlaySceneCode.GDMotionTrailObjects4= [];
gdjs.PlaySceneCode.GDMotionTrailObjects5= [];
gdjs.PlaySceneCode.GDMotionTrailObjects6= [];
gdjs.PlaySceneCode.GDTutorialTextObjects1= [];
gdjs.PlaySceneCode.GDTutorialTextObjects2= [];
gdjs.PlaySceneCode.GDTutorialTextObjects3= [];
gdjs.PlaySceneCode.GDTutorialTextObjects4= [];
gdjs.PlaySceneCode.GDTutorialTextObjects5= [];
gdjs.PlaySceneCode.GDTutorialTextObjects6= [];
gdjs.PlaySceneCode.GDContinueTextObjects1= [];
gdjs.PlaySceneCode.GDContinueTextObjects2= [];
gdjs.PlaySceneCode.GDContinueTextObjects3= [];
gdjs.PlaySceneCode.GDContinueTextObjects4= [];
gdjs.PlaySceneCode.GDContinueTextObjects5= [];
gdjs.PlaySceneCode.GDContinueTextObjects6= [];
gdjs.PlaySceneCode.GDRightButtonObjects1= [];
gdjs.PlaySceneCode.GDRightButtonObjects2= [];
gdjs.PlaySceneCode.GDRightButtonObjects3= [];
gdjs.PlaySceneCode.GDRightButtonObjects4= [];
gdjs.PlaySceneCode.GDRightButtonObjects5= [];
gdjs.PlaySceneCode.GDRightButtonObjects6= [];
gdjs.PlaySceneCode.GDLeftButtonObjects1= [];
gdjs.PlaySceneCode.GDLeftButtonObjects2= [];
gdjs.PlaySceneCode.GDLeftButtonObjects3= [];
gdjs.PlaySceneCode.GDLeftButtonObjects4= [];
gdjs.PlaySceneCode.GDLeftButtonObjects5= [];
gdjs.PlaySceneCode.GDLeftButtonObjects6= [];
gdjs.PlaySceneCode.GDTopButtonObjects1= [];
gdjs.PlaySceneCode.GDTopButtonObjects2= [];
gdjs.PlaySceneCode.GDTopButtonObjects3= [];
gdjs.PlaySceneCode.GDTopButtonObjects4= [];
gdjs.PlaySceneCode.GDTopButtonObjects5= [];
gdjs.PlaySceneCode.GDTopButtonObjects6= [];
gdjs.PlaySceneCode.GDFireButtonObjects1= [];
gdjs.PlaySceneCode.GDFireButtonObjects2= [];
gdjs.PlaySceneCode.GDFireButtonObjects3= [];
gdjs.PlaySceneCode.GDFireButtonObjects4= [];
gdjs.PlaySceneCode.GDFireButtonObjects5= [];
gdjs.PlaySceneCode.GDFireButtonObjects6= [];
gdjs.PlaySceneCode.GDEnemyBulletObjects1= [];
gdjs.PlaySceneCode.GDEnemyBulletObjects2= [];
gdjs.PlaySceneCode.GDEnemyBulletObjects3= [];
gdjs.PlaySceneCode.GDEnemyBulletObjects4= [];
gdjs.PlaySceneCode.GDEnemyBulletObjects5= [];
gdjs.PlaySceneCode.GDEnemyBulletObjects6= [];
gdjs.PlaySceneCode.GDEnemyObjects1= [];
gdjs.PlaySceneCode.GDEnemyObjects2= [];
gdjs.PlaySceneCode.GDEnemyObjects3= [];
gdjs.PlaySceneCode.GDEnemyObjects4= [];
gdjs.PlaySceneCode.GDEnemyObjects5= [];
gdjs.PlaySceneCode.GDEnemyObjects6= [];
gdjs.PlaySceneCode.GDTitleTextObjects1= [];
gdjs.PlaySceneCode.GDTitleTextObjects2= [];
gdjs.PlaySceneCode.GDTitleTextObjects3= [];
gdjs.PlaySceneCode.GDTitleTextObjects4= [];
gdjs.PlaySceneCode.GDTitleTextObjects5= [];
gdjs.PlaySceneCode.GDTitleTextObjects6= [];
gdjs.PlaySceneCode.GDHealthPowerObjects1= [];
gdjs.PlaySceneCode.GDHealthPowerObjects2= [];
gdjs.PlaySceneCode.GDHealthPowerObjects3= [];
gdjs.PlaySceneCode.GDHealthPowerObjects4= [];
gdjs.PlaySceneCode.GDHealthPowerObjects5= [];
gdjs.PlaySceneCode.GDHealthPowerObjects6= [];
gdjs.PlaySceneCode.GDNextLevelObjects1= [];
gdjs.PlaySceneCode.GDNextLevelObjects2= [];
gdjs.PlaySceneCode.GDNextLevelObjects3= [];
gdjs.PlaySceneCode.GDNextLevelObjects4= [];
gdjs.PlaySceneCode.GDNextLevelObjects5= [];
gdjs.PlaySceneCode.GDNextLevelObjects6= [];
gdjs.PlaySceneCode.GDDeathEnemyParticleObjects1= [];
gdjs.PlaySceneCode.GDDeathEnemyParticleObjects2= [];
gdjs.PlaySceneCode.GDDeathEnemyParticleObjects3= [];
gdjs.PlaySceneCode.GDDeathEnemyParticleObjects4= [];
gdjs.PlaySceneCode.GDDeathEnemyParticleObjects5= [];
gdjs.PlaySceneCode.GDDeathEnemyParticleObjects6= [];
gdjs.PlaySceneCode.GDMenuTextObjects1= [];
gdjs.PlaySceneCode.GDMenuTextObjects2= [];
gdjs.PlaySceneCode.GDMenuTextObjects3= [];
gdjs.PlaySceneCode.GDMenuTextObjects4= [];
gdjs.PlaySceneCode.GDMenuTextObjects5= [];
gdjs.PlaySceneCode.GDMenuTextObjects6= [];
gdjs.PlaySceneCode.GDContinueButtonObjects1= [];
gdjs.PlaySceneCode.GDContinueButtonObjects2= [];
gdjs.PlaySceneCode.GDContinueButtonObjects3= [];
gdjs.PlaySceneCode.GDContinueButtonObjects4= [];
gdjs.PlaySceneCode.GDContinueButtonObjects5= [];
gdjs.PlaySceneCode.GDContinueButtonObjects6= [];
gdjs.PlaySceneCode.GDFinishTextObjects1= [];
gdjs.PlaySceneCode.GDFinishTextObjects2= [];
gdjs.PlaySceneCode.GDFinishTextObjects3= [];
gdjs.PlaySceneCode.GDFinishTextObjects4= [];
gdjs.PlaySceneCode.GDFinishTextObjects5= [];
gdjs.PlaySceneCode.GDFinishTextObjects6= [];
gdjs.PlaySceneCode.GDTimeTextObjects1= [];
gdjs.PlaySceneCode.GDTimeTextObjects2= [];
gdjs.PlaySceneCode.GDTimeTextObjects3= [];
gdjs.PlaySceneCode.GDTimeTextObjects4= [];
gdjs.PlaySceneCode.GDTimeTextObjects5= [];
gdjs.PlaySceneCode.GDTimeTextObjects6= [];
gdjs.PlaySceneCode.GDTimeText2Objects1= [];
gdjs.PlaySceneCode.GDTimeText2Objects2= [];
gdjs.PlaySceneCode.GDTimeText2Objects3= [];
gdjs.PlaySceneCode.GDTimeText2Objects4= [];
gdjs.PlaySceneCode.GDTimeText2Objects5= [];
gdjs.PlaySceneCode.GDTimeText2Objects6= [];
gdjs.PlaySceneCode.GDTimeText3Objects1= [];
gdjs.PlaySceneCode.GDTimeText3Objects2= [];
gdjs.PlaySceneCode.GDTimeText3Objects3= [];
gdjs.PlaySceneCode.GDTimeText3Objects4= [];
gdjs.PlaySceneCode.GDTimeText3Objects5= [];
gdjs.PlaySceneCode.GDTimeText3Objects6= [];
gdjs.PlaySceneCode.GDTimeText4Objects1= [];
gdjs.PlaySceneCode.GDTimeText4Objects2= [];
gdjs.PlaySceneCode.GDTimeText4Objects3= [];
gdjs.PlaySceneCode.GDTimeText4Objects4= [];
gdjs.PlaySceneCode.GDTimeText4Objects5= [];
gdjs.PlaySceneCode.GDTimeText4Objects6= [];


gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDEnemyObjects1Objects = Hashtable.newFrom({"Enemy": gdjs.PlaySceneCode.GDEnemyObjects1});
gdjs.PlaySceneCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TutorialText"), gdjs.PlaySceneCode.GDTutorialTextObjects2);
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "MultiTouchControls", 0, 0, 0);
}{for(var i = 0, len = gdjs.PlaySceneCode.GDTutorialTextObjects2.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDTutorialTextObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("BigAsteroid"), gdjs.PlaySceneCode.GDBigAsteroidObjects1);
gdjs.copyArray(runtimeScene.getObjects("MediumAsteroid"), gdjs.PlaySceneCode.GDMediumAsteroidObjects1);
gdjs.copyArray(runtimeScene.getObjects("SmallAsteroid"), gdjs.PlaySceneCode.GDSmallAsteroidObjects1);
gdjs.PlaySceneCode.GDEnemyObjects1.length = 0;

{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Timer");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDEnemyObjects1Objects, 960, gdjs.randomInRange(40, 500), "");
}{for(var i = 0, len = gdjs.PlaySceneCode.GDBigAsteroidObjects1.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDBigAsteroidObjects1[i].getBehavior("Physics2").applyForce(gdjs.randomInRange(-(40), 40), gdjs.randomInRange(-(30), 30), (gdjs.PlaySceneCode.GDBigAsteroidObjects1[i].getCenterXInScene()), (gdjs.PlaySceneCode.GDBigAsteroidObjects1[i].getCenterYInScene()));
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDMediumAsteroidObjects1.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDMediumAsteroidObjects1[i].getBehavior("Physics2").applyForce(gdjs.randomInRange(-(20), 20), gdjs.randomInRange(-(15), 15), (gdjs.PlaySceneCode.GDMediumAsteroidObjects1[i].getCenterXInScene()), (gdjs.PlaySceneCode.GDMediumAsteroidObjects1[i].getCenterYInScene()));
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDSmallAsteroidObjects1.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDSmallAsteroidObjects1[i].getBehavior("Physics2").applyForce(gdjs.randomInRange(-(5), 5), gdjs.randomInRange(-(5), 5), (gdjs.PlaySceneCode.GDSmallAsteroidObjects1[i].getCenterXInScene()), (gdjs.PlaySceneCode.GDSmallAsteroidObjects1[i].getCenterYInScene()));
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDBigAsteroidObjects1.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDBigAsteroidObjects1[i].setAnimation(gdjs.random(3));
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDMediumAsteroidObjects1.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDMediumAsteroidObjects1[i].setAnimation(gdjs.random(1));
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDSmallAsteroidObjects1.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDSmallAsteroidObjects1[i].setAnimation(gdjs.random(1));
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDBigAsteroidObjects1.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDBigAsteroidObjects1[i].setAngle(gdjs.random(360));
}
for(var i = 0, len = gdjs.PlaySceneCode.GDMediumAsteroidObjects1.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDMediumAsteroidObjects1[i].setAngle(gdjs.random(360));
}
for(var i = 0, len = gdjs.PlaySceneCode.GDSmallAsteroidObjects1.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDSmallAsteroidObjects1[i].setAngle(gdjs.random(360));
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDBigAsteroidObjects1.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDBigAsteroidObjects1[i].setPosition(gdjs.PlaySceneCode.GDBigAsteroidObjects1[i].getX() +(gdjs.randomInRange(-(32), 32)),gdjs.PlaySceneCode.GDBigAsteroidObjects1[i].getY() +(gdjs.randomInRange(-(32), 32)));
}
for(var i = 0, len = gdjs.PlaySceneCode.GDMediumAsteroidObjects1.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDMediumAsteroidObjects1[i].setPosition(gdjs.PlaySceneCode.GDMediumAsteroidObjects1[i].getX() +(gdjs.randomInRange(-(32), 32)),gdjs.PlaySceneCode.GDMediumAsteroidObjects1[i].getY() +(gdjs.randomInRange(-(32), 32)));
}
for(var i = 0, len = gdjs.PlaySceneCode.GDSmallAsteroidObjects1.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDSmallAsteroidObjects1[i].setPosition(gdjs.PlaySceneCode.GDSmallAsteroidObjects1[i].getX() +(gdjs.randomInRange(-(32), 32)),gdjs.PlaySceneCode.GDSmallAsteroidObjects1[i].getY() +(gdjs.randomInRange(-(32), 32)));
}
}}

}


};gdjs.PlaySceneCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().get("State").setString("GamePlaying");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {

{ //Subevents
gdjs.PlaySceneCode.eventsList0(runtimeScene);} //End of subevents
}

}


};gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDMotionTrailObjects3Objects = Hashtable.newFrom({"MotionTrail": gdjs.PlaySceneCode.GDMotionTrailObjects3});
gdjs.PlaySceneCode.mapOfEmptyGDTopButtonObjects = Hashtable.newFrom({"TopButton": []});
gdjs.PlaySceneCode.eventsList2 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.PlaySceneCode.GDMotionTrailObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDMotionTrailObjects3Objects, 0, 0, "");
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("MotionTrail"), gdjs.PlaySceneCode.GDMotionTrailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PlaySceneCode.GDPlayerObjects3);
{for(var i = 0, len = gdjs.PlaySceneCode.GDMotionTrailObjects3.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDMotionTrailObjects3[i].setPosition((( gdjs.PlaySceneCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDPlayerObjects3[0].getPointX("MotionTrail")),(( gdjs.PlaySceneCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDPlayerObjects3[0].getPointY("MotionTrail")));
}
}}

}


{

gdjs.PlaySceneCode.GDTopButtonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.PlaySceneCode.GDTopButtonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("TopButton"), gdjs.PlaySceneCode.GDTopButtonObjects4);
for (var i = 0, k = 0, l = gdjs.PlaySceneCode.GDTopButtonObjects4.length;i<l;++i) {
    if ( gdjs.PlaySceneCode.GDTopButtonObjects4[i].getBehavior("MultitouchButton").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.PlaySceneCode.GDTopButtonObjects4[k] = gdjs.PlaySceneCode.GDTopButtonObjects4[i];
        ++k;
    }
}
gdjs.PlaySceneCode.GDTopButtonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PlaySceneCode.GDTopButtonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.PlaySceneCode.GDTopButtonObjects3_1final.indexOf(gdjs.PlaySceneCode.GDTopButtonObjects4[j]) === -1 )
            gdjs.PlaySceneCode.GDTopButtonObjects3_1final.push(gdjs.PlaySceneCode.GDTopButtonObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.PlaySceneCode.GDTopButtonObjects3_1final, gdjs.PlaySceneCode.GDTopButtonObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16147028);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("MotionTrail"), gdjs.PlaySceneCode.GDMotionTrailObjects3);
{for(var i = 0, len = gdjs.PlaySceneCode.GDMotionTrailObjects3.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDMotionTrailObjects3[i].startEmission();
}
}}

}


{

gdjs.PlaySceneCode.GDTopButtonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "w"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.PlaySceneCode.GDTopButtonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("TopButton"), gdjs.PlaySceneCode.GDTopButtonObjects3);
for (var i = 0, k = 0, l = gdjs.PlaySceneCode.GDTopButtonObjects3.length;i<l;++i) {
    if ( !(gdjs.PlaySceneCode.GDTopButtonObjects3[i].getBehavior("MultitouchButton").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_1 = true;
        gdjs.PlaySceneCode.GDTopButtonObjects3[k] = gdjs.PlaySceneCode.GDTopButtonObjects3[i];
        ++k;
    }
}
gdjs.PlaySceneCode.GDTopButtonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PlaySceneCode.GDTopButtonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.PlaySceneCode.GDTopButtonObjects2_1final.indexOf(gdjs.PlaySceneCode.GDTopButtonObjects3[j]) === -1 )
            gdjs.PlaySceneCode.GDTopButtonObjects2_1final.push(gdjs.PlaySceneCode.GDTopButtonObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlaySceneCode.mapOfEmptyGDTopButtonObjects) == 0;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.PlaySceneCode.GDTopButtonObjects2_1final, gdjs.PlaySceneCode.GDTopButtonObjects2);
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("MotionTrail"), gdjs.PlaySceneCode.GDMotionTrailObjects2);
{for(var i = 0, len = gdjs.PlaySceneCode.GDMotionTrailObjects2.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDMotionTrailObjects2[i].stopEmission();
}
}}

}


};gdjs.PlaySceneCode.eventsList3 = function(runtimeScene) {

{

gdjs.PlaySceneCode.GDTopButtonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.PlaySceneCode.GDTopButtonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("TopButton"), gdjs.PlaySceneCode.GDTopButtonObjects4);
for (var i = 0, k = 0, l = gdjs.PlaySceneCode.GDTopButtonObjects4.length;i<l;++i) {
    if ( gdjs.PlaySceneCode.GDTopButtonObjects4[i].getBehavior("MultitouchButton").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.PlaySceneCode.GDTopButtonObjects4[k] = gdjs.PlaySceneCode.GDTopButtonObjects4[i];
        ++k;
    }
}
gdjs.PlaySceneCode.GDTopButtonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PlaySceneCode.GDTopButtonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.PlaySceneCode.GDTopButtonObjects3_1final.indexOf(gdjs.PlaySceneCode.GDTopButtonObjects4[j]) === -1 )
            gdjs.PlaySceneCode.GDTopButtonObjects3_1final.push(gdjs.PlaySceneCode.GDTopButtonObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.PlaySceneCode.GDTopButtonObjects3_1final, gdjs.PlaySceneCode.GDTopButtonObjects3);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PlaySceneCode.GDPlayerObjects3);
{for(var i = 0, len = gdjs.PlaySceneCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDPlayerObjects3[i].getBehavior("Physics2").applyPolarForce((gdjs.PlaySceneCode.GDPlayerObjects3[i].getAngle()), 4.5, (gdjs.PlaySceneCode.GDPlayerObjects3[i].getPointX("")), (gdjs.PlaySceneCode.GDPlayerObjects3[i].getPointY("")));
}
}}

}


{

gdjs.PlaySceneCode.GDLeftButtonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.PlaySceneCode.GDLeftButtonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("LeftButton"), gdjs.PlaySceneCode.GDLeftButtonObjects4);
for (var i = 0, k = 0, l = gdjs.PlaySceneCode.GDLeftButtonObjects4.length;i<l;++i) {
    if ( gdjs.PlaySceneCode.GDLeftButtonObjects4[i].getBehavior("MultitouchButton").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.PlaySceneCode.GDLeftButtonObjects4[k] = gdjs.PlaySceneCode.GDLeftButtonObjects4[i];
        ++k;
    }
}
gdjs.PlaySceneCode.GDLeftButtonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PlaySceneCode.GDLeftButtonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.PlaySceneCode.GDLeftButtonObjects3_1final.indexOf(gdjs.PlaySceneCode.GDLeftButtonObjects4[j]) === -1 )
            gdjs.PlaySceneCode.GDLeftButtonObjects3_1final.push(gdjs.PlaySceneCode.GDLeftButtonObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.PlaySceneCode.GDLeftButtonObjects3_1final, gdjs.PlaySceneCode.GDLeftButtonObjects3);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PlaySceneCode.GDPlayerObjects3);
{for(var i = 0, len = gdjs.PlaySceneCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDPlayerObjects3[i].getBehavior("Physics2").applyTorque(-(0.5));
}
}}

}


{

gdjs.PlaySceneCode.GDRightButtonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.PlaySceneCode.GDRightButtonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("RightButton"), gdjs.PlaySceneCode.GDRightButtonObjects3);
for (var i = 0, k = 0, l = gdjs.PlaySceneCode.GDRightButtonObjects3.length;i<l;++i) {
    if ( gdjs.PlaySceneCode.GDRightButtonObjects3[i].getBehavior("MultitouchButton").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.PlaySceneCode.GDRightButtonObjects3[k] = gdjs.PlaySceneCode.GDRightButtonObjects3[i];
        ++k;
    }
}
gdjs.PlaySceneCode.GDRightButtonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PlaySceneCode.GDRightButtonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.PlaySceneCode.GDRightButtonObjects2_1final.indexOf(gdjs.PlaySceneCode.GDRightButtonObjects3[j]) === -1 )
            gdjs.PlaySceneCode.GDRightButtonObjects2_1final.push(gdjs.PlaySceneCode.GDRightButtonObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.PlaySceneCode.GDRightButtonObjects2_1final, gdjs.PlaySceneCode.GDRightButtonObjects2);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PlaySceneCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.PlaySceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDPlayerObjects2[i].getBehavior("Physics2").applyTorque(0.5);
}
}}

}


};gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBulletObjects2Objects = Hashtable.newFrom({"Bullet": gdjs.PlaySceneCode.GDBulletObjects2});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBulletFlashObjects2Objects = Hashtable.newFrom({"BulletFlash": gdjs.PlaySceneCode.GDBulletFlashObjects2});
gdjs.PlaySceneCode.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PlaySceneCode.GDPlayerObjects2);
gdjs.PlaySceneCode.GDFireButtonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PlaySceneCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.PlaySceneCode.GDPlayerObjects2[i].getBehavior("FireBullet").IsReadyToShoot((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.PlaySceneCode.GDPlayerObjects2[k] = gdjs.PlaySceneCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.PlaySceneCode.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.PlaySceneCode.GDFireButtonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("FireButton"), gdjs.PlaySceneCode.GDFireButtonObjects3);
for (var i = 0, k = 0, l = gdjs.PlaySceneCode.GDFireButtonObjects3.length;i<l;++i) {
    if ( gdjs.PlaySceneCode.GDFireButtonObjects3[i].getBehavior("MultitouchButton").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.PlaySceneCode.GDFireButtonObjects3[k] = gdjs.PlaySceneCode.GDFireButtonObjects3[i];
        ++k;
    }
}
gdjs.PlaySceneCode.GDFireButtonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PlaySceneCode.GDFireButtonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.PlaySceneCode.GDFireButtonObjects2_1final.indexOf(gdjs.PlaySceneCode.GDFireButtonObjects3[j]) === -1 )
            gdjs.PlaySceneCode.GDFireButtonObjects2_1final.push(gdjs.PlaySceneCode.GDFireButtonObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.PlaySceneCode.GDFireButtonObjects2_1final, gdjs.PlaySceneCode.GDFireButtonObjects2);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.PlaySceneCode.GDBulletObjects2);
/* Reuse gdjs.PlaySceneCode.GDPlayerObjects2 */
gdjs.PlaySceneCode.GDBulletFlashObjects2.length = 0;

{for(var i = 0, len = gdjs.PlaySceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDPlayerObjects2[i].getBehavior("FireBullet").Fire((gdjs.PlaySceneCode.GDPlayerObjects2[i].getPointX("BulletSpawn")), (gdjs.PlaySceneCode.GDPlayerObjects2[i].getPointY("BulletSpawn")), gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBulletObjects2Objects, (gdjs.PlaySceneCode.GDPlayerObjects2[i].getAngle()), 240, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDBulletObjects2.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDBulletObjects2[i].setZOrder((( gdjs.PlaySceneCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDPlayerObjects2[0].getZOrder()) - 2);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "LaserFire.wav", false, 40, gdjs.randomFloatInRange(0.9, 1.1));
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBulletFlashObjects2Objects, (( gdjs.PlaySceneCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDPlayerObjects2[0].getPointX("BulletFlash")), (( gdjs.PlaySceneCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDPlayerObjects2[0].getPointY("BulletFlash")), "");
}{for(var i = 0, len = gdjs.PlaySceneCode.GDBulletFlashObjects2.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDBulletFlashObjects2[i].setAngle((( gdjs.PlaySceneCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDPlayerObjects2[0].getAngle()) + 90);
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDBulletFlashObjects2.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDBulletFlashObjects2[i].setZOrder((( gdjs.PlaySceneCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDPlayerObjects2[0].getZOrder()) - 1);
}
}}

}


};gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDEnemyBulletObjects3Objects = Hashtable.newFrom({"EnemyBullet": gdjs.PlaySceneCode.GDEnemyBulletObjects3});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBulletFlashObjects3Objects = Hashtable.newFrom({"BulletFlash": gdjs.PlaySceneCode.GDBulletFlashObjects3});
gdjs.PlaySceneCode.eventsList5 = function(runtimeScene) {

{

/* Reuse gdjs.PlaySceneCode.GDEnemyObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PlaySceneCode.GDEnemyObjects3.length;i<l;++i) {
    if ( gdjs.PlaySceneCode.GDEnemyObjects3[i].getBehavior("FireBullet").HasJustFired((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.PlaySceneCode.GDEnemyObjects3[k] = gdjs.PlaySceneCode.GDEnemyObjects3[i];
        ++k;
    }
}
gdjs.PlaySceneCode.GDEnemyObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.PlaySceneCode.GDEnemyObjects3 */
/* Reuse gdjs.PlaySceneCode.GDEnemyBulletObjects3 */
gdjs.PlaySceneCode.GDBulletFlashObjects3.length = 0;

{for(var i = 0, len = gdjs.PlaySceneCode.GDEnemyBulletObjects3.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDEnemyBulletObjects3[i].setZOrder((( gdjs.PlaySceneCode.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDEnemyObjects3[0].getZOrder()) - 2);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Laser effect (2).aac", false, 40, gdjs.randomFloatInRange(0.9, 1.1));
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBulletFlashObjects3Objects, (( gdjs.PlaySceneCode.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDEnemyObjects3[0].getPointX("BulletFlash")), (( gdjs.PlaySceneCode.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDEnemyObjects3[0].getPointY("BulletFlash")), "");
}{for(var i = 0, len = gdjs.PlaySceneCode.GDBulletFlashObjects3.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDBulletFlashObjects3[i].setAngle((( gdjs.PlaySceneCode.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDEnemyObjects3[0].getAngle()) + 90);
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDBulletFlashObjects3.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDBulletFlashObjects3[i].setZOrder((( gdjs.PlaySceneCode.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDEnemyObjects3[0].getZOrder()) - 1);
}
}}

}


};gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.PlaySceneCode.GDBulletObjects3});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDEnemyObjects3Objects = Hashtable.newFrom({"Enemy": gdjs.PlaySceneCode.GDEnemyObjects3});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDDeathDebrisParticleObjects3Objects = Hashtable.newFrom({"DeathDebrisParticle": gdjs.PlaySceneCode.GDDeathDebrisParticleObjects3});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDDeathEnemyParticleObjects3Objects = Hashtable.newFrom({"DeathEnemyParticle": gdjs.PlaySceneCode.GDDeathEnemyParticleObjects3});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDHealthPowerObjects3Objects = Hashtable.newFrom({"HealthPower": gdjs.PlaySceneCode.GDHealthPowerObjects3});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBulletHitObjects3Objects = Hashtable.newFrom({"BulletHit": gdjs.PlaySceneCode.GDBulletHitObjects3});
gdjs.PlaySceneCode.mapOfEmptyGDEnemyObjects = Hashtable.newFrom({"Enemy": []});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDEnemyObjects3Objects = Hashtable.newFrom({"Enemy": gdjs.PlaySceneCode.GDEnemyObjects3});
gdjs.PlaySceneCode.eventsList6 = function(runtimeScene) {

};gdjs.PlaySceneCode.eventsList7 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.PlaySceneCode.GDEnemyObjects3);
gdjs.copyArray(runtimeScene.getObjects("EnemyBullet"), gdjs.PlaySceneCode.GDEnemyBulletObjects3);
{for(var i = 0, len = gdjs.PlaySceneCode.GDEnemyObjects3.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDEnemyObjects3[i].getBehavior("FireBullet").Fire((gdjs.PlaySceneCode.GDEnemyObjects3[i].getPointX("BulletSpawn")), (gdjs.PlaySceneCode.GDEnemyObjects3[i].getPointY("BulletSpawn")), gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDEnemyBulletObjects3Objects, (gdjs.PlaySceneCode.GDEnemyObjects3[i].getAngle()), 120, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.PlaySceneCode.eventsList5(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.PlaySceneCode.GDEnemyObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PlaySceneCode.GDPlayerObjects3);
{for(var i = 0, len = gdjs.PlaySceneCode.GDEnemyObjects3.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDEnemyObjects3[i].getBehavior("Physics2").applyForce(-(3), 0, (gdjs.PlaySceneCode.GDEnemyObjects3[i].getPointX("Origin")), (gdjs.PlaySceneCode.GDEnemyObjects3[i].getPointY("Origin")));
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDEnemyObjects3.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDEnemyObjects3[i].rotateTowardPosition((( gdjs.PlaySceneCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDPlayerObjects3[0].getPointX("Origin")), (( gdjs.PlaySceneCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDPlayerObjects3[0].getPointY("Origin")), 0, runtimeScene);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.PlaySceneCode.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.PlaySceneCode.GDEnemyObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBulletObjects3Objects, gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDEnemyObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.PlaySceneCode.GDBulletObjects3 */
gdjs.copyArray(runtimeScene.getObjects("DeathEnemyParticle"), gdjs.PlaySceneCode.GDDeathEnemyParticleObjects3);
/* Reuse gdjs.PlaySceneCode.GDEnemyObjects3 */
gdjs.PlaySceneCode.GDBulletHitObjects3.length = 0;

gdjs.PlaySceneCode.GDDeathDebrisParticleObjects3.length = 0;

gdjs.PlaySceneCode.GDHealthPowerObjects3.length = 0;

{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "EnemyTimer");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "PillTimer");
}{for(var i = 0, len = gdjs.PlaySceneCode.GDEnemyObjects3.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDEnemyObjects3[i].getBehavior("Health").Hit(1, false, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Explosion.wav", false, 60, gdjs.randomFloatInRange(0.9, 1));
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDDeathDebrisParticleObjects3Objects, (( gdjs.PlaySceneCode.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDEnemyObjects3[0].getPointX("")), (( gdjs.PlaySceneCode.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDEnemyObjects3[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.PlaySceneCode.GDDeathEnemyParticleObjects3.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDDeathEnemyParticleObjects3[i].setAngle((( gdjs.PlaySceneCode.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDEnemyObjects3[0].getAngle()));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDDeathEnemyParticleObjects3Objects, (( gdjs.PlaySceneCode.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDEnemyObjects3[0].getPointX("")), (( gdjs.PlaySceneCode.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDEnemyObjects3[0].getPointY("")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDHealthPowerObjects3Objects, (( gdjs.PlaySceneCode.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDEnemyObjects3[0].getPointX("")), (( gdjs.PlaySceneCode.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDEnemyObjects3[0].getPointY("")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBulletHitObjects3Objects, (( gdjs.PlaySceneCode.GDBulletObjects3.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDBulletObjects3[0].getPointX("BulletHit")), (( gdjs.PlaySceneCode.GDBulletObjects3.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDBulletObjects3[0].getPointY("BulletHit")), "");
}{for(var i = 0, len = gdjs.PlaySceneCode.GDEnemyObjects3.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDEnemyObjects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDBulletObjects3.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDBulletObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{


let stopDoWhile_0 = false;
do {
gdjs.PlaySceneCode.GDEnemyObjects3.length = 0;

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "EnemyTimer") >= 5;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlaySceneCode.mapOfEmptyGDEnemyObjects) == 0;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
let isConditionTrue_0 = false;
if (true) {
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDEnemyObjects3Objects, 960, gdjs.randomInRange(40, 500), "");
}
{ //Subevents: 
gdjs.PlaySceneCode.eventsList6(runtimeScene);} //Subevents end.
}
} else stopDoWhile_0 = true; 
} while (!stopDoWhile_0);

}


};gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.PlaySceneCode.GDPlayerObjects3});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDHealthPowerObjects3Objects = Hashtable.newFrom({"HealthPower": gdjs.PlaySceneCode.GDHealthPowerObjects3});
gdjs.PlaySceneCode.mapOfEmptyGDHealthPowerObjects = Hashtable.newFrom({"HealthPower": []});
gdjs.PlaySceneCode.eventsList8 = function(runtimeScene) {

{

/* Reuse gdjs.PlaySceneCode.GDHealthPowerObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.PlaySceneCode.GDHealthPowerObjects2.length;i<l;++i) {
    if ( gdjs.PlaySceneCode.GDHealthPowerObjects2[i].getBehavior("Flash").IsFlashing((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.PlaySceneCode.GDHealthPowerObjects2[k] = gdjs.PlaySceneCode.GDHealthPowerObjects2[i];
        ++k;
    }
}
gdjs.PlaySceneCode.GDHealthPowerObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "PillTimer") >= 8;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.PlaySceneCode.GDHealthPowerObjects2 */
{for(var i = 0, len = gdjs.PlaySceneCode.GDHealthPowerObjects2.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDHealthPowerObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.PlaySceneCode.eventsList9 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("HealthPower"), gdjs.PlaySceneCode.GDHealthPowerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PlaySceneCode.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDPlayerObjects3Objects, gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDHealthPowerObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.PlaySceneCode.GDHealthPowerObjects3 */
gdjs.copyArray(runtimeScene.getObjects("LifeBar"), gdjs.PlaySceneCode.GDLifeBarObjects3);
/* Reuse gdjs.PlaySceneCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.PlaySceneCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDPlayerObjects3[i].getBehavior("Health").Heal(1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDLifeBarObjects3.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDLifeBarObjects3[i].SetValue((( gdjs.PlaySceneCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDPlayerObjects3[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDHealthPowerObjects3.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDHealthPowerObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlaySceneCode.mapOfEmptyGDHealthPowerObjects) > 0;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "PillTimer") >= 5;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("HealthPower"), gdjs.PlaySceneCode.GDHealthPowerObjects2);
{for(var i = 0, len = gdjs.PlaySceneCode.GDHealthPowerObjects2.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDHealthPowerObjects2[i].getBehavior("Flash").Flash(3, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.PlaySceneCode.eventsList8(runtimeScene);} //End of subevents
}

}


};gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBulletObjects5Objects = Hashtable.newFrom({"Bullet": gdjs.PlaySceneCode.GDBulletObjects5});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBigAsteroidObjects5Objects = Hashtable.newFrom({"BigAsteroid": gdjs.PlaySceneCode.GDBigAsteroidObjects5});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDEnemyBulletObjects5Objects = Hashtable.newFrom({"EnemyBullet": gdjs.PlaySceneCode.GDEnemyBulletObjects5});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBigAsteroidObjects5Objects = Hashtable.newFrom({"BigAsteroid": gdjs.PlaySceneCode.GDBigAsteroidObjects5});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDDebrisHugeObjects4Objects = Hashtable.newFrom({"DebrisHuge": gdjs.PlaySceneCode.GDDebrisHugeObjects4});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBulletHitObjects4Objects = Hashtable.newFrom({"BulletHit": gdjs.PlaySceneCode.GDBulletHitObjects4});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDMediumAsteroidObjects5Objects = Hashtable.newFrom({"MediumAsteroid": gdjs.PlaySceneCode.GDMediumAsteroidObjects5});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDMediumAsteroidObjects5Objects = Hashtable.newFrom({"MediumAsteroid": gdjs.PlaySceneCode.GDMediumAsteroidObjects5});
gdjs.PlaySceneCode.eventsList10 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.PlaySceneCode.GDBigAsteroidObjects4, gdjs.PlaySceneCode.GDBigAsteroidObjects5);

gdjs.copyArray(gdjs.PlaySceneCode.GDBulletObjects4, gdjs.PlaySceneCode.GDBulletObjects5);

gdjs.PlaySceneCode.GDMediumAsteroidObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDMediumAsteroidObjects5Objects, (( gdjs.PlaySceneCode.GDBigAsteroidObjects5.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDBigAsteroidObjects5[0].getPointX("")), (( gdjs.PlaySceneCode.GDBigAsteroidObjects5.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDBigAsteroidObjects5[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.PlaySceneCode.GDMediumAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDMediumAsteroidObjects5[i].setAngle(gdjs.random(360));
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDMediumAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDMediumAsteroidObjects5[i].putAroundObject((gdjs.PlaySceneCode.GDBigAsteroidObjects5.length !== 0 ? gdjs.PlaySceneCode.GDBigAsteroidObjects5[0] : null), 15, (( gdjs.PlaySceneCode.GDBulletObjects5.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDBulletObjects5[0].getAngle()) - 90);
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDMediumAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDMediumAsteroidObjects5[i].getBehavior("Physics2").applyTorque(gdjs.randomFloatInRange(-(0.1), 0.1));
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDMediumAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDMediumAsteroidObjects5[i].getBehavior("Physics2").applyPolarForce((( gdjs.PlaySceneCode.GDBulletObjects5.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDBulletObjects5[0].getAngle()) + gdjs.randomFloatInRange(-(60), 0), 5, (gdjs.PlaySceneCode.GDMediumAsteroidObjects5[i].getBehavior("Physics2").getMassCenterX()), (gdjs.PlaySceneCode.GDMediumAsteroidObjects5[i].getBehavior("Physics2").getMassCenterY()));
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.PlaySceneCode.GDBigAsteroidObjects4, gdjs.PlaySceneCode.GDBigAsteroidObjects5);

gdjs.copyArray(gdjs.PlaySceneCode.GDBulletObjects4, gdjs.PlaySceneCode.GDBulletObjects5);

gdjs.PlaySceneCode.GDMediumAsteroidObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDMediumAsteroidObjects5Objects, (( gdjs.PlaySceneCode.GDBigAsteroidObjects5.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDBigAsteroidObjects5[0].getPointX("")), (( gdjs.PlaySceneCode.GDBigAsteroidObjects5.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDBigAsteroidObjects5[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.PlaySceneCode.GDMediumAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDMediumAsteroidObjects5[i].setAngle(gdjs.random(360));
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDMediumAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDMediumAsteroidObjects5[i].putAroundObject((gdjs.PlaySceneCode.GDBigAsteroidObjects5.length !== 0 ? gdjs.PlaySceneCode.GDBigAsteroidObjects5[0] : null), 15, (( gdjs.PlaySceneCode.GDBulletObjects5.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDBulletObjects5[0].getAngle()) + 90);
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDMediumAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDMediumAsteroidObjects5[i].getBehavior("Physics2").applyTorque(gdjs.randomFloatInRange(-(0.1), 0.1));
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDMediumAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDMediumAsteroidObjects5[i].getBehavior("Physics2").applyPolarForce((( gdjs.PlaySceneCode.GDBulletObjects5.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDBulletObjects5[0].getAngle()) + gdjs.randomFloatInRange(0, 60), 5, (gdjs.PlaySceneCode.GDMediumAsteroidObjects5[i].getBehavior("Physics2").getMassCenterX()), (gdjs.PlaySceneCode.GDMediumAsteroidObjects5[i].getBehavior("Physics2").getMassCenterY()));
}
}}

}


};gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBulletObjects5Objects = Hashtable.newFrom({"Bullet": gdjs.PlaySceneCode.GDBulletObjects5});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDMediumAsteroidObjects5Objects = Hashtable.newFrom({"MediumAsteroid": gdjs.PlaySceneCode.GDMediumAsteroidObjects5});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDEnemyBulletObjects5Objects = Hashtable.newFrom({"EnemyBullet": gdjs.PlaySceneCode.GDEnemyBulletObjects5});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDMediumAsteroidObjects5Objects = Hashtable.newFrom({"MediumAsteroid": gdjs.PlaySceneCode.GDMediumAsteroidObjects5});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDDebrisMediumObjects4Objects = Hashtable.newFrom({"DebrisMedium": gdjs.PlaySceneCode.GDDebrisMediumObjects4});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBulletHitObjects4Objects = Hashtable.newFrom({"BulletHit": gdjs.PlaySceneCode.GDBulletHitObjects4});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDSmallAsteroidObjects5Objects = Hashtable.newFrom({"SmallAsteroid": gdjs.PlaySceneCode.GDSmallAsteroidObjects5});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDSmallAsteroidObjects5Objects = Hashtable.newFrom({"SmallAsteroid": gdjs.PlaySceneCode.GDSmallAsteroidObjects5});
gdjs.PlaySceneCode.eventsList11 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("BigAsteroid"), gdjs.PlaySceneCode.GDBigAsteroidObjects5);
gdjs.copyArray(gdjs.PlaySceneCode.GDBulletObjects4, gdjs.PlaySceneCode.GDBulletObjects5);

gdjs.copyArray(gdjs.PlaySceneCode.GDMediumAsteroidObjects4, gdjs.PlaySceneCode.GDMediumAsteroidObjects5);

gdjs.PlaySceneCode.GDSmallAsteroidObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDSmallAsteroidObjects5Objects, (( gdjs.PlaySceneCode.GDBigAsteroidObjects5.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDBigAsteroidObjects5[0].getPointX("")), (( gdjs.PlaySceneCode.GDBigAsteroidObjects5.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDBigAsteroidObjects5[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.PlaySceneCode.GDSmallAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDSmallAsteroidObjects5[i].setAngle(gdjs.random(360));
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDSmallAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDSmallAsteroidObjects5[i].putAroundObject((gdjs.PlaySceneCode.GDMediumAsteroidObjects5.length !== 0 ? gdjs.PlaySceneCode.GDMediumAsteroidObjects5[0] : null), 8, (( gdjs.PlaySceneCode.GDBulletObjects5.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDBulletObjects5[0].getAngle()) - 90);
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDSmallAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDSmallAsteroidObjects5[i].getBehavior("Physics2").applyTorque(gdjs.randomFloatInRange(-(0.1), 0.1));
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDSmallAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDSmallAsteroidObjects5[i].getBehavior("Physics2").applyPolarForce((( gdjs.PlaySceneCode.GDBulletObjects5.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDBulletObjects5[0].getAngle()) + gdjs.randomFloatInRange(-(60), 0), 2, (gdjs.PlaySceneCode.GDSmallAsteroidObjects5[i].getBehavior("Physics2").getMassCenterX()), (gdjs.PlaySceneCode.GDSmallAsteroidObjects5[i].getBehavior("Physics2").getMassCenterY()));
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.PlaySceneCode.GDBulletObjects4, gdjs.PlaySceneCode.GDBulletObjects5);

gdjs.copyArray(gdjs.PlaySceneCode.GDMediumAsteroidObjects4, gdjs.PlaySceneCode.GDMediumAsteroidObjects5);

gdjs.PlaySceneCode.GDSmallAsteroidObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDSmallAsteroidObjects5Objects, (( gdjs.PlaySceneCode.GDMediumAsteroidObjects5.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDMediumAsteroidObjects5[0].getPointX("")), (( gdjs.PlaySceneCode.GDMediumAsteroidObjects5.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDMediumAsteroidObjects5[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.PlaySceneCode.GDSmallAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDSmallAsteroidObjects5[i].setAngle(gdjs.random(360));
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDSmallAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDSmallAsteroidObjects5[i].putAroundObject((gdjs.PlaySceneCode.GDMediumAsteroidObjects5.length !== 0 ? gdjs.PlaySceneCode.GDMediumAsteroidObjects5[0] : null), 8, (( gdjs.PlaySceneCode.GDBulletObjects5.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDBulletObjects5[0].getAngle()) + 90);
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDSmallAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDSmallAsteroidObjects5[i].getBehavior("Physics2").applyTorque(gdjs.randomFloatInRange(-(0.1), 0.1));
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDSmallAsteroidObjects5.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDSmallAsteroidObjects5[i].getBehavior("Physics2").applyPolarForce((( gdjs.PlaySceneCode.GDBulletObjects5.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDBulletObjects5[0].getAngle()) + gdjs.randomFloatInRange(0, 60), 2, (gdjs.PlaySceneCode.GDSmallAsteroidObjects5[i].getBehavior("Physics2").getMassCenterX()), (gdjs.PlaySceneCode.GDSmallAsteroidObjects5[i].getBehavior("Physics2").getMassCenterY()));
}
}}

}


};gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBulletObjects4Objects = Hashtable.newFrom({"Bullet": gdjs.PlaySceneCode.GDBulletObjects4});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDSmallAsteroidObjects4Objects = Hashtable.newFrom({"SmallAsteroid": gdjs.PlaySceneCode.GDSmallAsteroidObjects4});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDEnemyBulletObjects4Objects = Hashtable.newFrom({"EnemyBullet": gdjs.PlaySceneCode.GDEnemyBulletObjects4});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDSmallAsteroidObjects4Objects = Hashtable.newFrom({"SmallAsteroid": gdjs.PlaySceneCode.GDSmallAsteroidObjects4});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDDebrisSmallObjects3Objects = Hashtable.newFrom({"DebrisSmall": gdjs.PlaySceneCode.GDDebrisSmallObjects3});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBulletHitObjects3Objects = Hashtable.newFrom({"BulletHit": gdjs.PlaySceneCode.GDBulletHitObjects3});
gdjs.PlaySceneCode.eventsList12 = function(runtimeScene) {

};gdjs.PlaySceneCode.eventsList13 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("BigAsteroid"), gdjs.PlaySceneCode.GDBigAsteroidObjects3);

for (gdjs.PlaySceneCode.forEachIndex4 = 0;gdjs.PlaySceneCode.forEachIndex4 < gdjs.PlaySceneCode.GDBigAsteroidObjects3.length;++gdjs.PlaySceneCode.forEachIndex4) {
gdjs.PlaySceneCode.GDBulletObjects4.length = 0;

gdjs.PlaySceneCode.GDBulletHitObjects4.length = 0;

gdjs.PlaySceneCode.GDDebrisHugeObjects4.length = 0;

gdjs.PlaySceneCode.GDEnemyBulletObjects4.length = 0;

gdjs.PlaySceneCode.GDBigAsteroidObjects4.length = 0;


gdjs.PlaySceneCode.forEachTemporary4 = gdjs.PlaySceneCode.GDBigAsteroidObjects3[gdjs.PlaySceneCode.forEachIndex4];
gdjs.PlaySceneCode.GDBigAsteroidObjects4.push(gdjs.PlaySceneCode.forEachTemporary4);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.PlaySceneCode.GDBigAsteroidObjects4_1final.length = 0;
gdjs.PlaySceneCode.GDBulletObjects4_1final.length = 0;
gdjs.PlaySceneCode.GDEnemyBulletObjects4_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.PlaySceneCode.GDBigAsteroidObjects4, gdjs.PlaySceneCode.GDBigAsteroidObjects5);

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.PlaySceneCode.GDBulletObjects5);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBulletObjects5Objects, gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBigAsteroidObjects5Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PlaySceneCode.GDBigAsteroidObjects5.length; j < jLen ; ++j) {
        if ( gdjs.PlaySceneCode.GDBigAsteroidObjects4_1final.indexOf(gdjs.PlaySceneCode.GDBigAsteroidObjects5[j]) === -1 )
            gdjs.PlaySceneCode.GDBigAsteroidObjects4_1final.push(gdjs.PlaySceneCode.GDBigAsteroidObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.PlaySceneCode.GDBulletObjects5.length; j < jLen ; ++j) {
        if ( gdjs.PlaySceneCode.GDBulletObjects4_1final.indexOf(gdjs.PlaySceneCode.GDBulletObjects5[j]) === -1 )
            gdjs.PlaySceneCode.GDBulletObjects4_1final.push(gdjs.PlaySceneCode.GDBulletObjects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.PlaySceneCode.GDBigAsteroidObjects4, gdjs.PlaySceneCode.GDBigAsteroidObjects5);

gdjs.copyArray(runtimeScene.getObjects("EnemyBullet"), gdjs.PlaySceneCode.GDEnemyBulletObjects5);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDEnemyBulletObjects5Objects, gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBigAsteroidObjects5Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PlaySceneCode.GDBigAsteroidObjects5.length; j < jLen ; ++j) {
        if ( gdjs.PlaySceneCode.GDBigAsteroidObjects4_1final.indexOf(gdjs.PlaySceneCode.GDBigAsteroidObjects5[j]) === -1 )
            gdjs.PlaySceneCode.GDBigAsteroidObjects4_1final.push(gdjs.PlaySceneCode.GDBigAsteroidObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.PlaySceneCode.GDEnemyBulletObjects5.length; j < jLen ; ++j) {
        if ( gdjs.PlaySceneCode.GDEnemyBulletObjects4_1final.indexOf(gdjs.PlaySceneCode.GDEnemyBulletObjects5[j]) === -1 )
            gdjs.PlaySceneCode.GDEnemyBulletObjects4_1final.push(gdjs.PlaySceneCode.GDEnemyBulletObjects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.PlaySceneCode.GDBigAsteroidObjects4_1final, gdjs.PlaySceneCode.GDBigAsteroidObjects4);
gdjs.copyArray(gdjs.PlaySceneCode.GDBulletObjects4_1final, gdjs.PlaySceneCode.GDBulletObjects4);
gdjs.copyArray(gdjs.PlaySceneCode.GDEnemyBulletObjects4_1final, gdjs.PlaySceneCode.GDEnemyBulletObjects4);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Explosion.wav", false, 60, gdjs.randomFloatInRange(0.9, 1));
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDDebrisHugeObjects4Objects, (( gdjs.PlaySceneCode.GDBigAsteroidObjects4.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDBigAsteroidObjects4[0].getPointX("")), (( gdjs.PlaySceneCode.GDBigAsteroidObjects4.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDBigAsteroidObjects4[0].getPointY("")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBulletHitObjects4Objects, (( gdjs.PlaySceneCode.GDBulletObjects4.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDBulletObjects4[0].getPointX("BulletHit")), (( gdjs.PlaySceneCode.GDBulletObjects4.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDBulletObjects4[0].getPointY("BulletHit")), "");
}{for(var i = 0, len = gdjs.PlaySceneCode.GDBigAsteroidObjects4.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDBigAsteroidObjects4[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDEnemyBulletObjects4.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDEnemyBulletObjects4[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDBulletObjects4.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDBulletObjects4[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents: 
gdjs.PlaySceneCode.eventsList10(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("MediumAsteroid"), gdjs.PlaySceneCode.GDMediumAsteroidObjects3);

for (gdjs.PlaySceneCode.forEachIndex4 = 0;gdjs.PlaySceneCode.forEachIndex4 < gdjs.PlaySceneCode.GDMediumAsteroidObjects3.length;++gdjs.PlaySceneCode.forEachIndex4) {
gdjs.PlaySceneCode.GDBulletObjects4.length = 0;

gdjs.PlaySceneCode.GDBulletHitObjects4.length = 0;

gdjs.PlaySceneCode.GDDebrisMediumObjects4.length = 0;

gdjs.PlaySceneCode.GDEnemyBulletObjects4.length = 0;

gdjs.PlaySceneCode.GDMediumAsteroidObjects4.length = 0;


gdjs.PlaySceneCode.forEachTemporary4 = gdjs.PlaySceneCode.GDMediumAsteroidObjects3[gdjs.PlaySceneCode.forEachIndex4];
gdjs.PlaySceneCode.GDMediumAsteroidObjects4.push(gdjs.PlaySceneCode.forEachTemporary4);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.PlaySceneCode.GDBulletObjects4_1final.length = 0;
gdjs.PlaySceneCode.GDEnemyBulletObjects4_1final.length = 0;
gdjs.PlaySceneCode.GDMediumAsteroidObjects4_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.PlaySceneCode.GDBulletObjects5);
gdjs.copyArray(gdjs.PlaySceneCode.GDMediumAsteroidObjects4, gdjs.PlaySceneCode.GDMediumAsteroidObjects5);

isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBulletObjects5Objects, gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDMediumAsteroidObjects5Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PlaySceneCode.GDBulletObjects5.length; j < jLen ; ++j) {
        if ( gdjs.PlaySceneCode.GDBulletObjects4_1final.indexOf(gdjs.PlaySceneCode.GDBulletObjects5[j]) === -1 )
            gdjs.PlaySceneCode.GDBulletObjects4_1final.push(gdjs.PlaySceneCode.GDBulletObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.PlaySceneCode.GDMediumAsteroidObjects5.length; j < jLen ; ++j) {
        if ( gdjs.PlaySceneCode.GDMediumAsteroidObjects4_1final.indexOf(gdjs.PlaySceneCode.GDMediumAsteroidObjects5[j]) === -1 )
            gdjs.PlaySceneCode.GDMediumAsteroidObjects4_1final.push(gdjs.PlaySceneCode.GDMediumAsteroidObjects5[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("EnemyBullet"), gdjs.PlaySceneCode.GDEnemyBulletObjects5);
gdjs.copyArray(gdjs.PlaySceneCode.GDMediumAsteroidObjects4, gdjs.PlaySceneCode.GDMediumAsteroidObjects5);

isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDEnemyBulletObjects5Objects, gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDMediumAsteroidObjects5Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PlaySceneCode.GDEnemyBulletObjects5.length; j < jLen ; ++j) {
        if ( gdjs.PlaySceneCode.GDEnemyBulletObjects4_1final.indexOf(gdjs.PlaySceneCode.GDEnemyBulletObjects5[j]) === -1 )
            gdjs.PlaySceneCode.GDEnemyBulletObjects4_1final.push(gdjs.PlaySceneCode.GDEnemyBulletObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.PlaySceneCode.GDMediumAsteroidObjects5.length; j < jLen ; ++j) {
        if ( gdjs.PlaySceneCode.GDMediumAsteroidObjects4_1final.indexOf(gdjs.PlaySceneCode.GDMediumAsteroidObjects5[j]) === -1 )
            gdjs.PlaySceneCode.GDMediumAsteroidObjects4_1final.push(gdjs.PlaySceneCode.GDMediumAsteroidObjects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.PlaySceneCode.GDBulletObjects4_1final, gdjs.PlaySceneCode.GDBulletObjects4);
gdjs.copyArray(gdjs.PlaySceneCode.GDEnemyBulletObjects4_1final, gdjs.PlaySceneCode.GDEnemyBulletObjects4);
gdjs.copyArray(gdjs.PlaySceneCode.GDMediumAsteroidObjects4_1final, gdjs.PlaySceneCode.GDMediumAsteroidObjects4);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Explosion.wav", false, 55, gdjs.randomFloatInRange(1, 1.1));
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDDebrisMediumObjects4Objects, (( gdjs.PlaySceneCode.GDMediumAsteroidObjects4.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDMediumAsteroidObjects4[0].getPointX("")), (( gdjs.PlaySceneCode.GDMediumAsteroidObjects4.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDMediumAsteroidObjects4[0].getPointY("")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBulletHitObjects4Objects, (( gdjs.PlaySceneCode.GDBulletObjects4.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDBulletObjects4[0].getPointX("BulletHit")), (( gdjs.PlaySceneCode.GDBulletObjects4.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDBulletObjects4[0].getPointY("BulletHit")), "");
}{for(var i = 0, len = gdjs.PlaySceneCode.GDMediumAsteroidObjects4.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDMediumAsteroidObjects4[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDBulletObjects4.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDBulletObjects4[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDEnemyBulletObjects4.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDEnemyBulletObjects4[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents: 
gdjs.PlaySceneCode.eventsList11(runtimeScene);} //Subevents end.
}
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("SmallAsteroid"), gdjs.PlaySceneCode.GDSmallAsteroidObjects2);

for (gdjs.PlaySceneCode.forEachIndex3 = 0;gdjs.PlaySceneCode.forEachIndex3 < gdjs.PlaySceneCode.GDSmallAsteroidObjects2.length;++gdjs.PlaySceneCode.forEachIndex3) {
gdjs.PlaySceneCode.GDBulletObjects3.length = 0;

gdjs.PlaySceneCode.GDBulletHitObjects3.length = 0;

gdjs.PlaySceneCode.GDDebrisSmallObjects3.length = 0;

gdjs.PlaySceneCode.GDEnemyBulletObjects3.length = 0;

gdjs.PlaySceneCode.GDSmallAsteroidObjects3.length = 0;


gdjs.PlaySceneCode.forEachTemporary3 = gdjs.PlaySceneCode.GDSmallAsteroidObjects2[gdjs.PlaySceneCode.forEachIndex3];
gdjs.PlaySceneCode.GDSmallAsteroidObjects3.push(gdjs.PlaySceneCode.forEachTemporary3);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.PlaySceneCode.GDBulletObjects3_1final.length = 0;
gdjs.PlaySceneCode.GDEnemyBulletObjects3_1final.length = 0;
gdjs.PlaySceneCode.GDSmallAsteroidObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.PlaySceneCode.GDBulletObjects4);
gdjs.copyArray(gdjs.PlaySceneCode.GDSmallAsteroidObjects3, gdjs.PlaySceneCode.GDSmallAsteroidObjects4);

isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBulletObjects4Objects, gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDSmallAsteroidObjects4Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PlaySceneCode.GDBulletObjects4.length; j < jLen ; ++j) {
        if ( gdjs.PlaySceneCode.GDBulletObjects3_1final.indexOf(gdjs.PlaySceneCode.GDBulletObjects4[j]) === -1 )
            gdjs.PlaySceneCode.GDBulletObjects3_1final.push(gdjs.PlaySceneCode.GDBulletObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.PlaySceneCode.GDSmallAsteroidObjects4.length; j < jLen ; ++j) {
        if ( gdjs.PlaySceneCode.GDSmallAsteroidObjects3_1final.indexOf(gdjs.PlaySceneCode.GDSmallAsteroidObjects4[j]) === -1 )
            gdjs.PlaySceneCode.GDSmallAsteroidObjects3_1final.push(gdjs.PlaySceneCode.GDSmallAsteroidObjects4[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("EnemyBullet"), gdjs.PlaySceneCode.GDEnemyBulletObjects4);
gdjs.copyArray(gdjs.PlaySceneCode.GDSmallAsteroidObjects3, gdjs.PlaySceneCode.GDSmallAsteroidObjects4);

isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDEnemyBulletObjects4Objects, gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDSmallAsteroidObjects4Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PlaySceneCode.GDEnemyBulletObjects4.length; j < jLen ; ++j) {
        if ( gdjs.PlaySceneCode.GDEnemyBulletObjects3_1final.indexOf(gdjs.PlaySceneCode.GDEnemyBulletObjects4[j]) === -1 )
            gdjs.PlaySceneCode.GDEnemyBulletObjects3_1final.push(gdjs.PlaySceneCode.GDEnemyBulletObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.PlaySceneCode.GDSmallAsteroidObjects4.length; j < jLen ; ++j) {
        if ( gdjs.PlaySceneCode.GDSmallAsteroidObjects3_1final.indexOf(gdjs.PlaySceneCode.GDSmallAsteroidObjects4[j]) === -1 )
            gdjs.PlaySceneCode.GDSmallAsteroidObjects3_1final.push(gdjs.PlaySceneCode.GDSmallAsteroidObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.PlaySceneCode.GDBulletObjects3_1final, gdjs.PlaySceneCode.GDBulletObjects3);
gdjs.copyArray(gdjs.PlaySceneCode.GDEnemyBulletObjects3_1final, gdjs.PlaySceneCode.GDEnemyBulletObjects3);
gdjs.copyArray(gdjs.PlaySceneCode.GDSmallAsteroidObjects3_1final, gdjs.PlaySceneCode.GDSmallAsteroidObjects3);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Explosion.wav", false, 50, gdjs.randomFloatInRange(1.1, 1.2));
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDDebrisSmallObjects3Objects, (( gdjs.PlaySceneCode.GDSmallAsteroidObjects3.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDSmallAsteroidObjects3[0].getPointX("")), (( gdjs.PlaySceneCode.GDSmallAsteroidObjects3.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDSmallAsteroidObjects3[0].getPointY("")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBulletHitObjects3Objects, (( gdjs.PlaySceneCode.GDBulletObjects3.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDBulletObjects3[0].getPointX("BulletHit")), (( gdjs.PlaySceneCode.GDBulletObjects3.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDBulletObjects3[0].getPointY("BulletHit")), "");
}{for(var i = 0, len = gdjs.PlaySceneCode.GDSmallAsteroidObjects3.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDSmallAsteroidObjects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDEnemyBulletObjects3.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDEnemyBulletObjects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDBulletObjects3.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDBulletObjects3[i].deleteFromScene(runtimeScene);
}
}}
}

}


};gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.PlaySceneCode.GDPlayerObjects2});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBigAsteroidObjects2ObjectsGDgdjs_9546PlaySceneCode_9546GDMediumAsteroidObjects2ObjectsGDgdjs_9546PlaySceneCode_9546GDSmallAsteroidObjects2Objects = Hashtable.newFrom({"BigAsteroid": gdjs.PlaySceneCode.GDBigAsteroidObjects2, "MediumAsteroid": gdjs.PlaySceneCode.GDMediumAsteroidObjects2, "SmallAsteroid": gdjs.PlaySceneCode.GDSmallAsteroidObjects2});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDEnemyBulletObjects2Objects = Hashtable.newFrom({"EnemyBullet": gdjs.PlaySceneCode.GDEnemyBulletObjects2});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.PlaySceneCode.GDPlayerObjects2});
gdjs.PlaySceneCode.eventsList14 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtsExt__CameraShake__SetLayerTranslationAmplitude.func(runtimeScene, 1, 1, "", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__CameraShake__SetLayerRotationAmplitude.func(runtimeScene, 1, "", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__CameraShake__SetLayerZoomAmplitude.func(runtimeScene, 1.01, "", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__CameraShake__SetDefaultShakingFrequency.func(runtimeScene, 10, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("BigAsteroid"), gdjs.PlaySceneCode.GDBigAsteroidObjects2);
gdjs.copyArray(runtimeScene.getObjects("MediumAsteroid"), gdjs.PlaySceneCode.GDMediumAsteroidObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PlaySceneCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("SmallAsteroid"), gdjs.PlaySceneCode.GDSmallAsteroidObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.physics2.objectsCollide(gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDPlayerObjects2Objects, "Physics2", gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDBigAsteroidObjects2ObjectsGDgdjs_9546PlaySceneCode_9546GDMediumAsteroidObjects2ObjectsGDgdjs_9546PlaySceneCode_9546GDSmallAsteroidObjects2Objects, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("LifeBar"), gdjs.PlaySceneCode.GDLifeBarObjects2);
/* Reuse gdjs.PlaySceneCode.GDPlayerObjects2 */
{gdjs.evtTools.sound.playSound(runtimeScene, "Bump.wav", false, 60, gdjs.randomFloatInRange(0.9, 1.1));
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 1, 0, 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.PlaySceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDPlayerObjects2[i].getBehavior("Flash").Flash(1.5, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDLifeBarObjects2.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDLifeBarObjects2[i].getBehavior("Flash").Flash(1.5, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDPlayerObjects2[i].getBehavior("Health").Hit(1, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDLifeBarObjects2.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDLifeBarObjects2[i].SetValue((( gdjs.PlaySceneCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDPlayerObjects2[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("EnemyBullet"), gdjs.PlaySceneCode.GDEnemyBulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PlaySceneCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDEnemyBulletObjects2Objects, gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDPlayerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.PlaySceneCode.GDEnemyBulletObjects2 */
gdjs.copyArray(runtimeScene.getObjects("LifeBar"), gdjs.PlaySceneCode.GDLifeBarObjects2);
/* Reuse gdjs.PlaySceneCode.GDPlayerObjects2 */
{gdjs.evtTools.sound.playSound(runtimeScene, "Hit 1.aac", false, 60, gdjs.randomFloatInRange(0.9, 1.1));
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 1, 0, 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.PlaySceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDPlayerObjects2[i].getBehavior("Flash").Flash(1.5, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDLifeBarObjects2.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDLifeBarObjects2[i].getBehavior("Flash").Flash(1.5, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDPlayerObjects2[i].getBehavior("Health").Hit(1, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDLifeBarObjects2.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDLifeBarObjects2[i].SetValue((( gdjs.PlaySceneCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDPlayerObjects2[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDEnemyBulletObjects2.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDEnemyBulletObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PlaySceneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PlaySceneCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.PlaySceneCode.GDPlayerObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.PlaySceneCode.GDPlayerObjects1[k] = gdjs.PlaySceneCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.PlaySceneCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("MotionTrail"), gdjs.PlaySceneCode.GDMotionTrailObjects1);
{for(var i = 0, len = gdjs.PlaySceneCode.GDMotionTrailObjects1.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDMotionTrailObjects1[i].stopEmission();
}
}{runtimeScene.getScene().getVariables().get("State").setString("GameOverAnimation");
}}

}


};gdjs.PlaySceneCode.eventsList15 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("TimeText"), gdjs.PlaySceneCode.GDTimeTextObjects2);
{for(var i = 0, len = gdjs.PlaySceneCode.GDTimeTextObjects2.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDTimeTextObjects2[i].getBehavior("Text").setText("Time:" + gdjs.evtsExt__TimeFormatter__SecondsToHHMMSS000.func(runtimeScene, gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSeconds(runtimeScene, "Timer"), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
}}

}


{


gdjs.PlaySceneCode.eventsList2(runtimeScene);
}


{


gdjs.PlaySceneCode.eventsList3(runtimeScene);
}


{


gdjs.PlaySceneCode.eventsList4(runtimeScene);
}


{


gdjs.PlaySceneCode.eventsList7(runtimeScene);
}


{


gdjs.PlaySceneCode.eventsList9(runtimeScene);
}


{


gdjs.PlaySceneCode.eventsList13(runtimeScene);
}


{


gdjs.PlaySceneCode.eventsList14(runtimeScene);
}


};gdjs.PlaySceneCode.eventsList16 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("State")) == "GamePlaying";
if (isConditionTrue_0) {

{ //Subevents
gdjs.PlaySceneCode.eventsList15(runtimeScene);} //End of subevents
}

}


};gdjs.PlaySceneCode.eventsList17 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16192732);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "Menu", 0, 0, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ContinueButton"), gdjs.PlaySceneCode.GDContinueButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PlaySceneCode.GDContinueButtonObjects1.length;i<l;++i) {
    if ( gdjs.PlaySceneCode.GDContinueButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.PlaySceneCode.GDContinueButtonObjects1[k] = gdjs.PlaySceneCode.GDContinueButtonObjects1[i];
        ++k;
    }
}
gdjs.PlaySceneCode.GDContinueButtonObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.PlaySceneCode.GDContinueButtonObjects1 */
gdjs.copyArray(runtimeScene.getObjects("MenuText"), gdjs.PlaySceneCode.GDMenuTextObjects1);
{runtimeScene.getScene().getVariables().get("State").setString("GamePlaying");
}{gdjs.evtTools.runtimeScene.unpauseTimer(runtimeScene, "Timer");
}{for(var i = 0, len = gdjs.PlaySceneCode.GDMenuTextObjects1.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDMenuTextObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDContinueButtonObjects1.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDContinueButtonObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.PlaySceneCode.eventsList18 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().get("State").setString("MenuAnimation");
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "Timer");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("State")) == "MenuAnimation";
if (isConditionTrue_0) {

{ //Subevents
gdjs.PlaySceneCode.eventsList17(runtimeScene);} //End of subevents
}

}


};gdjs.PlaySceneCode.mapOfEmptyGDBigAsteroidObjectsEmptyGDMediumAsteroidObjectsEmptyGDSmallAsteroidObjects = Hashtable.newFrom({"BigAsteroid": [], "MediumAsteroid": [], "SmallAsteroid": []});
gdjs.PlaySceneCode.mapOfEmptyGDEnemyObjects = Hashtable.newFrom({"Enemy": []});
gdjs.PlaySceneCode.asyncCallback16198116 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("ContinueButton"), gdjs.PlaySceneCode.GDContinueButtonObjects3);

{for(var i = 0, len = gdjs.PlaySceneCode.GDContinueButtonObjects3.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDContinueButtonObjects3[i].hide(false);
}
}{runtimeScene.getScene().getVariables().get("State").setString("NextLevelContinue");
}}
gdjs.PlaySceneCode.eventsList19 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.PlaySceneCode.GDContinueButtonObjects2) asyncObjectsList.addObject("ContinueButton", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.PlaySceneCode.asyncCallback16198116(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.PlaySceneCode.eventsList20 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16197132);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "NextLevel", 0, 0, 0);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16196676);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ContinueButton"), gdjs.PlaySceneCode.GDContinueButtonObjects2);
{for(var i = 0, len = gdjs.PlaySceneCode.GDContinueButtonObjects2.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDContinueButtonObjects2[i].hide();
}
}
{ //Subevents
gdjs.PlaySceneCode.eventsList19(runtimeScene);} //End of subevents
}

}


};gdjs.PlaySceneCode.eventsList21 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlaySceneCode.mapOfEmptyGDBigAsteroidObjectsEmptyGDMediumAsteroidObjectsEmptyGDSmallAsteroidObjects) == 0;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlaySceneCode.mapOfEmptyGDEnemyObjects) == 0;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TutorialText"), gdjs.PlaySceneCode.GDTutorialTextObjects2);
{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "EnemyTimer");
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "Timer");
}{runtimeScene.getGame().getVariables().getFromIndex(0).setString(gdjs.evtTools.common.toString(gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSeconds(runtimeScene, "Timer")));
}{for(var i = 0, len = gdjs.PlaySceneCode.GDTutorialTextObjects2.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDTutorialTextObjects2[i].hide();
}
}{runtimeScene.getScene().getVariables().get("State").setString("NextLevelScreen");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("State")) == "NextLevelScreen";
if (isConditionTrue_0) {

{ //Subevents
gdjs.PlaySceneCode.eventsList20(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("State")) == "NextLevelContinue";
if (isConditionTrue_0) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("ContinueButton"), gdjs.PlaySceneCode.GDContinueButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PlaySceneCode.GDContinueButtonObjects1.length;i<l;++i) {
    if ( gdjs.PlaySceneCode.GDContinueButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.PlaySceneCode.GDContinueButtonObjects1[k] = gdjs.PlaySceneCode.GDContinueButtonObjects1[i];
        ++k;
    }
}
gdjs.PlaySceneCode.GDContinueButtonObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "PlayScene2", false);
}}

}


};gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDDeathShipParticleObjects3Objects = Hashtable.newFrom({"DeathShipParticle": gdjs.PlaySceneCode.GDDeathShipParticleObjects3});
gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDDeathDebrisParticleObjects3Objects = Hashtable.newFrom({"DeathDebrisParticle": gdjs.PlaySceneCode.GDDeathDebrisParticleObjects3});
gdjs.PlaySceneCode.asyncCallback16203540 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("ContinueText"), gdjs.PlaySceneCode.GDContinueTextObjects3);

{for(var i = 0, len = gdjs.PlaySceneCode.GDContinueTextObjects3.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDContinueTextObjects3[i].hide(false);
}
}{runtimeScene.getScene().getVariables().get("State").setString("GameOverWaitKey");
}}
gdjs.PlaySceneCode.eventsList22 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.PlaySceneCode.GDContinueTextObjects2) asyncObjectsList.addObject("ContinueText", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.PlaySceneCode.asyncCallback16203540(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.PlaySceneCode.eventsList23 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16201012);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PlaySceneCode.GDPlayerObjects3);
gdjs.PlaySceneCode.GDDeathDebrisParticleObjects3.length = 0;

gdjs.PlaySceneCode.GDDeathShipParticleObjects3.length = 0;

{gdjs.evtTools.sound.playSound(runtimeScene, "Death.wav", false, 50, 1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDDeathShipParticleObjects3Objects, (( gdjs.PlaySceneCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDPlayerObjects3[0].getPointX("")), (( gdjs.PlaySceneCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDPlayerObjects3[0].getPointY("")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlaySceneCode.mapOfGDgdjs_9546PlaySceneCode_9546GDDeathDebrisParticleObjects3Objects, (( gdjs.PlaySceneCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDPlayerObjects3[0].getPointX("")), (( gdjs.PlaySceneCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDPlayerObjects3[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.PlaySceneCode.GDDeathShipParticleObjects3.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDDeathShipParticleObjects3[i].setAngle((( gdjs.PlaySceneCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.PlaySceneCode.GDPlayerObjects3[0].getAngle()));
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDPlayerObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16202524);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "GameOver", 0, 0, 0);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16202660);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ContinueText"), gdjs.PlaySceneCode.GDContinueTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("TutorialText"), gdjs.PlaySceneCode.GDTutorialTextObjects2);
{for(var i = 0, len = gdjs.PlaySceneCode.GDTutorialTextObjects2.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDTutorialTextObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.PlaySceneCode.GDContinueTextObjects2.length ;i < len;++i) {
    gdjs.PlaySceneCode.GDContinueTextObjects2[i].hide();
}
}
{ //Subevents
gdjs.PlaySceneCode.eventsList22(runtimeScene);} //End of subevents
}

}


};gdjs.PlaySceneCode.eventsList24 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.anyKeyReleased(runtimeScene);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "PlayScene", false);
}}

}


};gdjs.PlaySceneCode.eventsList25 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("State")) == "GameOverAnimation";
if (isConditionTrue_0) {

{ //Subevents
gdjs.PlaySceneCode.eventsList23(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("State")) == "GameOverWaitKey";
if (isConditionTrue_0) {

{ //Subevents
gdjs.PlaySceneCode.eventsList24(runtimeScene);} //End of subevents
}

}


};gdjs.PlaySceneCode.eventsList26 = function(runtimeScene) {

{



}


{


gdjs.PlaySceneCode.eventsList1(runtimeScene);
}


{


gdjs.PlaySceneCode.eventsList16(runtimeScene);
}


{


gdjs.PlaySceneCode.eventsList18(runtimeScene);
}


{


gdjs.PlaySceneCode.eventsList21(runtimeScene);
}


{


gdjs.PlaySceneCode.eventsList25(runtimeScene);
}


};

gdjs.PlaySceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.PlaySceneCode.GDPlayerObjects1.length = 0;
gdjs.PlaySceneCode.GDPlayerObjects2.length = 0;
gdjs.PlaySceneCode.GDPlayerObjects3.length = 0;
gdjs.PlaySceneCode.GDPlayerObjects4.length = 0;
gdjs.PlaySceneCode.GDPlayerObjects5.length = 0;
gdjs.PlaySceneCode.GDPlayerObjects6.length = 0;
gdjs.PlaySceneCode.GDBulletObjects1.length = 0;
gdjs.PlaySceneCode.GDBulletObjects2.length = 0;
gdjs.PlaySceneCode.GDBulletObjects3.length = 0;
gdjs.PlaySceneCode.GDBulletObjects4.length = 0;
gdjs.PlaySceneCode.GDBulletObjects5.length = 0;
gdjs.PlaySceneCode.GDBulletObjects6.length = 0;
gdjs.PlaySceneCode.GDBigAsteroidObjects1.length = 0;
gdjs.PlaySceneCode.GDBigAsteroidObjects2.length = 0;
gdjs.PlaySceneCode.GDBigAsteroidObjects3.length = 0;
gdjs.PlaySceneCode.GDBigAsteroidObjects4.length = 0;
gdjs.PlaySceneCode.GDBigAsteroidObjects5.length = 0;
gdjs.PlaySceneCode.GDBigAsteroidObjects6.length = 0;
gdjs.PlaySceneCode.GDMediumAsteroidObjects1.length = 0;
gdjs.PlaySceneCode.GDMediumAsteroidObjects2.length = 0;
gdjs.PlaySceneCode.GDMediumAsteroidObjects3.length = 0;
gdjs.PlaySceneCode.GDMediumAsteroidObjects4.length = 0;
gdjs.PlaySceneCode.GDMediumAsteroidObjects5.length = 0;
gdjs.PlaySceneCode.GDMediumAsteroidObjects6.length = 0;
gdjs.PlaySceneCode.GDSmallAsteroidObjects1.length = 0;
gdjs.PlaySceneCode.GDSmallAsteroidObjects2.length = 0;
gdjs.PlaySceneCode.GDSmallAsteroidObjects3.length = 0;
gdjs.PlaySceneCode.GDSmallAsteroidObjects4.length = 0;
gdjs.PlaySceneCode.GDSmallAsteroidObjects5.length = 0;
gdjs.PlaySceneCode.GDSmallAsteroidObjects6.length = 0;
gdjs.PlaySceneCode.GDLifeBarObjects1.length = 0;
gdjs.PlaySceneCode.GDLifeBarObjects2.length = 0;
gdjs.PlaySceneCode.GDLifeBarObjects3.length = 0;
gdjs.PlaySceneCode.GDLifeBarObjects4.length = 0;
gdjs.PlaySceneCode.GDLifeBarObjects5.length = 0;
gdjs.PlaySceneCode.GDLifeBarObjects6.length = 0;
gdjs.PlaySceneCode.GDGameOverObjects1.length = 0;
gdjs.PlaySceneCode.GDGameOverObjects2.length = 0;
gdjs.PlaySceneCode.GDGameOverObjects3.length = 0;
gdjs.PlaySceneCode.GDGameOverObjects4.length = 0;
gdjs.PlaySceneCode.GDGameOverObjects5.length = 0;
gdjs.PlaySceneCode.GDGameOverObjects6.length = 0;
gdjs.PlaySceneCode.GDDeathShipParticleObjects1.length = 0;
gdjs.PlaySceneCode.GDDeathShipParticleObjects2.length = 0;
gdjs.PlaySceneCode.GDDeathShipParticleObjects3.length = 0;
gdjs.PlaySceneCode.GDDeathShipParticleObjects4.length = 0;
gdjs.PlaySceneCode.GDDeathShipParticleObjects5.length = 0;
gdjs.PlaySceneCode.GDDeathShipParticleObjects6.length = 0;
gdjs.PlaySceneCode.GDDeathDebrisParticleObjects1.length = 0;
gdjs.PlaySceneCode.GDDeathDebrisParticleObjects2.length = 0;
gdjs.PlaySceneCode.GDDeathDebrisParticleObjects3.length = 0;
gdjs.PlaySceneCode.GDDeathDebrisParticleObjects4.length = 0;
gdjs.PlaySceneCode.GDDeathDebrisParticleObjects5.length = 0;
gdjs.PlaySceneCode.GDDeathDebrisParticleObjects6.length = 0;
gdjs.PlaySceneCode.GDDebrisHugeObjects1.length = 0;
gdjs.PlaySceneCode.GDDebrisHugeObjects2.length = 0;
gdjs.PlaySceneCode.GDDebrisHugeObjects3.length = 0;
gdjs.PlaySceneCode.GDDebrisHugeObjects4.length = 0;
gdjs.PlaySceneCode.GDDebrisHugeObjects5.length = 0;
gdjs.PlaySceneCode.GDDebrisHugeObjects6.length = 0;
gdjs.PlaySceneCode.GDDebrisMediumObjects1.length = 0;
gdjs.PlaySceneCode.GDDebrisMediumObjects2.length = 0;
gdjs.PlaySceneCode.GDDebrisMediumObjects3.length = 0;
gdjs.PlaySceneCode.GDDebrisMediumObjects4.length = 0;
gdjs.PlaySceneCode.GDDebrisMediumObjects5.length = 0;
gdjs.PlaySceneCode.GDDebrisMediumObjects6.length = 0;
gdjs.PlaySceneCode.GDDebrisSmallObjects1.length = 0;
gdjs.PlaySceneCode.GDDebrisSmallObjects2.length = 0;
gdjs.PlaySceneCode.GDDebrisSmallObjects3.length = 0;
gdjs.PlaySceneCode.GDDebrisSmallObjects4.length = 0;
gdjs.PlaySceneCode.GDDebrisSmallObjects5.length = 0;
gdjs.PlaySceneCode.GDDebrisSmallObjects6.length = 0;
gdjs.PlaySceneCode.GDBulletHitObjects1.length = 0;
gdjs.PlaySceneCode.GDBulletHitObjects2.length = 0;
gdjs.PlaySceneCode.GDBulletHitObjects3.length = 0;
gdjs.PlaySceneCode.GDBulletHitObjects4.length = 0;
gdjs.PlaySceneCode.GDBulletHitObjects5.length = 0;
gdjs.PlaySceneCode.GDBulletHitObjects6.length = 0;
gdjs.PlaySceneCode.GDBulletFlashObjects1.length = 0;
gdjs.PlaySceneCode.GDBulletFlashObjects2.length = 0;
gdjs.PlaySceneCode.GDBulletFlashObjects3.length = 0;
gdjs.PlaySceneCode.GDBulletFlashObjects4.length = 0;
gdjs.PlaySceneCode.GDBulletFlashObjects5.length = 0;
gdjs.PlaySceneCode.GDBulletFlashObjects6.length = 0;
gdjs.PlaySceneCode.GDStarBackgroundObjects1.length = 0;
gdjs.PlaySceneCode.GDStarBackgroundObjects2.length = 0;
gdjs.PlaySceneCode.GDStarBackgroundObjects3.length = 0;
gdjs.PlaySceneCode.GDStarBackgroundObjects4.length = 0;
gdjs.PlaySceneCode.GDStarBackgroundObjects5.length = 0;
gdjs.PlaySceneCode.GDStarBackgroundObjects6.length = 0;
gdjs.PlaySceneCode.GDMotionTrailObjects1.length = 0;
gdjs.PlaySceneCode.GDMotionTrailObjects2.length = 0;
gdjs.PlaySceneCode.GDMotionTrailObjects3.length = 0;
gdjs.PlaySceneCode.GDMotionTrailObjects4.length = 0;
gdjs.PlaySceneCode.GDMotionTrailObjects5.length = 0;
gdjs.PlaySceneCode.GDMotionTrailObjects6.length = 0;
gdjs.PlaySceneCode.GDTutorialTextObjects1.length = 0;
gdjs.PlaySceneCode.GDTutorialTextObjects2.length = 0;
gdjs.PlaySceneCode.GDTutorialTextObjects3.length = 0;
gdjs.PlaySceneCode.GDTutorialTextObjects4.length = 0;
gdjs.PlaySceneCode.GDTutorialTextObjects5.length = 0;
gdjs.PlaySceneCode.GDTutorialTextObjects6.length = 0;
gdjs.PlaySceneCode.GDContinueTextObjects1.length = 0;
gdjs.PlaySceneCode.GDContinueTextObjects2.length = 0;
gdjs.PlaySceneCode.GDContinueTextObjects3.length = 0;
gdjs.PlaySceneCode.GDContinueTextObjects4.length = 0;
gdjs.PlaySceneCode.GDContinueTextObjects5.length = 0;
gdjs.PlaySceneCode.GDContinueTextObjects6.length = 0;
gdjs.PlaySceneCode.GDRightButtonObjects1.length = 0;
gdjs.PlaySceneCode.GDRightButtonObjects2.length = 0;
gdjs.PlaySceneCode.GDRightButtonObjects3.length = 0;
gdjs.PlaySceneCode.GDRightButtonObjects4.length = 0;
gdjs.PlaySceneCode.GDRightButtonObjects5.length = 0;
gdjs.PlaySceneCode.GDRightButtonObjects6.length = 0;
gdjs.PlaySceneCode.GDLeftButtonObjects1.length = 0;
gdjs.PlaySceneCode.GDLeftButtonObjects2.length = 0;
gdjs.PlaySceneCode.GDLeftButtonObjects3.length = 0;
gdjs.PlaySceneCode.GDLeftButtonObjects4.length = 0;
gdjs.PlaySceneCode.GDLeftButtonObjects5.length = 0;
gdjs.PlaySceneCode.GDLeftButtonObjects6.length = 0;
gdjs.PlaySceneCode.GDTopButtonObjects1.length = 0;
gdjs.PlaySceneCode.GDTopButtonObjects2.length = 0;
gdjs.PlaySceneCode.GDTopButtonObjects3.length = 0;
gdjs.PlaySceneCode.GDTopButtonObjects4.length = 0;
gdjs.PlaySceneCode.GDTopButtonObjects5.length = 0;
gdjs.PlaySceneCode.GDTopButtonObjects6.length = 0;
gdjs.PlaySceneCode.GDFireButtonObjects1.length = 0;
gdjs.PlaySceneCode.GDFireButtonObjects2.length = 0;
gdjs.PlaySceneCode.GDFireButtonObjects3.length = 0;
gdjs.PlaySceneCode.GDFireButtonObjects4.length = 0;
gdjs.PlaySceneCode.GDFireButtonObjects5.length = 0;
gdjs.PlaySceneCode.GDFireButtonObjects6.length = 0;
gdjs.PlaySceneCode.GDEnemyBulletObjects1.length = 0;
gdjs.PlaySceneCode.GDEnemyBulletObjects2.length = 0;
gdjs.PlaySceneCode.GDEnemyBulletObjects3.length = 0;
gdjs.PlaySceneCode.GDEnemyBulletObjects4.length = 0;
gdjs.PlaySceneCode.GDEnemyBulletObjects5.length = 0;
gdjs.PlaySceneCode.GDEnemyBulletObjects6.length = 0;
gdjs.PlaySceneCode.GDEnemyObjects1.length = 0;
gdjs.PlaySceneCode.GDEnemyObjects2.length = 0;
gdjs.PlaySceneCode.GDEnemyObjects3.length = 0;
gdjs.PlaySceneCode.GDEnemyObjects4.length = 0;
gdjs.PlaySceneCode.GDEnemyObjects5.length = 0;
gdjs.PlaySceneCode.GDEnemyObjects6.length = 0;
gdjs.PlaySceneCode.GDTitleTextObjects1.length = 0;
gdjs.PlaySceneCode.GDTitleTextObjects2.length = 0;
gdjs.PlaySceneCode.GDTitleTextObjects3.length = 0;
gdjs.PlaySceneCode.GDTitleTextObjects4.length = 0;
gdjs.PlaySceneCode.GDTitleTextObjects5.length = 0;
gdjs.PlaySceneCode.GDTitleTextObjects6.length = 0;
gdjs.PlaySceneCode.GDHealthPowerObjects1.length = 0;
gdjs.PlaySceneCode.GDHealthPowerObjects2.length = 0;
gdjs.PlaySceneCode.GDHealthPowerObjects3.length = 0;
gdjs.PlaySceneCode.GDHealthPowerObjects4.length = 0;
gdjs.PlaySceneCode.GDHealthPowerObjects5.length = 0;
gdjs.PlaySceneCode.GDHealthPowerObjects6.length = 0;
gdjs.PlaySceneCode.GDNextLevelObjects1.length = 0;
gdjs.PlaySceneCode.GDNextLevelObjects2.length = 0;
gdjs.PlaySceneCode.GDNextLevelObjects3.length = 0;
gdjs.PlaySceneCode.GDNextLevelObjects4.length = 0;
gdjs.PlaySceneCode.GDNextLevelObjects5.length = 0;
gdjs.PlaySceneCode.GDNextLevelObjects6.length = 0;
gdjs.PlaySceneCode.GDDeathEnemyParticleObjects1.length = 0;
gdjs.PlaySceneCode.GDDeathEnemyParticleObjects2.length = 0;
gdjs.PlaySceneCode.GDDeathEnemyParticleObjects3.length = 0;
gdjs.PlaySceneCode.GDDeathEnemyParticleObjects4.length = 0;
gdjs.PlaySceneCode.GDDeathEnemyParticleObjects5.length = 0;
gdjs.PlaySceneCode.GDDeathEnemyParticleObjects6.length = 0;
gdjs.PlaySceneCode.GDMenuTextObjects1.length = 0;
gdjs.PlaySceneCode.GDMenuTextObjects2.length = 0;
gdjs.PlaySceneCode.GDMenuTextObjects3.length = 0;
gdjs.PlaySceneCode.GDMenuTextObjects4.length = 0;
gdjs.PlaySceneCode.GDMenuTextObjects5.length = 0;
gdjs.PlaySceneCode.GDMenuTextObjects6.length = 0;
gdjs.PlaySceneCode.GDContinueButtonObjects1.length = 0;
gdjs.PlaySceneCode.GDContinueButtonObjects2.length = 0;
gdjs.PlaySceneCode.GDContinueButtonObjects3.length = 0;
gdjs.PlaySceneCode.GDContinueButtonObjects4.length = 0;
gdjs.PlaySceneCode.GDContinueButtonObjects5.length = 0;
gdjs.PlaySceneCode.GDContinueButtonObjects6.length = 0;
gdjs.PlaySceneCode.GDFinishTextObjects1.length = 0;
gdjs.PlaySceneCode.GDFinishTextObjects2.length = 0;
gdjs.PlaySceneCode.GDFinishTextObjects3.length = 0;
gdjs.PlaySceneCode.GDFinishTextObjects4.length = 0;
gdjs.PlaySceneCode.GDFinishTextObjects5.length = 0;
gdjs.PlaySceneCode.GDFinishTextObjects6.length = 0;
gdjs.PlaySceneCode.GDTimeTextObjects1.length = 0;
gdjs.PlaySceneCode.GDTimeTextObjects2.length = 0;
gdjs.PlaySceneCode.GDTimeTextObjects3.length = 0;
gdjs.PlaySceneCode.GDTimeTextObjects4.length = 0;
gdjs.PlaySceneCode.GDTimeTextObjects5.length = 0;
gdjs.PlaySceneCode.GDTimeTextObjects6.length = 0;
gdjs.PlaySceneCode.GDTimeText2Objects1.length = 0;
gdjs.PlaySceneCode.GDTimeText2Objects2.length = 0;
gdjs.PlaySceneCode.GDTimeText2Objects3.length = 0;
gdjs.PlaySceneCode.GDTimeText2Objects4.length = 0;
gdjs.PlaySceneCode.GDTimeText2Objects5.length = 0;
gdjs.PlaySceneCode.GDTimeText2Objects6.length = 0;
gdjs.PlaySceneCode.GDTimeText3Objects1.length = 0;
gdjs.PlaySceneCode.GDTimeText3Objects2.length = 0;
gdjs.PlaySceneCode.GDTimeText3Objects3.length = 0;
gdjs.PlaySceneCode.GDTimeText3Objects4.length = 0;
gdjs.PlaySceneCode.GDTimeText3Objects5.length = 0;
gdjs.PlaySceneCode.GDTimeText3Objects6.length = 0;
gdjs.PlaySceneCode.GDTimeText4Objects1.length = 0;
gdjs.PlaySceneCode.GDTimeText4Objects2.length = 0;
gdjs.PlaySceneCode.GDTimeText4Objects3.length = 0;
gdjs.PlaySceneCode.GDTimeText4Objects4.length = 0;
gdjs.PlaySceneCode.GDTimeText4Objects5.length = 0;
gdjs.PlaySceneCode.GDTimeText4Objects6.length = 0;

gdjs.PlaySceneCode.eventsList26(runtimeScene);

return;

}

gdjs['PlaySceneCode'] = gdjs.PlaySceneCode;
